import { useEffect, useLayoutEffect, useState, type ReactNode } from "react";
import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { BookOpen, ChartPie, Menu, Moon, PenLine, Sun, Wallet } from "lucide-react";
import { Toaster } from "sonner";
import { cn } from "@/lib/cn";
import { formatLong, todayISO } from "@/lib/dates";
import { useLedger } from "@/lib/store";
import { applyTheme } from "@/lib/theme";

const NAV = [
  { to: "/", label: "Özet", icon: BookOpen },
  { to: "/gun", label: "Gün", icon: PenLine },
  { to: "/gider", label: "Gider", icon: Wallet },
  { to: "/rapor", label: "Rapor", icon: ChartPie },
  { to: "/diger", label: "Diğer", icon: Menu },
] as const;

const MORE = ["/diger", "/arac", "/hedef", "/ayarlar"];

export function AppFrame() {
  const theme = useLedger((s) => s.settings.theme);
  const setSettings = useLedger((s) => s.setSettings);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    void Promise.resolve(useLedger.persist.rehydrate()).catch(() => undefined);
  }, []);

  useLayoutEffect(() => {
    applyTheme(theme);
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const compute = () => setDark(theme === "dark" || (theme === "system" && mq.matches));
    compute();
    mq.addEventListener("change", compute);
    return () => mq.removeEventListener("change", compute);
  }, [theme]);

  return (
    <>
      <Toaster
        position="top-center"
        theme={dark ? "dark" : "light"}
        toastOptions={{
          style: {
            background: "var(--surface)",
            color: "var(--ink)",
            border: "1px solid var(--line)",
          },
        }}
      />
      <Shell dark={dark} onToggleTheme={() => setSettings({ theme: dark ? "light" : "dark" })}>
        <Outlet />
      </Shell>
    </>
  );
}

function Shell({
  children,
  dark,
  onToggleTheme,
}: {
  children: ReactNode;
  dark: boolean;
  onToggleTheme: () => void;
}) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const today = todayISO();

  return (
    <div className="min-h-dvh lg:pl-60">
      <aside className="no-print fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-paper px-4 py-6 lg:flex">
        <p className="px-2 font-display text-3xl tracking-tight">Tur Defteri</p>
        <p className="mt-1 px-2 text-sm text-muted">Gün sonu kasa</p>
        <nav className="mt-8 flex flex-col gap-1" aria-label="Bölümler">
          {NAV.map((item) => (
            <NavLink key={item.to} to={item.to} label={item.label} icon={item.icon} path={path} wide />
          ))}
        </nav>
      </aside>

      <header className="no-print sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-paper px-5 py-3 lg:px-8">
        <div className="flex items-center gap-3 lg:hidden">
          <span
            className="flex size-9 items-center justify-center rounded-lg bg-primary font-display text-sm text-primary-fg"
            aria-hidden
          >
            Td
          </span>
          <p className="font-display text-xl leading-none tracking-tight">Tur Defteri</p>
        </div>
        <p className="hidden text-sm text-muted lg:block">{formatLong(today)}</p>
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-full border border-line bg-surface"
          aria-label={dark ? "Aydınlık temaya geç" : "Karanlık temaya geç"}
          onClick={onToggleTheme}
        >
          {dark ? <Sun className="size-5" /> : <Moon className="size-5" />}
        </button>
      </header>

      <main id="icerik" className="with-nav mx-auto w-full max-w-3xl px-5 pt-6 lg:px-8">
        {children}
      </main>

      <nav
        className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-line bg-paper lg:hidden"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
        aria-label="Bölümler"
      >
        <div className="flex">
          {NAV.map((item) => (
            <NavLink key={item.to} to={item.to} label={item.label} icon={item.icon} path={path} />
          ))}
        </div>
      </nav>
    </div>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  path,
  wide = false,
}: {
  to: (typeof NAV)[number]["to"];
  label: string;
  icon: typeof BookOpen;
  path: string;
  wide?: boolean;
}) {
  const active =
    to === "/"
      ? path === "/"
      : to === "/diger"
        ? MORE.some((p) => path === p || path.startsWith(`${p}/`))
        : path === to || path.startsWith(`${to}/`);

  return (
    <Link
      to={to}
      aria-current={active ? "page" : undefined}
      className={cn(
        wide
          ? "flex min-h-12 items-center gap-3 rounded-xl px-3 text-base font-medium"
          : "flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 text-xs font-medium",
        active ? "text-primary" : "text-muted",
        wide && active && "bg-surface",
      )}
    >
      <Icon className="size-6" strokeWidth={1.75} aria-hidden />
      {label}
    </Link>
  );
}
