import type { ButtonHTMLAttributes, ReactNode } from "react";
import { useState } from "react";
import { cn } from "@/lib/cn";
import { formatTRY } from "@/lib/format";

type Variant = "primary" | "surface" | "ghost" | "danger";
type Size = "lg" | "md";

export function buttonClass(variant: Variant = "primary", size: Size = "md", className?: string) {
  return cn(
    "inline-flex items-center justify-center gap-2 rounded-2xl font-semibold",
    size === "lg" ? "min-h-14 px-5 text-lg" : "min-h-11 px-4 text-base",
    variant === "primary" && "bg-primary text-primary-fg",
    variant === "surface" && "border border-line bg-surface text-ink",
    variant === "ghost" && "bg-transparent text-ink",
    variant === "danger" && "bg-expense text-primary-fg",
    className,
  );
}

export function Button({
  variant = "primary",
  size = "md",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: Size }) {
  return <button type={type} className={buttonClass(variant, size, className)} {...props} />;
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <section className={cn("rounded-2xl border border-line bg-surface p-5", className)}>{children}</section>;
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="flex min-w-0 flex-col gap-2">
      <span className="text-sm font-medium text-ink">{label}</span>
      {children}
      {hint ? <span className="text-sm leading-snug text-muted">{hint}</span> : null}
    </label>
  );
}

export function Chip({
  pressed,
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { pressed?: boolean }) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      className={cn(
        "min-h-11 rounded-full border px-4 text-base",
        pressed ? "border-primary bg-primary text-primary-fg" : "border-line bg-surface text-ink",
        className,
      )}
      {...props}
    />
  );
}

export function PageIntro({
  eyebrow,
  title,
  text,
}: {
  eyebrow?: string;
  title: string;
  text?: string;
}) {
  return (
    <header className="mb-6">
      {eyebrow ? <p className="mb-1 text-sm font-medium text-muted">{eyebrow}</p> : null}
      <h1 className="font-display text-4xl leading-tight tracking-tight">{title}</h1>
      {text ? <p className="mt-2 max-w-prose text-base leading-relaxed text-muted">{text}</p> : null}
    </header>
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-3 flex items-end justify-between gap-3">
      <h2 className="text-lg font-semibold">{children}</h2>
      {action}
    </div>
  );
}

export function Money({ value, digits = "auto" }: { value: number; digits?: 0 | 2 | "auto" }) {
  return <span className="tabular-nums">{formatTRY(value, digits)}</span>;
}

export function toneClass(n: number): string {
  if (n > 0) return "text-primary";
  if (n < 0) return "text-expense";
  return "text-ink";
}

export function GoalBar({
  label,
  value,
  goal,
}: {
  label: string;
  value: number;
  goal: number | null;
}) {
  if (goal == null || goal <= 0) return null;
  const pct = (value / goal) * 100;
  const width = Math.max(0, Math.min(100, pct));
  const left = goal - value;
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between gap-3 text-sm">
        <span className="text-muted">{label}</span>
        <span className="tabular-nums text-ink">
          {formatTRY(value, 0)} / {formatTRY(goal, 0)}
        </span>
      </div>
      <div
        className="h-2 overflow-hidden rounded-full bg-surface-2"
        role="progressbar"
        aria-valuenow={Math.round(width)}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label}
      >
        <div className="bar-fill h-full rounded-full bg-primary" style={{ width: `${width}%` }} />
      </div>
      <p className="mt-2 text-sm text-muted">{left > 0 ? `${formatTRY(left, 0)} kaldı` : "Hedef geçildi"}</p>
    </div>
  );
}

export function ConfirmDelete({ onConfirm, label = "Sil" }: { onConfirm: () => void; label?: string }) {
  const [open, setOpen] = useState(false);
  if (!open) {
    return (
      <button type="button" className="text-sm text-muted" onClick={() => setOpen(true)}>
        {label}
      </button>
    );
  }
  return (
    <span className="flex items-center gap-3 text-sm">
      <button type="button" className="font-semibold text-expense" onClick={onConfirm}>
        Evet, sil
      </button>
      <button type="button" className="text-muted" onClick={() => setOpen(false)}>
        Vazgeç
      </button>
    </span>
  );
}

export function ErrorNote({ children }: { children: ReactNode }) {
  if (!children) return null;
  return (
    <p role="alert" className="text-sm text-expense">
      {children}
    </p>
  );
}
