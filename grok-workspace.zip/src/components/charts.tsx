import { useEffect, useState } from "react";
import { Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Slice } from "@/lib/calc";
import { formatAxis, formatTRY } from "@/lib/format";

const FILLS = ["var(--chart-0)", "var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)"];

function useReducedMotion() {
  const [reduce, setReduce] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduce(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  return reduce;
}

type TipPayload = { value?: number; name?: string };

function Tip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: TipPayload[];
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-line bg-surface px-3 py-2 text-sm">
      {label ? <p className="text-muted">{label}</p> : null}
      {payload.map((item) => (
        <p key={item.name ?? "v"} className="font-medium tabular-nums">
          {item.name ? `${item.name}: ` : ""}
          {formatTRY(Number(item.value ?? 0), 0)}
        </p>
      ))}
    </div>
  );
}

export function SplitPies({ earn, spend }: { earn: Slice[]; spend: Slice[] }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <PieBlock title="Platformlar" slices={earn} empty="Bu aralıkta kazanç yok." />
      <PieBlock title="Giderler" slices={spend} empty="Bu aralıkta gider yok." />
    </div>
  );
}

function PieBlock({ title, slices, empty }: { title: string; slices: Slice[]; empty: string }) {
  const reduce = useReducedMotion();
  const total = slices.reduce((s, x) => s + x.value, 0);
  return (
    <section className="rounded-2xl border border-line bg-surface p-5">
      <h2 className="text-lg font-semibold">{title}</h2>
      {slices.length === 0 ? (
        <p className="mt-4 text-sm text-muted">{empty}</p>
      ) : (
        <>
          <div className="mx-auto h-48 w-full max-w-xs">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={slices}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={48}
                  outerRadius={72}
                  paddingAngle={2}
                  stroke="none"
                  isAnimationActive={!reduce}
                >
                  {slices.map((slice, i) => (
                    <Cell key={slice.name} fill={FILLS[i % FILLS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<Tip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <ul className="mt-2 flex flex-col gap-2">
            {slices.map((slice, i) => (
              <li key={slice.name} className="flex items-center justify-between gap-3 text-sm">
                <span className="flex min-w-0 items-center gap-2">
                  <span className="size-2.5 shrink-0 rounded-full" style={{ background: FILLS[i % FILLS.length] }} />
                  <span className="truncate">{slice.name}</span>
                </span>
                <span className="shrink-0 tabular-nums">
                  {formatTRY(slice.value, 0)}
                  <span className="text-muted"> · {total > 0 ? Math.round((slice.value / total) * 100) : 0}%</span>
                </span>
              </li>
            ))}
          </ul>
        </>
      )}
    </section>
  );
}

export function NetLine({ points }: { points: { label: string; net: number }[] }) {
  const reduce = useReducedMotion();
  const has = points.some((p) => p.net !== 0);
  return (
    <section className="rounded-2xl border border-line bg-surface p-5">
      <h2 className="text-lg font-semibold">Net akış</h2>
      {!has ? (
        <p className="mt-4 text-sm text-muted">Bu aralıkta hareket yok.</p>
      ) : (
        <div className="mt-4 h-56 w-full min-w-0">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={points} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <XAxis
                dataKey="label"
                tick={{ fill: "var(--muted)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                minTickGap={20}
              />
              <YAxis
                tick={{ fill: "var(--muted)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                width={64}
                tickFormatter={formatAxis}
              />
              <Tooltip content={<Tip />} />
              <Line
                type="monotone"
                dataKey="net"
                name="Net"
                stroke="var(--primary)"
                strokeWidth={2.5}
                dot={false}
                isAnimationActive={!reduce}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </section>
  );
}
