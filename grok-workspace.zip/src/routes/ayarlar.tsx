import { useRef, useState, type ChangeEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { taxAmount, totalsBetween } from "@/lib/calc";
import { monthBounds, todayISO } from "@/lib/dates";
import { downloadBackup, downloadCsvFile, downloadXlsFile } from "@/lib/export";
import { amountToInput, formatTRY, parseAmount } from "@/lib/format";
import { snapshot, useLedger } from "@/lib/store";
import type { TaxBase, ThemeMode } from "@/lib/types";
import { Button, Card, Chip, ErrorNote, Field, PageIntro } from "@/components/ui";

export const Route = createFileRoute("/ayarlar")({ component: AyarlarPage });

const THEMES: { id: ThemeMode; label: string }[] = [
  { id: "system", label: "Sistem" },
  { id: "light", label: "Aydınlık" },
  { id: "dark", label: "Karanlık" },
];

function AyarlarPage() {
  const settings = useLedger((s) => s.settings);
  const setSettings = useLedger((s) => s.setSettings);
  const platforms = useLedger((s) => s.platforms);
  const earnings = useLedger((s) => s.earnings);
  const expenses = useLedger((s) => s.expenses);
  const vehicles = useLedger((s) => s.vehicles);
  const addPlatform = useLedger((s) => s.addPlatform);
  const renamePlatform = useLedger((s) => s.renamePlatform);
  const archivePlatform = useLedger((s) => s.archivePlatform);
  const restorePlatform = useLedger((s) => s.restorePlatform);
  const loadSample = useLedger((s) => s.loadSample);
  const resetData = useLedger((s) => s.resetData);
  const importBackup = useLedger((s) => s.importBackup);

  const fileRef = useRef<HTMLInputElement>(null);
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [rate, setRate] = useState(settings.taxRate ? amountToInput(settings.taxRate) : "");
  const [confirmSample, setConfirmSample] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const today = todayISO();
  const month = monthBounds(today);
  const totals = totalsBetween(earnings, expenses, month.from, month.to);
  const tax = taxAmount(totals.earn, totals.net, settings.taxRate, settings.taxBase);
  const hasData = earnings.length + expenses.length + vehicles.length > 0;
  const active = platforms.filter((p) => !p.archived);
  const archived = platforms.filter((p) => p.archived);

  function applyRate(raw: string, base: TaxBase = settings.taxBase) {
    setRate(raw);
    if (!raw.trim()) {
      setSettings({ taxRate: 0, taxBase: base });
      return;
    }
    const n = parseAmount(raw);
    if (n == null || n > 100) return;
    setSettings({ taxRate: n, taxBase: base });
  }

  function exportRange(kind: "csv" | "xls") {
    const dates = [...earnings, ...expenses].map((r) => r.date).sort();
    if (dates.length === 0) {
      toast.error("Dışa aktarılacak kayıt yok");
      return;
    }
    const data = snapshot();
    const from = dates[0] ?? today;
    const to = dates[dates.length - 1] ?? today;
    if (kind === "csv") downloadCsvFile(data, from, to);
    else downloadXlsFile(data, from, to);
  }

  function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const json: unknown = JSON.parse(String(reader.result));
        if (!importBackup(json)) toast.error("Bu dosya Tur Defteri yedeği değil");
        else {
          const next = useLedger.getState().settings.taxRate;
          setRate(next ? amountToInput(next) : "");
          toast.success("Yedek geri yüklendi");
        }
      } catch {
        toast.error("Dosya okunamadı");
      }
    };
    reader.readAsText(file);
  }

  return (
    <div className="flex flex-col gap-6">
      <PageIntro
        title="Ayarlar"
        text="Her şey bu cihazda kalır. Uygulamayı veya site verisini silersen kayıtlar da gider; arada bir yedek indir."
      />
      <Link to="/diger" className="text-sm font-medium text-muted">
        ← Diğer
      </Link>

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold">Görünüm</h2>
        <div className="grid grid-cols-3 gap-1 rounded-2xl bg-surface-2 p-1">
          {THEMES.map((item) => (
            <button
              key={item.id}
              type="button"
              className={
                settings.theme === item.id
                  ? "min-h-11 rounded-xl bg-surface text-sm font-semibold text-ink"
                  : "min-h-11 rounded-xl text-sm font-medium text-muted"
              }
              onClick={() => setSettings({ theme: item.id })}
            >
              {item.label}
            </button>
          ))}
        </div>
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold">Stopaj yardımcısı</h2>
        <p className="text-sm text-muted">Yüzde gir, bu ayın tahmini kesintisini gör. Beyanname yerine geçmez.</p>
        <Field label="Oran (%)">
          <input
            className="field"
            inputMode="decimal"
            placeholder="20"
            value={rate}
            onChange={(e) => applyRate(e.target.value)}
          />
        </Field>
        <div className="flex flex-wrap gap-2">
          {(
            [
              ["brut", "Brüt kazanç"],
              ["net", "Net kâr"],
            ] as const
          ).map(([id, label]) => (
            <Chip key={id} pressed={settings.taxBase === id} onClick={() => applyRate(rate, id)}>
              {label}
            </Chip>
          ))}
        </div>
        <Card>
          <p className="text-sm text-muted">Bu ay tahmini stopaj</p>
          <p className="mt-1 font-display text-3xl tabular-nums">{tax == null ? "—" : formatTRY(tax, 2)}</p>
          <p className="mt-2 text-sm text-muted">
            Matrah {settings.taxBase === "brut" ? formatTRY(totals.earn, 0) : formatTRY(Math.max(0, totals.net), 0)}
          </p>
        </Card>
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold">Platformlar</h2>
        <ul className="flex flex-col gap-2">
          {active.map((p) => (
            <li key={p.id} className="flex flex-col gap-2 rounded-2xl border border-line bg-surface p-3 sm:flex-row sm:items-center">
              <input
                className="field sm:flex-1"
                defaultValue={p.name}
                maxLength={40}
                key={`${p.id}-${p.name}`}
                aria-label={`${p.name} adı`}
                onBlur={(e) => {
                  const next = e.target.value;
                  if (next.trim() === p.name) return;
                  if (!renamePlatform(p.id, next)) {
                    e.target.value = p.name;
                    setError("Bu isim kullanılıyor veya boş.");
                  } else setError("");
                }}
              />
              <Button variant="ghost" onClick={() => archivePlatform(p.id)}>
                Gizle
              </Button>
            </li>
          ))}
        </ul>
        {archived.length > 0 ? (
          <div className="flex flex-col gap-2">
            <p className="text-sm text-muted">Gizli</p>
            {archived.map((p) => (
              <div key={p.id} className="flex items-center justify-between gap-3 text-sm">
                <span>{p.name}</span>
                <button type="button" className="font-medium text-primary" onClick={() => restorePlatform(p.id)}>
                  Geri al
                </button>
              </div>
            ))}
          </div>
        ) : null}
        <div className="flex flex-col gap-2 sm:flex-row">
          <input
            className="field sm:flex-1"
            placeholder="Yeni platform"
            maxLength={40}
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <Button
            onClick={() => {
              const result = addPlatform(name);
              if (!result.ok) setError(result.message);
              else {
                setName("");
                setError("");
              }
            }}
          >
            Ekle
          </Button>
        </div>
        <ErrorNote>{error}</ErrorNote>
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold">Dışa aktarma ve yedek</h2>
        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
          <Button variant="surface" onClick={() => exportRange("csv")}>
            Tüm kayıtlar CSV
          </Button>
          <Button variant="surface" onClick={() => exportRange("xls")}>
            Tüm kayıtlar Excel
          </Button>
          <Button variant="surface" onClick={() => downloadBackup(snapshot())}>
            Yedek indir
          </Button>
          <Button variant="surface" onClick={() => fileRef.current?.click()}>
            Yedekten yükle
          </Button>
        </div>
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={onFile} />
        <p className="text-sm text-muted">
          CSV, Türkçe Excel için noktalı virgül kullanır. PDF için Rapor ekranında yazdır. Yedek yüklemek bu cihazdaki
          defterin yerine geçer.
        </p>
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold">Veri</h2>
        {confirmSample ? (
          <Card>
            <p>Örnek hafta, şu anki kazanç, gider, araç ve hedeflerin yerine geçer.</p>
            <div className="mt-3 flex gap-2">
              <Button
                onClick={() => {
                  loadSample();
                  setConfirmSample(false);
                  toast.success("Örnek hafta yüklendi");
                }}
              >
                Yükle
              </Button>
              <Button variant="ghost" onClick={() => setConfirmSample(false)}>
                Vazgeç
              </Button>
            </div>
          </Card>
        ) : (
          <Button
            variant="surface"
            onClick={() => {
              if (hasData) setConfirmSample(true);
              else {
                loadSample();
                toast.success("Örnek hafta yüklendi");
              }
            }}
          >
            Örnek haftayı yükle
          </Button>
        )}
        {confirmReset ? (
          <Card>
            <p>Kazanç, gider, araç, hedef ve platformlar silinir. Tema ayarın kalır.</p>
            <div className="mt-3 flex gap-2">
              <Button
                variant="danger"
                onClick={() => {
                  resetData();
                  setConfirmReset(false);
                  toast.success("Kayıtlar silindi");
                }}
              >
                Evet, sil
              </Button>
              <Button variant="ghost" onClick={() => setConfirmReset(false)}>
                Vazgeç
              </Button>
            </div>
          </Card>
        ) : (
          <Button variant="ghost" onClick={() => setConfirmReset(true)}>
            Tüm kayıtları sil
          </Button>
        )}
      </section>
    </div>
  );
}
