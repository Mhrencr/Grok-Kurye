import { useMemo } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import {
  calendarAvg,
  dueLabel,
  monthMessage,
  totalsBetween,
  upcomingMaintenance,
} from "@/lib/calc";
import {
  formatLong,
  formatShort,
  formatWeekday,
  lastDays,
  monthBounds,
  monthProgress,
  todayISO,
  weekBounds,
} from "@/lib/dates";
import { formatTRY } from "@/lib/format";
import { useLedger } from "@/lib/store";
import { maintLabel } from "@/lib/types";
import { buttonClass, Card, GoalBar, toneClass } from "@/components/ui";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const earnings = useLedger((s) => s.earnings);
  const expenses = useLedger((s) => s.expenses);
  const goals = useLedger((s) => s.goals);
  const closedDays = useLedger((s) => s.closedDays);
  const vehicles = useLedger((s) => s.vehicles);
  const maintenance = useLedger((s) => s.maintenance);
  const loadSample = useLedger((s) => s.loadSample);

  const model = useMemo(() => {
    const today = todayISO();
    const week = weekBounds(today);
    const month = monthBounds(today);
    const monthTotals = totalsBetween(earnings, expenses, month.from, month.to);
    const progress = monthProgress(today);
    const pct = goals.monthly && goals.monthly > 0 ? (monthTotals.net / goals.monthly) * 100 : null;
    return {
      today,
      week,
      month,
      todayTotals: totalsBetween(earnings, expenses, today, today),
      weekTotals: totalsBetween(earnings, expenses, week.from, week.to),
      monthTotals,
      days: lastDays(today, 7)
        .map((date) => ({
          date,
          totals: totalsBetween(earnings, expenses, date, date),
          closed: closedDays.includes(date),
        }))
        .reverse(),
      reminders: upcomingMaintenance(maintenance, today).slice(0, 3),
      message: pct == null ? null : monthMessage(pct, progress.late),
      weekAvg: calendarAvg(
        totalsBetween(earnings, expenses, week.from, week.to).net,
        week.from,
        week.to,
      ),
    };
  }, [earnings, expenses, closedDays, maintenance, goals.monthly]);

  const empty = earnings.length === 0 && expenses.length === 0;
  const todayClosed = closedDays.includes(model.today);

  return (
    <div className="flex flex-col gap-5">
      <header>
        <p className="text-sm font-medium text-muted">{formatLong(model.today)}</p>
        <h1 className="mt-1 font-display text-4xl tracking-tight">Gün sonu</h1>
        <p className="mt-2 text-muted">Kasa evde kapanır. Yolda bir şey yazmana gerek yok.</p>
      </header>

      <Link to="/gun" search={{ tarih: model.today }} className={buttonClass("primary", "lg", "w-full")}>
        Bugünün kayıtlarını gir
      </Link>
      {todayClosed ? <p className="text-center text-sm text-muted">Bugün deftere işlendi. İstersen düzenlersin.</p> : null}

      <Card>
        <p className="text-sm text-muted">Bugünün neti</p>
        <p className={`mt-1 font-display text-5xl tabular-nums tracking-tight ${toneClass(model.todayTotals.net)}`}>
          {formatTRY(model.todayTotals.net, 0)}
        </p>
        <p className="mt-3 text-sm text-muted">
          Kazanç {formatTRY(model.todayTotals.earn, 0)} · Gider {formatTRY(model.todayTotals.spend, 0)}
          {model.todayTotals.tip > 0 ? ` · Bahşiş ${formatTRY(model.todayTotals.tip, 0)}` : ""}
          {model.todayTotals.trips > 0 ? ` · ${model.todayTotals.trips} tur` : ""}
        </p>
        <div className="mt-4">
          <GoalBar label="Günlük hedef" value={model.todayTotals.net} goal={goals.daily} />
        </div>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2">
        <Card>
          <p className="text-sm text-muted">Bu hafta</p>
          <p className={`mt-1 font-display text-3xl tabular-nums ${toneClass(model.weekTotals.net)}`}>
            {formatTRY(model.weekTotals.net, 0)}
          </p>
          <p className="mt-2 text-sm text-muted">
            Kazanç {formatTRY(model.weekTotals.earn, 0)}
            <br />
            Gider {formatTRY(model.weekTotals.spend, 0)}
          </p>
          <div className="mt-4">
            <GoalBar label="Haftalık hedef" value={model.weekTotals.net} goal={goals.weekly} />
          </div>
        </Card>
        <Card>
          <p className="text-sm text-muted">Bu ay</p>
          <p className={`mt-1 font-display text-3xl tabular-nums ${toneClass(model.monthTotals.net)}`}>
            {formatTRY(model.monthTotals.net, 0)}
          </p>
          <p className="mt-2 text-sm text-muted">
            Kazanç {formatTRY(model.monthTotals.earn, 0)}
            <br />
            Gider {formatTRY(model.monthTotals.spend, 0)}
          </p>
          <div className="mt-4">
            <GoalBar label="Aylık hedef" value={model.monthTotals.net} goal={goals.monthly} />
          </div>
          {model.message ? <p className="mt-3 text-sm leading-relaxed text-ink">{model.message}</p> : null}
        </Card>
      </div>

      {!goals.daily && !goals.weekly && !goals.monthly ? (
        <Link to="/hedef" className="text-sm font-semibold text-primary">
          Net kazanç hedefi koy
        </Link>
      ) : null}

      {model.reminders.length > 0 ? (
        <div className="flex flex-col gap-2">
          {model.reminders.map((item) => {
            const vehicle = vehicles.find((v) => v.id === item.vehicleId);
            return (
              <Link key={item.id} to="/arac" className="rounded-2xl border border-line bg-surface px-4 py-3">
                <p className="text-sm text-muted">{vehicle?.plate ?? "Araç"}</p>
                <p className="font-medium">{maintLabel(item.kind)}</p>
                <p className={item.days < 0 ? "text-sm text-expense" : "text-sm text-muted"}>{dueLabel(item.days)}</p>
              </Link>
            );
          })}
        </div>
      ) : null}

      <section>
        <h2 className="mb-3 text-lg font-semibold">Son 7 gün</h2>
        <Card className="px-4 py-1">
          <ul>
            {model.days.map((day) => {
              const quiet = day.totals.earn === 0 && day.totals.spend === 0;
              return (
                <li key={day.date} className="border-t border-line first:border-t-0">
                  <Link to="/gun" search={{ tarih: day.date }} className="flex items-center gap-3 py-3">
                    <div className="w-14 shrink-0">
                      <p className="text-xs text-muted">{formatWeekday(day.date)}</p>
                      <p className="text-sm font-medium">{formatShort(day.date)}</p>
                    </div>
                    <div className="min-w-0 flex-1">
                      {quiet ? (
                        <p className="text-sm text-muted">Kayıt yok</p>
                      ) : (
                        <p className="truncate text-sm text-muted">
                          {formatTRY(day.totals.earn, 0)} kazanç · {formatTRY(day.totals.spend, 0)} gider
                        </p>
                      )}
                    </div>
                    {day.closed ? <Check className="size-4 shrink-0 text-primary" aria-label="Kaydedildi" /> : null}
                    <p className={`shrink-0 font-display text-xl tabular-nums ${toneClass(quiet ? 0 : day.totals.net)}`}>
                      {quiet ? "—" : formatTRY(day.totals.net, 0)}
                    </p>
                  </Link>
                </li>
              );
            })}
          </ul>
        </Card>
      </section>

      {empty ? (
        <Card>
          <h2 className="font-display text-2xl">Defter boş</h2>
          <p className="mt-2 text-muted">
            İlk gününü kendin yazabilir ya da ekranların nasıl dolduğunu görmek için örnek bir hafta yükleyebilirsin.
          </p>
          <button type="button" className={`${buttonClass("surface", "md")} mt-4`} onClick={loadSample}>
            Örnek haftayı yükle
          </button>
        </Card>
      ) : null}

      {model.weekAvg != null && model.weekTotals.daysActive > 0 ? (
        <p className="text-sm text-muted">
          Bu hafta takvim ortalaması {formatTRY(model.weekAvg, 0)} / gün. Çalıştığın{" "}
          {model.weekTotals.daysActive} günün ortalaması {formatTRY(model.weekTotals.avgNet ?? 0, 0)}.
        </p>
      ) : null}
    </div>
  );
}
