import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { dueLabel, vehicleFuelStats } from "@/lib/calc";
import { daysBetween, formatShort, todayISO } from "@/lib/dates";
import { amountToInput, formatKm, formatNum, formatTRY, parseAmount, parseIntish } from "@/lib/format";
import { uid, useLedger } from "@/lib/store";
import { MAINT_KINDS, maintLabel, type MaintenanceKind } from "@/lib/types";
import { Button, Card, Chip, ConfirmDelete, ErrorNote, Field, PageIntro } from "@/components/ui";

export const Route = createFileRoute("/arac")({ component: AracPage });

function AracPage() {
  const vehicles = useLedger((s) => s.vehicles);
  const expenses = useLedger((s) => s.expenses);
  const maintenance = useLedger((s) => s.maintenance);
  const addVehicle = useLedger((s) => s.addVehicle);
  const updateVehicle = useLedger((s) => s.updateVehicle);
  const deleteVehicle = useLedger((s) => s.deleteVehicle);
  const addExpense = useLedger((s) => s.addExpense);
  const addMaintenance = useLedger((s) => s.addMaintenance);
  const toggleMaintenance = useLedger((s) => s.toggleMaintenance);
  const deleteMaintenance = useLedger((s) => s.deleteMaintenance);

  const [selected, setSelected] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const current = vehicles.find((v) => v.id === selected) ?? vehicles[0] ?? null;

  return (
    <div className="flex flex-col gap-6">
      <PageIntro
        eyebrow="Çoklu araç"
        title="Araç ve yakıt"
        text="Yakıt alımı gider olarak düşer. Sayaç yazarsan gerçek tüketim, yazmazsan beyan ettiğin litre/100 km kullanılır."
      />

      <Link to="/diger" className="text-sm font-medium text-muted">
        ← Diğer
      </Link>

      {vehicles.length > 0 ? (
        <div className="flex flex-wrap gap-2">
          {vehicles.map((v) => (
            <Chip key={v.id} pressed={current?.id === v.id} onClick={() => setSelected(v.id)}>
              {v.plate}
            </Chip>
          ))}
        </div>
      ) : null}

      {vehicles.length === 0 || showForm ? (
        <VehicleForm
          onDone={() => setShowForm(false)}
          onCreate={(row) => {
            addVehicle(row);
            setSelected(row.id);
            setShowForm(false);
          }}
        />
      ) : (
        <Button variant="surface" onClick={() => setShowForm(true)}>
          Araç ekle
        </Button>
      )}

      {current ? (
        <VehicleDetail
          vehicle={current}
          expenses={expenses}
          maintenance={maintenance.filter((m) => m.vehicleId === current.id)}
          onSave={(patch) => updateVehicle(current.id, patch)}
          onDelete={() => {
            const ok = deleteVehicle(current.id);
            if (!ok) toast.error("Bu araca bağlı gider veya hatırlatma var. Önce onları sil.");
            else setSelected(null);
          }}
          onFuel={(row) => {
            addExpense(row);
            toast.success("Yakıt gider olarak kaydedildi");
          }}
          onRemind={(row) => addMaintenance(row)}
          onToggle={toggleMaintenance}
          onDeleteRemind={deleteMaintenance}
        />
      ) : (
        <p className="text-sm text-muted">Km maliyeti için önce aracı yaz.</p>
      )}
    </div>
  );
}

function VehicleForm({
  onCreate,
  onDone,
}: {
  onCreate: (row: { id: string; brand: string; model: string; plate: string; consumption: number }) => void;
  onDone: () => void;
}) {
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [plate, setPlate] = useState("");
  const [cons, setCons] = useState("");
  const [error, setError] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!brand.trim() || !model.trim() || !plate.trim()) {
      setError("Marka, model ve plaka gerekli.");
      return;
    }
    const consumption = parseAmount(cons);
    if (consumption == null || consumption <= 0 || consumption > 40) {
      setError("Tüketimi 100 km'de litre olarak yaz. Örneğin 2,8.");
      return;
    }
    onCreate({
      id: uid(),
      brand: brand.trim(),
      model: model.trim(),
      plate: plate.trim().toLocaleUpperCase("tr"),
      consumption,
    });
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Marka">
          <input className="field" value={brand} maxLength={40} onChange={(e) => setBrand(e.target.value)} />
        </Field>
        <Field label="Model">
          <input className="field" value={model} maxLength={40} onChange={(e) => setModel(e.target.value)} />
        </Field>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Plaka">
          <input className="field" value={plate} maxLength={16} onChange={(e) => setPlate(e.target.value)} />
        </Field>
        <Field label="Ortalama tüketim" hint="Litre / 100 km">
          <input
            className="field"
            inputMode="decimal"
            placeholder="2,8"
            value={cons}
            onChange={(e) => setCons(e.target.value)}
          />
        </Field>
      </div>
      <ErrorNote>{error}</ErrorNote>
      <div className="flex gap-2">
        <Button type="submit" size="lg">
          Aracı kaydet
        </Button>
        <Button type="button" variant="ghost" size="lg" onClick={onDone}>
          Vazgeç
        </Button>
      </div>
    </form>
  );
}

function VehicleDetail({
  vehicle,
  expenses,
  maintenance,
  onSave,
  onDelete,
  onFuel,
  onRemind,
  onToggle,
  onDeleteRemind,
}: {
  vehicle: {
    id: string;
    brand: string;
    model: string;
    plate: string;
    consumption: number;
  };
  expenses: ReturnType<typeof useLedger.getState>["expenses"];
  maintenance: ReturnType<typeof useLedger.getState>["maintenance"];
  onSave: (patch: { brand: string; model: string; plate: string; consumption: number }) => void;
  onDelete: () => void;
  onFuel: (row: ReturnType<typeof useLedger.getState>["expenses"][number]) => void;
  onRemind: (row: ReturnType<typeof useLedger.getState>["maintenance"][number]) => void;
  onToggle: (id: string) => void;
  onDeleteRemind: (id: string) => void;
}) {
  const stats = vehicleFuelStats(vehicle, expenses);
  const [cons, setCons] = useState(amountToInput(vehicle.consumption));
  const [error, setError] = useState("");
  const today = todayISO();
  const open = maintenance.filter((m) => !m.done).sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  const done = maintenance.filter((m) => m.done);
  const fuels = expenses
    .filter((e) => e.category === "yakit" && e.vehicleId === vehicle.id)
    .sort((a, b) => (a.date < b.date ? 1 : -1));

  return (
    <div className="flex flex-col gap-5">
      <Card>
        <p className="text-sm text-muted">
          {vehicle.brand} {vehicle.model}
        </p>
        <h2 className="font-display text-3xl tracking-tight">{vehicle.plate}</h2>
        <dl className="mt-4 grid grid-cols-2 gap-4">
          <Stat label="Ort. ₺/litre" value={stats.pricePerLiter != null ? formatTRY(stats.pricePerLiter, 2) : "—"} />
          <Stat label="₺ / km" value={stats.costPerKm != null ? formatTRY(stats.costPerKm, 2) : "—"} />
          <Stat
            label="Tüketim"
            value={
              stats.actualConsumption != null
                ? `${formatNum(stats.actualConsumption, 1)} L`
                : `${formatNum(vehicle.consumption, 1)} L`
            }
          />
          <Stat label="Kayıtlı km" value={stats.recordedKm != null ? formatKm(stats.recordedKm) : "—"} />
        </dl>
        <p className="mt-3 text-sm text-muted">
          {stats.actualConsumption != null
            ? `Sayaçlara göre ${formatNum(stats.actualConsumption, 1)} L / 100 km. Beyan ${formatNum(vehicle.consumption, 1)}.`
            : "İki yakıt alımına kilometre yazınca gerçek tüketim çıkar."}
          {stats.fills > 0 ? ` ${stats.fills} alım, ${formatNum(stats.liters, 1)} litre.` : ""}
        </p>
        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end">
          <Field label="Beyan tüketim (L/100 km)">
            <input className="field" inputMode="decimal" value={cons} onChange={(e) => setCons(e.target.value)} />
          </Field>
          <Button
            type="button"
            onClick={() => {
              const n = parseAmount(cons);
              if (n == null || n <= 0 || n > 40) {
                setError("2,8 gibi bir değer yaz.");
                return;
              }
              setError("");
              onSave({ ...vehicle, consumption: n });
              toast.success("Tüketim güncellendi");
            }}
          >
            Güncelle
          </Button>
        </div>
        <ErrorNote>{error}</ErrorNote>
        <div className="mt-3">
          <ConfirmDelete label="Aracı sil" onConfirm={onDelete} />
        </div>
      </Card>

      <FuelForm
        onSave={(fields) =>
          onFuel({
            id: uid(),
            date: fields.date,
            category: "yakit",
            amount: fields.amount,
            note: fields.note,
            liters: fields.liters,
            vehicleId: vehicle.id,
            odometer: fields.odometer,
          })
        }
      />

      <section>
        <h2 className="mb-3 text-lg font-semibold">Yakıt alımları</h2>
        {fuels.length === 0 ? (
          <p className="text-sm text-muted">Bu araç için yakıt yok. Yukarıdan veya gider ekranından ekle.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {fuels.map((row) => (
              <li key={row.id} className="flex items-center justify-between gap-3 rounded-2xl border border-line px-4 py-3">
                <div>
                  <p className="font-medium">{formatShort(row.date)}</p>
                  <p className="text-sm text-muted">
                    {row.liters ? `${formatNum(row.liters, 1)} L` : "Litre yok"}
                    {row.odometer != null ? ` · ${formatKm(row.odometer)}` : ""}
                    {row.note ? ` · ${row.note}` : ""}
                  </p>
                </div>
                <p className="tabular-nums">{formatTRY(row.amount, 0)}</p>
              </li>
            ))}
          </ul>
        )}
      </section>

      <RemindForm
        onSave={(fields) =>
          onRemind({
            id: uid(),
            vehicleId: vehicle.id,
            kind: fields.kind,
            dueDate: fields.dueDate,
            note: fields.note,
            done: false,
          })
        }
      />

      <section>
        <h2 className="mb-3 text-lg font-semibold">Hatırlatmalar</h2>
        {open.length === 0 ? <p className="text-sm text-muted">Açık hatırlatma yok.</p> : null}
        <ul className="flex flex-col gap-2">
          {open.map((item) => {
            const days = daysBetween(today, item.dueDate);
            return (
              <li key={item.id} className="rounded-2xl border border-line bg-surface px-4 py-3">
                <p className="font-medium">{maintLabel(item.kind)}</p>
                <p className={days < 0 ? "text-sm text-expense" : "text-sm text-muted"}>
                  {formatShort(item.dueDate)} · {dueLabel(days)}
                  {item.note ? ` · ${item.note}` : ""}
                </p>
                <div className="mt-2 flex gap-4">
                  <button type="button" className="text-sm font-medium text-primary" onClick={() => onToggle(item.id)}>
                    Tamamlandı
                  </button>
                  <ConfirmDelete onConfirm={() => onDeleteRemind(item.id)} />
                </div>
              </li>
            );
          })}
        </ul>
        {done.length > 0 ? (
          <ul className="mt-3 flex flex-col gap-2">
            {done.map((item) => (
              <li key={item.id} className="flex items-center justify-between gap-3 text-sm text-muted">
                <span>
                  {maintLabel(item.kind)} · {formatShort(item.dueDate)}
                </span>
                <button type="button" className="font-medium text-ink" onClick={() => onToggle(item.id)}>
                  Geri al
                </button>
              </li>
            ))}
          </ul>
        ) : null}
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-sm text-muted">{label}</dt>
      <dd className="font-display text-2xl tabular-nums">{value}</dd>
    </div>
  );
}

function FuelForm({
  onSave,
}: {
  onSave: (fields: { date: string; amount: number; liters: number | null; odometer: number | null; note: string }) => void;
}) {
  const [date, setDate] = useState(todayISO);
  const [amount, setAmount] = useState("");
  const [liters, setLiters] = useState("");
  const [odometer, setOdometer] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const amt = parseAmount(amount);
    if (amt == null || amt <= 0) {
      setError("Tutarı yaz.");
      return;
    }
    let literVal: number | null = null;
    if (liters.trim()) {
      literVal = parseAmount(liters);
      if (literVal == null || literVal <= 0) {
        setError("Litre geçersiz.");
        return;
      }
    }
    let odo: number | null = null;
    if (odometer.trim()) {
      odo = parseIntish(odometer);
      if (odo == null) {
        setError("Kilometre tam sayı olmalı.");
        return;
      }
    }
    onSave({ date, amount: amt, liters: literVal, odometer: odo, note });
    setAmount("");
    setLiters("");
    setOdometer("");
    setNote("");
    setError("");
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-4">
      <h2 className="text-lg font-semibold">Yakıt alımı</h2>
      <Field label="Tarih">
        <input className="field" type="date" value={date} onChange={(e) => setDate(e.target.value || todayISO())} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Tutar (₺)">
          <input className="field" inputMode="decimal" placeholder="0,00" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        <Field label="Litre">
          <input className="field" inputMode="decimal" placeholder="0,00" value={liters} onChange={(e) => setLiters(e.target.value)} />
        </Field>
      </div>
      <Field label="Kilometre sayacı" hint="İsteğe bağlı">
        <input className="field" inputMode="numeric" value={odometer} onChange={(e) => setOdometer(e.target.value)} />
      </Field>
      <Field label="Not">
        <input className="field" maxLength={280} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      <ErrorNote>{error}</ErrorNote>
      <Button type="submit" size="lg">
        Yakıtı kaydet
      </Button>
    </form>
  );
}

function RemindForm({
  onSave,
}: {
  onSave: (fields: { kind: MaintenanceKind; dueDate: string; note: string }) => void;
}) {
  const [kind, setKind] = useState<MaintenanceKind>("yag");
  const [dueDate, setDueDate] = useState(todayISO());
  const [note, setNote] = useState("");

  return (
    <form
      className="flex flex-col gap-4"
      onSubmit={(e) => {
        e.preventDefault();
        onSave({ kind, dueDate, note });
        setNote("");
        toast.success("Hatırlatma eklendi");
      }}
    >
      <h2 className="text-lg font-semibold">Bakım hatırlatması</h2>
      <p className="text-sm text-muted">Masrafı giderlere ayrıca yaz. Burası sadece tarihi tutar.</p>
      <div className="flex flex-wrap gap-2">
        {MAINT_KINDS.map((k) => (
          <Chip key={k.id} pressed={kind === k.id} onClick={() => setKind(k.id)}>
            {k.label}
          </Chip>
        ))}
      </div>
      <Field label="Tarih">
        <input className="field" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value || todayISO())} />
      </Field>
      <Field label="Not">
        <input className="field" maxLength={280} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      <Button type="submit">Hatırlatmayı kaydet</Button>
    </form>
  );
}
