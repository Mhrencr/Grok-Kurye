import { useEffect, useMemo, useState, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { totalsBetween } from "@/lib/calc";
import { dateSearch, formatShort, groupByDate, todayISO } from "@/lib/dates";
import { amountToInput, formatNum, formatTRY, parseAmount, parseIntish } from "@/lib/format";
import { uid, useLedger } from "@/lib/store";
import { CATEGORIES, categoryLabel, type Category, type Expense } from "@/lib/types";
import { Button, Card, Chip, ConfirmDelete, ErrorNote, Field, PageIntro } from "@/components/ui";

export const Route = createFileRoute("/gider")({
  validateSearch: dateSearch,
  component: GiderPage,
});

function GiderPage() {
  const { tarih } = Route.useSearch();
  const expenses = useLedger((s) => s.expenses);
  const earnings = useLedger((s) => s.earnings);
  const vehicles = useLedger((s) => s.vehicles);
  const addExpense = useLedger((s) => s.addExpense);
  const updateExpense = useLedger((s) => s.updateExpense);
  const deleteExpense = useLedger((s) => s.deleteExpense);

  const [date, setDate] = useState(() => tarih ?? todayISO());
  const [category, setCategory] = useState<Category | "">("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [liters, setLiters] = useState("");
  const [vehicleId, setVehicleId] = useState("");
  const [odometer, setOdometer] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [visibleGroups, setVisibleGroups] = useState(12);

  useEffect(() => {
    if (tarih) setDate(tarih);
  }, [tarih]);

  const groups = useMemo(() => groupByDate(expenses), [expenses]);
  const shown = groups.slice(0, visibleGroups);

  function reset(keepCategory = true) {
    setAmount("");
    setNote("");
    setLiters("");
    setOdometer("");
    setEditing(null);
    setError("");
    if (!keepCategory) setCategory("");
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!category) {
      setError("Bir kategori seç.");
      return;
    }
    const amt = parseAmount(amount);
    if (amt == null || amt <= 0) {
      setError("Tutar gir.");
      return;
    }
    let literVal: number | null = null;
    if (category === "yakit" && liters.trim()) {
      literVal = parseAmount(liters);
      if (literVal == null || literVal <= 0) {
        setError("Litre geçersiz.");
        return;
      }
    }
    let odo: number | null = null;
    if (category === "yakit" && odometer.trim()) {
      odo = parseIntish(odometer);
      if (odo == null) {
        setError("Kilometre tam sayı olmalı.");
        return;
      }
    }
    const patch = {
      date,
      category,
      amount: amt,
      note,
      liters: category === "yakit" ? literVal : null,
      vehicleId: category === "yakit" && vehicleId ? vehicleId : null,
      odometer: category === "yakit" ? odo : null,
    };
    if (editing) updateExpense(editing, patch);
    else addExpense({ id: uid(), ...patch });
    reset(true);
  }

  function startEdit(row: Expense) {
    setEditing(row.id);
    setDate(row.date);
    setCategory(row.category);
    setAmount(amountToInput(row.amount));
    setNote(row.note);
    setLiters(row.liters != null ? amountToInput(row.liters) : "");
    setVehicleId(row.vehicleId ?? "");
    setOdometer(row.odometer != null ? String(Math.round(row.odometer)) : "");
    setError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const amtN = parseAmount(amount);
  const literN = parseAmount(liters);
  const vehicle = vehicles.find((v) => v.id === vehicleId);
  const perLiter = amtN != null && literN != null && literN > 0 ? amtN / literN : null;
  const perKm =
    perLiter != null && vehicle && vehicle.consumption > 0 ? (perLiter * vehicle.consumption) / 100 : null;
  const dayNet = totalsBetween(earnings, expenses, date, date);

  return (
    <div className="flex flex-col gap-5">
      <PageIntro
        eyebrow={formatShort(date)}
        title="Gider"
        text="Yakıtta litreyi de yaz. Kilometre maliyeti, aracın tüketiminden hesaplanır."
      />

      <form onSubmit={onSubmit} className="flex flex-col gap-5">
        <Field label="Tarih">
          <input className="field" type="date" value={date} onChange={(e) => setDate(e.target.value || todayISO())} />
        </Field>

        <div>
          <p className="mb-2 text-sm font-medium">Kategori</p>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <Chip key={c.id} pressed={category === c.id} onClick={() => setCategory(c.id)}>
                {c.label}
              </Chip>
            ))}
          </div>
        </div>

        <Field label="Tutar (₺)">
          <input
            className="field"
            inputMode="decimal"
            autoComplete="off"
            placeholder="0,00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </Field>

        <Field label="Not">
          <input className="field" maxLength={280} value={note} onChange={(e) => setNote(e.target.value)} />
        </Field>

        {category === "yakit" ? (
          <Card className="flex flex-col gap-4 bg-surface-2">
            <Field label="Litre" hint="İsteğe bağlı. ₺/litre ve ₺/km için gerekli.">
              <input
                className="field"
                inputMode="decimal"
                placeholder="0,00"
                value={liters}
                onChange={(e) => setLiters(e.target.value)}
              />
            </Field>
            <div>
              <p className="mb-2 text-sm font-medium">Araç</p>
              {vehicles.length === 0 ? (
                <p className="text-sm text-muted">Araç seçmeden de kaydedilir. Km hesabı için Araç bölümünden ekle.</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {vehicles.map((v) => (
                    <Chip key={v.id} pressed={vehicleId === v.id} onClick={() => setVehicleId(v.id)}>
                      {v.plate}
                    </Chip>
                  ))}
                </div>
              )}
            </div>
            <Field label="Kilometre sayacı" hint="İsteğe bağlı. İki alım arasında gerçek tüketim çıkar.">
              <input
                className="field"
                inputMode="numeric"
                placeholder="45210"
                value={odometer}
                onChange={(e) => setOdometer(e.target.value)}
              />
            </Field>
            {perLiter != null ? (
              <p className="text-sm">
                <span className="tabular-nums font-medium">{formatTRY(perLiter, 2)}</span>
                <span className="text-muted"> / litre</span>
                {perKm != null ? (
                  <>
                    <span className="text-muted"> · tahmini </span>
                    <span className="tabular-nums font-medium">{formatTRY(perKm, 2)}</span>
                    <span className="text-muted"> / km ({formatNum(vehicle?.consumption ?? 0, 1)} L / 100 km)</span>
                  </>
                ) : null}
              </p>
            ) : null}
          </Card>
        ) : null}

        <ErrorNote>{error}</ErrorNote>
        <p className="text-sm text-muted">
          Bu günün neti şimdi <span className="tabular-nums text-ink">{formatTRY(dayNet.net, 0)}</span>.
        </p>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button type="submit" size="lg" className="sm:flex-1">
            {editing ? "Gideri güncelle" : "Gideri kaydet"}
          </Button>
          {editing ? (
            <Button type="button" variant="ghost" size="lg" onClick={() => reset(true)}>
              Vazgeç
            </Button>
          ) : null}
        </div>
      </form>

      <section>
        <h2 className="mb-3 text-lg font-semibold">Son giderler</h2>
        {shown.length === 0 ? (
          <p className="text-sm text-muted">Henüz gider yok.</p>
        ) : (
          <div className="flex flex-col gap-4">
            {shown.map((group) => (
              <div key={group.date}>
                <p className="mb-2 text-sm font-medium text-muted">{formatShort(group.date)}</p>
                <ul className="flex flex-col gap-2">
                  {group.items.map((row) => (
                    <li key={row.id} className="rounded-2xl border border-line bg-surface px-4 py-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="font-medium">{categoryLabel(row.category)}</p>
                          <p className="text-sm text-muted">
                            {row.note || "Not yok"}
                            {row.liters ? ` · ${formatNum(row.liters, 1)} L` : ""}
                          </p>
                        </div>
                        <p className="shrink-0 tabular-nums text-expense">{formatTRY(row.amount, 2)}</p>
                      </div>
                      <div className="mt-2 flex gap-4">
                        <button type="button" className="text-sm font-medium text-primary" onClick={() => startEdit(row)}>
                          Düzenle
                        </button>
                        <ConfirmDelete onConfirm={() => deleteExpense(row.id)} />
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
            {groups.length > shown.length ? (
              <Button variant="surface" onClick={() => setVisibleGroups((n) => n + 12)}>
                Daha eski giderler
              </Button>
            ) : null}
          </div>
        )}
      </section>
    </div>
  );
}
