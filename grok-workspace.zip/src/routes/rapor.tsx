import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { NetLine, SplitPies } from "@/components/charts";
import {
  calendarAvg,
  chartPoints,
  dayPoints,
  earningsByPlatform,
  expensesByCategory,
  periodKm,
  taxAmount,
  topEarningDays,
  totalsBetween,
  type DayPoint,
} from "@/lib/calc";
import { formatLong, formatShort, monthBounds, todayISO, weekBounds } from "@/lib/dates";
import { downloadCsvFile, downloadXlsFile } from "@/lib/export";
import { formatKm, formatTRY } from "@/lib/format";
import { snapshot, useLedger } from "@/lib/store";
import { categoryLabel } from "@/lib/types";
import { Button, Card, Chip, PageIntro, toneClass } from "@/components/ui";

export const Route = createFileRoute("/rapor")({ component: RaporPage });

type Preset = "gun" | "hafta" | "ay" | "ozel";

const PRESETS: { id: Preset; label: string }[] = [
  { id: "gun", label: "Gün" },
  { id: "hafta", label: "Hafta" },
  { id: "ay", label: "Ay" },
  { id: "ozel", label: "Özel" },
];

function RaporPage() {
  const earnings = useLedger((s) => s.earnings);
  const expenses = useLedger((s) => s.expenses);
  const platforms = useLedger((s) => s.platforms);
  const vehicles = useLedger((s) => s.vehicles);
  const settings = useLedger((s) => s.settings);

  const today = todayISO();
  const [preset, setPreset] = useState<Preset>("ay");
  const [customFrom, setCustomFrom] = useState(monthBounds(today).from);
  const [customTo, setCustomTo] = useState(today);

  const range = useMemo(() => {
    if (preset === "gun") return { from: today, to: today };
    if (preset === "hafta") return weekBounds(today);
    if (preset === "ay") return monthBounds(today);
    const from = customFrom <= customTo ? customFrom : customTo;
    const to = customFrom <= customTo ? customTo : customFrom;
    return { from, to };
  }, [preset, today, customFrom, customTo]);

  const model = useMemo(() => {
    const totals = totalsBetween(earnings, expenses, range.from, range.to);
    const points = dayPoints(earnings, expenses, range.from, range.to);
    const km = periodKm(expenses, vehicles, range.from, range.to);
    const kmBasis = km.recordedKm ?? km.estimatedKm;
    const perKm = kmBasis && kmBasis > 0 ? totals.net / kmBasis : null;
    return {
      totals,
      points,
      chart: chartPoints(points),
      platforms: earningsByPlatform(earnings, platforms, range.from, range.to),
      categories: expensesByCategory(expenses, range.from, range.to).map((s) => ({
        name: categoryLabel(s.name),
        value: s.value,
      })),
      top: topEarningDays(earnings, expenses, range.from, range.to),
      avgActive: totals.avgNet,
      avgCalendar: calendarAvg(totals.net, range.from, range.to),
      km,
      perKm,
      tax: taxAmount(totals.earn, totals.net, settings.taxRate, settings.taxBase),
    };
  }, [earnings, expenses, platforms, vehicles, range, settings.taxRate, settings.taxBase]);

  const table = model.points.length <= 62 ? model.points : model.chart;

  return (
    <div className="flex flex-col gap-5">
      <p className="show-print text-sm">
        Tur Defteri · {formatLong(range.from)} – {formatLong(range.to)}
      </p>
      <div className="no-print">
        <PageIntro
          eyebrow="İstatistik"
          title="Rapor"
          text="Gün, hafta, ay veya kendi aralığın. Rakamlar cihazındaki kayıtlardan gelir."
        />
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((item) => (
            <Chip key={item.id} pressed={preset === item.id} onClick={() => setPreset(item.id)}>
              {item.label}
            </Chip>
          ))}
        </div>
        {preset === "ozel" ? (
          <div className="mt-4 grid grid-cols-2 gap-3">
            <label className="flex flex-col gap-2 text-sm font-medium">
              Başlangıç
              <input className="field" type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} />
            </label>
            <label className="flex flex-col gap-2 text-sm font-medium">
              Bitiş
              <input className="field" type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)} />
            </label>
          </div>
        ) : (
          <p className="mt-3 text-sm text-muted">
            {formatShort(range.from)} – {formatShort(range.to)}
          </p>
        )}
      </div>

      <Card>
        <p className="text-sm text-muted">Net</p>
        <p className={`mt-1 font-display text-5xl tabular-nums tracking-tight ${toneClass(model.totals.net)}`}>
          {formatTRY(model.totals.net, 0)}
        </p>
        <div className="mt-4 grid grid-cols-3 gap-2 text-sm">
          <div>
            <p className="text-muted">Kazanç</p>
            <p className="tabular-nums font-medium">{formatTRY(model.totals.earn, 0)}</p>
          </div>
          <div>
            <p className="text-muted">Gider</p>
            <p className="tabular-nums font-medium text-expense">{formatTRY(model.totals.spend, 0)}</p>
          </div>
          <div>
            <p className="text-muted">Bahşiş</p>
            <p className="tabular-nums font-medium">{formatTRY(model.totals.tip, 0)}</p>
          </div>
        </div>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2">
        <Card>
          <p className="text-sm text-muted">Çalışılan gün ortalaması</p>
          <p className="mt-1 font-display text-3xl tabular-nums">
            {model.avgActive == null ? "—" : formatTRY(model.avgActive, 0)}
          </p>
          <p className="mt-2 text-sm text-muted">{model.totals.daysActive} gün kayıtlı</p>
        </Card>
        <Card>
          <p className="text-sm text-muted">Takvim günü ortalaması</p>
          <p className="mt-1 font-display text-3xl tabular-nums">
            {model.avgCalendar == null ? "—" : formatTRY(model.avgCalendar, 0)}
          </p>
          <p className="mt-2 text-sm text-muted">Boş günler dahil</p>
        </Card>
      </div>

      <SplitPies earn={model.platforms} spend={model.categories} />
      <NetLine points={model.chart} />
      {model.points.length > 45 ? (
        <p className="text-sm text-muted">Aralık uzun olduğu için çizgi grafik haftalara bölündü.</p>
      ) : null}

      <Card>
        <h2 className="text-lg font-semibold">Km başına net</h2>
        {model.perKm == null ? (
          <p className="mt-2 text-sm text-muted">
            Yakıt litresini ve araç tüketimini yazınca bu hesap açılır. Sayaç varsa kayıtlı kilometre kullanılır.
          </p>
        ) : (
          <>
            <p className={`mt-2 font-display text-4xl tabular-nums ${toneClass(model.perKm)}`}>
              {formatTRY(model.perKm, 2)}
            </p>
            <p className="mt-2 text-sm text-muted">
              {model.km.recordedKm != null
                ? `Kayıtlı ${formatKm(model.km.recordedKm)}`
                : `Tahmini ${formatKm(model.km.estimatedKm ?? 0)} (tüketimden)`}
            </p>
          </>
        )}
      </Card>

      <section>
        <h2 className="mb-3 text-lg font-semibold">En yüksek kazançlı günler</h2>
        {model.top.length === 0 ? (
          <p className="text-sm text-muted">Bu aralıkta kazanç yok.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {model.top.map((day) => (
              <li key={day.date} className="flex items-center justify-between rounded-2xl border border-line px-4 py-3">
                <span>{formatShort(day.date)}</span>
                <span className="text-right">
                  <span className="block tabular-nums font-medium">{formatTRY(day.earn, 0)}</span>
                  <span className={`block text-sm tabular-nums ${toneClass(day.net)}`}>net {formatTRY(day.net, 0)}</span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {model.tax != null ? (
        <Card>
          <h2 className="text-lg font-semibold">Tahmini stopaj</h2>
          <p className="mt-2 font-display text-3xl tabular-nums">{formatTRY(model.tax, 2)}</p>
          <p className="mt-2 text-sm text-muted">
            %{settings.taxRate.toLocaleString("tr-TR")} oran,{" "}
            {settings.taxBase === "brut" ? "brüt kazanç" : "net kâr"} üzerinden. Resmi hesap değildir.
          </p>
        </Card>
      ) : null}

      {model.totals.earn === 0 && model.totals.spend === 0 ? (
        <p className="text-sm text-muted">Bu aralıkta satır yok.</p>
      ) : (
        <DayTable rows={table} weekly={model.points.length > 62} />
      )}

      <div className="no-print flex flex-col gap-2 sm:flex-row">
        <Button
          variant="surface"
          onClick={() => downloadCsvFile(snapshot(), range.from, range.to)}
        >
          CSV indir
        </Button>
        <Button variant="surface" onClick={() => downloadXlsFile(snapshot(), range.from, range.to)}>
          Excel indir
        </Button>
        <Button variant="surface" onClick={() => window.print()}>
          PDF / yazdır
        </Button>
      </div>
    </div>
  );
}

function DayTable({ rows, weekly }: { rows: DayPoint[]; weekly: boolean }) {
  return (
    <section>
      <h2 className="mb-3 text-lg font-semibold">{weekly ? "Haftalık döküm" : "Gün gün"}</h2>
      <div className="overflow-x-auto rounded-2xl border border-line">
        <table className="w-full min-w-lg text-left text-sm">
          <thead className="bg-surface-2 text-muted">
            <tr>
              <th className="px-3 py-3 font-medium">Tarih</th>
              <th className="px-3 py-3 font-medium">Kazanç</th>
              <th className="px-3 py-3 font-medium">Gider</th>
              <th className="px-3 py-3 font-medium">Net</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.date + row.label} className="border-t border-line">
                <td className="px-3 py-3">{row.label}</td>
                <td className="px-3 py-3 tabular-nums">{formatTRY(row.earn, 0)}</td>
                <td className="px-3 py-3 tabular-nums">{formatTRY(row.spend, 0)}</td>
                <td className={`px-3 py-3 tabular-nums ${toneClass(row.net)}`}>{formatTRY(row.net, 0)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
