import { useMemo, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { monthMessage, totalsBetween } from "@/lib/calc";
import { monthBounds, monthProgress, todayISO, weekBounds } from "@/lib/dates";
import { amountToInput, formatTRY, parseAmount } from "@/lib/format";
import { useLedger } from "@/lib/store";
import { Button, Card, ErrorNote, Field, GoalBar, PageIntro } from "@/components/ui";

export const Route = createFileRoute("/hedef")({ component: HedefPage });

function HedefPage() {
  const goals = useLedger((s) => s.goals);
  const setGoals = useLedger((s) => s.setGoals);
  const earnings = useLedger((s) => s.earnings);
  const expenses = useLedger((s) => s.expenses);

  const [daily, setDaily] = useState(() => amountToInput(goals.daily));
  const [weekly, setWeekly] = useState(() => amountToInput(goals.weekly));
  const [monthly, setMonthly] = useState(() => amountToInput(goals.monthly));
  const [error, setError] = useState("");

  const today = todayISO();
  const actual = useMemo(() => {
    const week = weekBounds(today);
    const month = monthBounds(today);
    const monthTotals = totalsBetween(earnings, expenses, month.from, month.to);
    const progress = monthProgress(today);
    return {
      day: totalsBetween(earnings, expenses, today, today),
      week: totalsBetween(earnings, expenses, week.from, week.to),
      month: monthTotals,
      late: progress.late,
    };
  }, [earnings, expenses, today]);

  const pct =
    goals.monthly && goals.monthly > 0 ? (actual.month.net / goals.monthly) * 100 : null;

  function read(raw: string, label: string): number | null | "bad" {
    if (!raw.trim()) return null;
    const n = parseAmount(raw);
    if (n == null || n <= 0) {
      setError(`${label} hedefi geçersiz.`);
      return "bad";
    }
    return n;
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    const d = read(daily, "Günlük");
    if (d === "bad") return;
    const w = read(weekly, "Haftalık");
    if (w === "bad") return;
    const m = read(monthly, "Aylık");
    if (m === "bad") return;
    setGoals({ daily: d, weekly: w, monthly: m });
    setDaily(amountToInput(d));
    setWeekly(amountToInput(w));
    setMonthly(amountToInput(m));
    toast.success("Hedefler kaydedildi");
  }

  return (
    <div className="flex flex-col gap-5">
      <PageIntro
        eyebrow="Net kazanç"
        title="Hedef"
        text="Boş bırakırsan o dönem için hedef kalkar. Çubuklar net kâra bakar, brüte değil."
      />
      <Link to="/diger" className="text-sm font-medium text-muted">
        ← Diğer
      </Link>

      <form onSubmit={onSubmit} className="flex flex-col gap-4">
        <Field label="Günlük net (₺)" hint={`Bugün ${formatTRY(actual.day.net, 0)}`}>
          <input className="field" inputMode="decimal" placeholder="1200" value={daily} onChange={(e) => setDaily(e.target.value)} />
        </Field>
        <Field label="Haftalık net (₺)" hint={`Bu hafta ${formatTRY(actual.week.net, 0)}`}>
          <input className="field" inputMode="decimal" placeholder="7000" value={weekly} onChange={(e) => setWeekly(e.target.value)} />
        </Field>
        <Field label="Aylık net (₺)" hint={`Bu ay ${formatTRY(actual.month.net, 0)}`}>
          <input className="field" inputMode="decimal" placeholder="28000" value={monthly} onChange={(e) => setMonthly(e.target.value)} />
        </Field>
        <ErrorNote>{error}</ErrorNote>
        <Button type="submit" size="lg">
          Hedefleri kaydet
        </Button>
      </form>

      <Card className="flex flex-col gap-5">
        <GoalBar label="Bugün" value={actual.day.net} goal={goals.daily} />
        <GoalBar label="Bu hafta" value={actual.week.net} goal={goals.weekly} />
        <GoalBar label="Bu ay" value={actual.month.net} goal={goals.monthly} />
        {!goals.daily && !goals.weekly && !goals.monthly ? (
          <p className="text-sm text-muted">Kayıtlı hedef yok.</p>
        ) : null}
        {pct != null ? <p className="text-sm leading-relaxed">{monthMessage(pct, actual.late)}</p> : null}
      </Card>
    </div>
  );
}
