import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { totalsBetween } from "@/lib/calc";
import { dateSearch, formatLong } from "@/lib/dates";
import { amountToInput, formatTRY, parseAmount, parseIntish } from "@/lib/format";
import { uid, useLedger } from "@/lib/store";
import { categoryLabel, type Earning } from "@/lib/types";
import { Button, Card, Chip, ConfirmDelete, ErrorNote, Field, PageIntro, toneClass } from "@/components/ui";
import { todayISO } from "@/lib/dates";

export const Route = createFileRoute("/gun")({
  validateSearch: dateSearch,
  component: GunPage,
});

function GunPage() {
  const { tarih } = Route.useSearch();
  const earnings = useLedger((s) => s.earnings);
  const expenses = useLedger((s) => s.expenses);
  const platforms = useLedger((s) => s.platforms);
  const closedDays = useLedger((s) => s.closedDays);
  const addEarning = useLedger((s) => s.addEarning);
  const updateEarning = useLedger((s) => s.updateEarning);
  const deleteEarning = useLedger((s) => s.deleteEarning);
  const addPlatform = useLedger((s) => s.addPlatform);
  const closeDay = useLedger((s) => s.closeDay);
  const reopenDay = useLedger((s) => s.reopenDay);

  const [date, setDate] = useState(() => tarih ?? todayISO());
  const [platformId, setPlatformId] = useState("");
  const [amount, setAmount] = useState("");
  const [tip, setTip] = useState("");
  const [trips, setTrips] = useState("");
  const [note, setNote] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [addingPlatform, setAddingPlatform] = useState(false);
  const [newPlatform, setNewPlatform] = useState("");
  const [confirmEmpty, setConfirmEmpty] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (tarih) setDate(tarih);
  }, [tarih]);

  const activePlatforms = platforms.filter((p) => !p.archived || p.id === platformId);

  useEffect(() => {
    if (platformId) return;
    const first = platforms.find((p) => !p.archived);
    if (first) setPlatformId(first.id);
  }, [platformId, platforms]);

  const dayEarnings = useMemo(
    () => earnings.filter((e) => e.date === date),
    [earnings, date],
  );
  const dayExpenses = useMemo(
    () => expenses.filter((e) => e.date === date),
    [expenses, date],
  );
  const totals = useMemo(() => totalsBetween(earnings, expenses, date, date), [earnings, expenses, date]);
  const closed = closedDays.includes(date);

  function resetFields() {
    setAmount("");
    setTip("");
    setTrips("");
    setNote("");
    setEditing(null);
    setError("");
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!platformId) {
      setError("Önce bir platform seç veya ekle.");
      return;
    }
    if (amount.trim() && parseAmount(amount) == null) {
      setError("Kazanç tutarı geçersiz.");
      return;
    }
    if (tip.trim() && parseAmount(tip) == null) {
      setError("Bahşiş tutarı geçersiz.");
      return;
    }
    const amt = amount.trim() ? (parseAmount(amount) ?? 0) : 0;
    const tp = tip.trim() ? (parseAmount(tip) ?? 0) : 0;
    if (amt + tp <= 0) {
      setError("Kazanç veya bahşiş gir.");
      return;
    }
    let tripCount: number | null = null;
    if (trips.trim()) {
      tripCount = parseIntish(trips);
      if (tripCount == null) {
        setError("Tur sayısı tam sayı olmalı.");
        return;
      }
    }
    const patch = {
      date,
      platformId,
      amount: amt,
      tip: tp,
      trips: tripCount,
      note,
    };
    if (editing) updateEarning(editing, patch);
    else addEarning({ id: uid(), ...patch });
    const keep = platformId;
    resetFields();
    setPlatformId(keep);
  }

  function startEdit(row: Earning) {
    setEditing(row.id);
    setPlatformId(row.platformId);
    setAmount(amountToInput(row.amount));
    setTip(row.tip ? amountToInput(row.tip) : "");
    setTrips(row.trips == null ? "" : String(row.trips));
    setNote(row.note);
    setError("");
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function onAddPlatform() {
    const result = addPlatform(newPlatform);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    setPlatformId(result.id);
    setNewPlatform("");
    setAddingPlatform(false);
    setError("");
  }

  function onClose() {
    if (dayEarnings.length + dayExpenses.length === 0 && !confirmEmpty) {
      setConfirmEmpty(true);
      return;
    }
    closeDay(date);
    setConfirmEmpty(false);
    toast.success("Gün deftere işlendi");
  }

  const nameOf = (id: string) => platforms.find((p) => p.id === id)?.name ?? "Eski platform";

  return (
    <div className="flex flex-col gap-5">
      <PageIntro
        eyebrow="Toplu giriş"
        title="Günün kazancı"
        text="Her platformu ayrı satır yaz. Toplam kendiliğinden çıkar. Günü bitirince kaydet."
      />

      <Card>
        <p className="text-sm text-muted">{formatLong(date)}</p>
        <p className={`mt-1 font-display text-4xl tabular-nums ${toneClass(totals.net)}`}>
          {formatTRY(totals.net, 0)}
        </p>
        <p className="mt-2 text-sm text-muted">
          Kazanç {formatTRY(totals.earn, 2)} · Gider {formatTRY(totals.spend, 2)}
          {totals.tip > 0 ? ` · Bahşiş ${formatTRY(totals.tip, 2)}` : ""}
        </p>
        {closed ? <p className="mt-2 text-sm font-medium text-primary">Bu gün kaydedildi.</p> : null}
      </Card>

      <form ref={formRef} onSubmit={onSubmit} className="flex flex-col gap-5">
        <Field label="Tarih">
          <input
            className="field"
            type="date"
            value={date}
            onChange={(e) => {
              setDate(e.target.value || todayISO());
              resetFields();
              setConfirmEmpty(false);
            }}
          />
        </Field>

        <div>
          <p className="mb-2 text-sm font-medium">Platform</p>
          <div className="flex flex-wrap gap-2">
            {activePlatforms.map((p) => (
              <Chip key={p.id} pressed={platformId === p.id} onClick={() => setPlatformId(p.id)}>
                {p.name}
              </Chip>
            ))}
            <Chip pressed={addingPlatform} onClick={() => setAddingPlatform((v) => !v)}>
              + Yeni
            </Chip>
          </div>
          {addingPlatform ? (
            <div className="mt-3 flex flex-col gap-2 sm:flex-row">
              <input
                className="field sm:flex-1"
                value={newPlatform}
                placeholder="Platform adı"
                maxLength={40}
                onChange={(e) => setNewPlatform(e.target.value)}
              />
              <Button type="button" onClick={onAddPlatform}>
                Ekle
              </Button>
            </div>
          ) : null}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Kazanç (₺)">
            <input
              className="field"
              inputMode="decimal"
              autoComplete="off"
              placeholder="0,00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </Field>
          <Field label="Bahşiş (₺)">
            <input
              className="field"
              inputMode="decimal"
              autoComplete="off"
              placeholder="0,00"
              value={tip}
              onChange={(e) => setTip(e.target.value)}
            />
          </Field>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Tur sayısı" hint="Boş bırakabilirsin.">
            <input
              className="field"
              inputMode="numeric"
              placeholder="0"
              value={trips}
              onChange={(e) => setTrips(e.target.value)}
            />
          </Field>
          <Field label="Not">
            <input className="field" maxLength={280} value={note} onChange={(e) => setNote(e.target.value)} />
          </Field>
        </div>

        <ErrorNote>{error}</ErrorNote>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button type="submit" size="lg" className="sm:flex-1">
            {editing ? "Satırı güncelle" : "Satır ekle"}
          </Button>
          {editing ? (
            <Button type="button" variant="ghost" size="lg" onClick={resetFields}>
              Vazgeç
            </Button>
          ) : null}
        </div>
      </form>

      <section>
        <h2 className="mb-3 text-lg font-semibold">Bu günün satırları</h2>
        {dayEarnings.length === 0 ? (
          <p className="text-sm text-muted">Henüz kazanç satırı yok.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {dayEarnings.map((row) => (
              <li key={row.id} className="rounded-2xl border border-line bg-surface px-4 py-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-medium">{nameOf(row.platformId)}</p>
                    <p className="text-sm text-muted">
                      {formatTRY(row.amount, 2)}
                      {row.tip > 0 ? ` + ${formatTRY(row.tip, 2)} bahşiş` : ""}
                      {row.trips != null ? ` · ${row.trips} tur` : ""}
                    </p>
                    {row.note ? <p className="mt-1 text-sm text-muted">{row.note}</p> : null}
                  </div>
                  <p className="shrink-0 font-display text-xl tabular-nums">{formatTRY(row.amount + row.tip, 0)}</p>
                </div>
                <div className="mt-2 flex gap-4">
                  <button type="button" className="text-sm font-medium text-primary" onClick={() => startEdit(row)}>
                    Düzenle
                  </button>
                  <ConfirmDelete onConfirm={() => deleteEarning(row.id)} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <div className="mb-3 flex items-end justify-between gap-3">
          <h2 className="text-lg font-semibold">Bu günün giderleri</h2>
          <Link to="/gider" search={{ tarih: date }} className="text-sm font-semibold text-primary">
            Gider ekle
          </Link>
        </div>
        {dayExpenses.length === 0 ? (
          <p className="text-sm text-muted">Gider yok.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {dayExpenses.map((row) => (
              <li key={row.id} className="flex items-center justify-between rounded-2xl border border-line px-4 py-3">
                <span className="text-sm">{row.note || categoryLabel(row.category)}</span>
                <span className="tabular-nums text-expense">{formatTRY(row.amount, 2)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <div className="save-bar">
        {confirmEmpty ? (
          <p className="mb-2 text-sm text-muted">Bu tarihte kayıt yok. Boş gün olarak kaydedilsin mi?</p>
        ) : null}
        {closed ? (
          <Button variant="surface" size="lg" className="w-full" onClick={() => reopenDay(date)}>
            Günü yeniden aç
          </Button>
        ) : (
          <Button size="lg" className="w-full" onClick={onClose}>
            Günü kaydet
          </Button>
        )}
      </div>
    </div>
  );
}
