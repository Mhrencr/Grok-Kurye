import { createFileRoute, Link } from "@tanstack/react-router";
import { Bike, ChevronRight, Settings, Target } from "lucide-react";
import { PageIntro } from "@/components/ui";

export const Route = createFileRoute("/diger")({ component: DigerPage });

const LINKS = [
  {
    to: "/arac",
    title: "Araç ve yakıt",
    text: "Tüketim, kilometre maliyeti, yağ, lastik ve muayene.",
    icon: Bike,
  },
  {
    to: "/hedef",
    title: "Hedefler",
    text: "Günlük, haftalık ve aylık net kazanç.",
    icon: Target,
  },
  {
    to: "/ayarlar",
    title: "Ayarlar ve yedek",
    text: "Tema, stopaj, platformlar, Excel ve cihaz yedeği.",
    icon: Settings,
  },
] as const;

function DigerPage() {
  return (
    <div className="flex flex-col gap-5">
      <PageIntro title="Diğer" text="Günün kaydı özet, gün ve giderde. Gerisi burada." />
      <ul className="flex flex-col gap-3">
        {LINKS.map((item) => (
          <li key={item.to}>
            <Link
              to={item.to}
              className="flex min-h-20 items-center gap-4 rounded-2xl border border-line bg-surface px-4 py-4"
            >
              <item.icon className="size-6 shrink-0 text-primary" aria-hidden />
              <span className="min-w-0 flex-1">
                <span className="block font-semibold">{item.title}</span>
                <span className="mt-1 block text-sm text-muted">{item.text}</span>
              </span>
              <ChevronRight className="size-5 shrink-0 text-muted" aria-hidden />
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
