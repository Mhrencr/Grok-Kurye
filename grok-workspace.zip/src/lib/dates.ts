import { endOfMonth, endOfWeek, format, getDaysInMonth, startOfMonth, startOfWeek } from "date-fns";
import { tr } from "date-fns/locale";

const ISO = /^\d{4}-\d{2}-\d{2}$/;

export function isISODate(value: string): boolean {
  if (!ISO.test(value)) return false;
  const d = parseISODate(value);
  return formatISODate(d) === value;
}

export function formatISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseISODate(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y || 1970, (m || 1) - 1, d || 1);
}

export function todayISO(): string {
  // Türkiye takvimi. Sunucu UTC olsa da kuryenin günü İstanbul'a göre kapanır
  // ve sunucu ile telefon aynı günü basar.
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Istanbul",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

export function shiftISO(iso: string, days: number): string {
  const d = parseISODate(iso);
  d.setDate(d.getDate() + days);
  return formatISODate(d);
}

export function weekBounds(iso: string): { from: string; to: string } {
  const d = parseISODate(iso);
  return {
    from: formatISODate(startOfWeek(d, { weekStartsOn: 1 })),
    to: formatISODate(endOfWeek(d, { weekStartsOn: 1 })),
  };
}

export function monthBounds(iso: string): { from: string; to: string } {
  const d = parseISODate(iso);
  return {
    from: formatISODate(startOfMonth(d)),
    to: formatISODate(endOfMonth(d)),
  };
}

export function lastDays(iso: string, count: number): string[] {
  const days: string[] = [];
  for (let i = count - 1; i >= 0; i -= 1) days.push(shiftISO(iso, -i));
  return days;
}

/** Dahil aralık. 400 günden uzunsa kesilir; arayüz zaten daraltır. */
export function eachISO(from: string, to: string): string[] {
  if (from > to) return [];
  const out: string[] = [];
  let cur = from;
  let guard = 0;
  while (cur <= to && guard < 400) {
    out.push(cur);
    cur = shiftISO(cur, 1);
    guard += 1;
  }
  return out;
}

export function daysBetween(from: string, to: string): number {
  const a = parseISODate(from).getTime();
  const b = parseISODate(to).getTime();
  return Math.round((b - a) / 86_400_000);
}

export function formatLong(iso: string): string {
  return format(parseISODate(iso), "d MMMM yyyy, EEEE", { locale: tr });
}

export function formatShort(iso: string): string {
  return format(parseISODate(iso), "d MMM", { locale: tr });
}

export function formatWeekday(iso: string): string {
  return format(parseISODate(iso), "EEE", { locale: tr });
}

export function monthProgress(iso: string): { day: number; days: number; late: boolean } {
  const d = parseISODate(iso);
  const day = d.getDate();
  const days = getDaysInMonth(d);
  return { day, days, late: day >= days - 2 };
}

export function dateSearch(search: Record<string, unknown>): { tarih?: string } {
  const tarih = typeof search.tarih === "string" && isISODate(search.tarih) ? search.tarih : undefined;
  return { tarih };
}

export function groupByDate<T extends { date: string }>(rows: T[]): { date: string; items: T[] }[] {
  const sorted = [...rows].sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
  const map = new Map<string, T[]>();
  for (const row of sorted) {
    const list = map.get(row.date);
    if (list) list.push(row);
    else map.set(row.date, [row]);
  }
  return [...map.entries()].map(([date, items]) => ({ date, items }));
}
