import { eachISO, daysBetween, formatShort } from "@/lib/dates";
import { round2 } from "@/lib/format";
import type { Earning, Expense, Maintenance, Platform, Vehicle } from "@/lib/types";

export type Totals = {
  earn: number;
  tip: number;
  spend: number;
  net: number;
  trips: number;
  daysActive: number;
  /** Çalışılan gün başına net. Kayıtsız günler ortalamayı düşürmesin. */
  avgNet: number | null;
};

export type Slice = { name: string; value: number };

export type DayPoint = {
  date: string;
  label: string;
  earn: number;
  spend: number;
  net: number;
};

export type VehicleFuelStats = {
  fills: number;
  liters: number;
  amount: number;
  pricePerLiter: number | null;
  recordedKm: number | null;
  actualConsumption: number | null;
  costPerKm: number | null;
};

export function totalsBetween(
  earnings: Earning[],
  expenses: Expense[],
  from: string,
  to: string,
): Totals {
  let earn = 0;
  let tip = 0;
  let trips = 0;
  let spend = 0;
  const active = new Set<string>();
  for (const row of earnings) {
    if (row.date < from || row.date > to) continue;
    earn += row.amount + row.tip;
    tip += row.tip;
    if (row.trips) trips += row.trips;
    active.add(row.date);
  }
  for (const row of expenses) {
    if (row.date < from || row.date > to) continue;
    spend += row.amount;
    active.add(row.date);
  }
  const net = round2(earn - spend);
  const daysActive = active.size;
  return {
    earn: round2(earn),
    tip: round2(tip),
    spend: round2(spend),
    net,
    trips,
    daysActive,
    avgNet: daysActive > 0 ? round2(net / daysActive) : null,
  };
}

export function earningsByPlatform(
  earnings: Earning[],
  platforms: Platform[],
  from: string,
  to: string,
): Slice[] {
  const map = new Map<string, number>();
  for (const row of earnings) {
    if (row.date < from || row.date > to) continue;
    const gross = row.amount + row.tip;
    map.set(row.platformId, (map.get(row.platformId) ?? 0) + gross);
  }
  const nameOf = (id: string) => platforms.find((p) => p.id === id)?.name ?? "Eski platform";
  return [...map.entries()]
    .map(([id, value]) => ({ name: nameOf(id), value: round2(value) }))
    .filter((s) => s.value > 0)
    .sort((a, b) => b.value - a.value);
}

export function expensesByCategory(expenses: Expense[], from: string, to: string): Slice[] {
  const map = new Map<string, number>();
  for (const row of expenses) {
    if (row.date < from || row.date > to) continue;
    map.set(row.category, (map.get(row.category) ?? 0) + row.amount);
  }
  return [...map.entries()]
    .map(([name, value]) => ({ name, value: round2(value) }))
    .filter((s) => s.value > 0)
    .sort((a, b) => b.value - a.value);
}

export function dayPoints(earnings: Earning[], expenses: Expense[], from: string, to: string): DayPoint[] {
  const days = eachISO(from, to);
  return days.map((date) => {
    const t = totalsBetween(earnings, expenses, date, date);
    return { date, label: formatShort(date), earn: t.earn, spend: t.spend, net: t.net };
  });
}

/** 45 günden uzun aralıkta çizgi grafik haftalığa iner. */
export function chartPoints(points: DayPoint[]): DayPoint[] {
  if (points.length <= 45) return points;
  const buckets: DayPoint[] = [];
  for (let i = 0; i < points.length; i += 7) {
    const chunk = points.slice(i, i + 7);
    const earn = round2(chunk.reduce((s, p) => s + p.earn, 0));
    const spend = round2(chunk.reduce((s, p) => s + p.spend, 0));
    const first = chunk[0];
    const last = chunk[chunk.length - 1];
    if (!first || !last) continue;
    buckets.push({
      date: first.date,
      label: first.label === last.label ? first.label : `${first.label}`,
      earn,
      spend,
      net: round2(earn - spend),
    });
  }
  return buckets;
}

export function topEarningDays(
  earnings: Earning[],
  expenses: Expense[],
  from: string,
  to: string,
): { date: string; earn: number; net: number }[] {
  const map = new Map<string, { earn: number; spend: number }>();
  for (const row of earnings) {
    if (row.date < from || row.date > to) continue;
    const cur = map.get(row.date) ?? { earn: 0, spend: 0 };
    cur.earn += row.amount + row.tip;
    map.set(row.date, cur);
  }
  for (const row of expenses) {
    if (row.date < from || row.date > to) continue;
    const cur = map.get(row.date) ?? { earn: 0, spend: 0 };
    cur.spend += row.amount;
    map.set(row.date, cur);
  }
  return [...map.entries()]
    .map(([date, v]) => ({ date, earn: round2(v.earn), net: round2(v.earn - v.spend) }))
    .filter((d) => d.earn > 0)
    .sort((a, b) => b.earn - a.earn)
    .slice(0, 5);
}

export function calendarAvg(net: number, from: string, to: string): number | null {
  const days = eachISO(from, to).length;
  if (days === 0) return null;
  return round2(net / days);
}

export function vehicleFuelStats(vehicle: Vehicle, expenses: Expense[]): VehicleFuelStats {
  const fills = expenses.filter((e) => e.category === "yakit" && e.vehicleId === vehicle.id);
  let amount = 0;
  let liters = 0;
  let litersAmount = 0;
  for (const row of fills) {
    amount += row.amount;
    if (row.liters && row.liters > 0) {
      liters += row.liters;
      litersAmount += row.amount;
    }
  }
  const withOdo = fills
    .filter((f) => f.odometer != null && (f.liters ?? 0) > 0)
    .sort((a, b) => a.date.localeCompare(b.date) || (a.odometer ?? 0) - (b.odometer ?? 0));
  let recordedKm: number | null = null;
  let actualConsumption: number | null = null;
  if (withOdo.length >= 2) {
    const first = withOdo[0];
    const last = withOdo[withOdo.length - 1];
    if (first?.odometer != null && last?.odometer != null) {
      const km = last.odometer - first.odometer;
      if (km > 0) {
        recordedKm = km;
        const used = withOdo.slice(1).reduce((s, f) => s + (f.liters ?? 0), 0);
        if (used > 0) actualConsumption = round2((used / km) * 100);
      }
    }
  }
  const pricePerLiter = liters > 0 ? round2(litersAmount / liters) : null;
  const cons = actualConsumption ?? (vehicle.consumption > 0 ? vehicle.consumption : null);
  const costPerKm = pricePerLiter != null && cons != null ? round2((pricePerLiter * cons) / 100) : null;
  return {
    fills: fills.length,
    liters: round2(liters),
    amount: round2(amount),
    pricePerLiter,
    recordedKm,
    actualConsumption,
    costPerKm,
  };
}

export function periodKm(
  expenses: Expense[],
  vehicles: Vehicle[],
  from: string,
  to: string,
): { recordedKm: number | null; estimatedKm: number | null } {
  let recorded = 0;
  let recordedOk = false;
  let estimated = 0;
  let estimatedOk = false;
  for (const vehicle of vehicles) {
    const stats = vehicleFuelStats(vehicle, expenses.filter((e) => e.date >= from && e.date <= to));
    // vehicleFuelStats already filters vehicle; passing a prefiltered list is correct
    // because it filters vehicleId again.
    if (stats.recordedKm != null) {
      recorded += stats.recordedKm;
      recordedOk = true;
    }
    const liters = expenses
      .filter(
        (e) =>
          e.category === "yakit" &&
          e.vehicleId === vehicle.id &&
          e.date >= from &&
          e.date <= to &&
          (e.liters ?? 0) > 0,
      )
      .reduce((s, e) => s + (e.liters ?? 0), 0);
    if (liters > 0 && vehicle.consumption > 0) {
      estimated += liters / (vehicle.consumption / 100);
      estimatedOk = true;
    }
  }
  return {
    recordedKm: recordedOk ? round2(recorded) : null,
    estimatedKm: estimatedOk ? round2(estimated) : null,
  };
}

export type Reminder = Maintenance & { days: number };

export function upcomingMaintenance(items: Maintenance[], today: string): Reminder[] {
  return items
    .filter((m) => !m.done)
    .map((m) => ({ ...m, days: daysBetween(today, m.dueDate) }))
    .filter((m) => m.days <= 14)
    .sort((a, b) => a.days - b.days);
}

export function dueLabel(days: number): string {
  if (days < 0) {
    const n = Math.abs(days);
    return n === 1 ? "1 gün geçti" : `${n} gün geçti`;
  }
  if (days === 0) return "Bugün";
  if (days === 1) return "Yarın";
  return `${days} gün kaldı`;
}

export function monthMessage(pct: number, late: boolean): string {
  if (pct >= 100) {
    return late
      ? "Ayı hedefin üstünde kapattın. Eline sağlık."
      : "Aylık hedef tamam. Üstü fazladan nefes.";
  }
  if (pct >= 80) return "Hedefe bir adım kaldı. Ay sonuna kadar tempo yetiyor.";
  if (pct >= 50) return "Yolun yarısından fazlası geride. Net, hedefin izinde.";
  if (late) return "Ay kapanıyor, hedef uzakta. Yine de kasa net: ne girdi, ne çıktı ortada.";
  return "Hedef için vakit var. Gün sonlarını aksatmadan yazmak yeter.";
}

export function taxAmount(earn: number, net: number, rate: number, base: "brut" | "net"): number | null {
  if (!(rate > 0) || rate > 100) return null;
  const matrah = base === "brut" ? earn : Math.max(0, net);
  return round2((matrah * rate) / 100);
}
