import { shiftISO } from "@/lib/dates";
import { DEFAULT_PLATFORMS, type Earning, type Expense, type LedgerData, type Maintenance } from "@/lib/types";

/** İlk bakış için tek haftalık, silinebilir örnek. Gerçek kayıtların yerine geçer. */
export function buildSample(today: string): Pick<
  LedgerData,
  "platforms" | "earnings" | "expenses" | "vehicles" | "maintenance" | "goals" | "closedDays"
> {
  const d = (n: number) => shiftISO(today, n);
  const vehicleId = "arac-ornek";

  const earn = (
    date: string,
    platformId: string,
    amount: number,
    tip: number,
    trips: number | null,
    note = "",
  ): Earning => ({
    id: `ornek-${date}-${platformId}-${amount}`,
    date,
    platformId,
    amount,
    tip,
    trips,
    note,
  });

  const spend = (
    id: string,
    date: string,
    category: Expense["category"],
    amount: number,
    note: string,
    extra: Partial<Pick<Expense, "liters" | "vehicleId" | "odometer">> = {},
  ): Expense => ({
    id,
    date,
    category,
    amount,
    note,
    liters: extra.liters ?? null,
    vehicleId: extra.vehicleId ?? null,
    odometer: extra.odometer ?? null,
  });

  const earnings: Earning[] = [
    earn(d(-6), "ys", 860, 45, 16, "Akşam yoğun"),
    earn(d(-6), "getir", 240, 20, 4),
    earn(d(-5), "trendyol", 610, 30, 11),
    earn(d(-4), "ys", 980, 80, 18),
    earn(d(-4), "migros", 190, 10, 3),
    earn(d(-2), "getir", 470, 35, 8),
    earn(d(-2), "kendi", 260, 40, 2, "Tanıdık teslimat"),
    earn(d(-1), "ys", 720, 55, 13),
    earn(d(-1), "trendyol", 300, 15, 5),
    earn(d(0), "ys", 540, 40, 9),
  ];

  const expenses: Expense[] = [
    spend("g-yakit-1", d(-6), "yakit", 420, "İstasyon", {
      liters: 8.1,
      vehicleId,
      odometer: 45210,
    }),
    spend("g-yemek", d(-5), "yemek", 165, "Öğle"),
    spend("g-bakim", d(-5), "bakim", 90, "Zincir spreyi"),
    spend("g-yakit-2", d(-2), "yakit", 395, "İstasyon", {
      liters: 7.6,
      vehicleId,
      odometer: 45490,
    }),
    spend("g-tel", d(-1), "telefon", 220, "Hat + paket"),
  ];

  const maintenance: Maintenance[] = [
    {
      id: "m-yag",
      vehicleId,
      kind: "yag",
      dueDate: shiftISO(today, 3),
      note: "1500 km oldu sayılır",
      done: false,
    },
    {
      id: "m-muayene",
      vehicleId,
      kind: "muayene",
      dueDate: shiftISO(today, 40),
      note: "",
      done: false,
    },
  ];

  return {
    platforms: DEFAULT_PLATFORMS.map((p) => ({ ...p })),
    earnings,
    expenses,
    vehicles: [
      {
        id: vehicleId,
        brand: "Honda",
        model: "PCX",
        plate: "34 TD 270",
        consumption: 2.8,
      },
    ],
    maintenance,
    goals: { daily: 1200, weekly: 7000, monthly: 28000 },
    closedDays: [d(-1), d(-4)],
  };
}
