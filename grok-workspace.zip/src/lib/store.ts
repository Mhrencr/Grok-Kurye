import { create } from "zustand";
import { persist } from "zustand/middleware";
import { parseBackup } from "@/lib/backup";
import { round2 } from "@/lib/format";
import { buildSample } from "@/lib/sample";
import { applyTheme } from "@/lib/theme";
import {
  defaultLedger,
  type Earning,
  type Expense,
  type Goals,
  type LedgerData,
  type Maintenance,
  type Platform,
  type Settings,
  type Vehicle,
} from "@/lib/types";
import { formatISODate } from "@/lib/dates";

export function uid(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

type AddPlatformResult = { ok: true; id: string } | { ok: false; message: string };

type Actions = {
  addEarning: (row: Earning) => void;
  updateEarning: (id: string, patch: Omit<Earning, "id">) => void;
  deleteEarning: (id: string) => void;
  addExpense: (row: Expense) => void;
  updateExpense: (id: string, patch: Omit<Expense, "id">) => void;
  deleteExpense: (id: string) => void;
  addVehicle: (row: Vehicle) => void;
  updateVehicle: (id: string, patch: Omit<Vehicle, "id">) => void;
  deleteVehicle: (id: string) => boolean;
  addMaintenance: (row: Maintenance) => void;
  toggleMaintenance: (id: string) => void;
  deleteMaintenance: (id: string) => void;
  addPlatform: (name: string) => AddPlatformResult;
  renamePlatform: (id: string, name: string) => boolean;
  archivePlatform: (id: string) => void;
  restorePlatform: (id: string) => void;
  setGoals: (goals: Goals) => void;
  setSettings: (patch: Partial<Settings>) => void;
  closeDay: (date: string) => void;
  reopenDay: (date: string) => void;
  loadSample: () => void;
  resetData: () => void;
  importBackup: (raw: unknown) => boolean;
};

export type Ledger = LedgerData & Actions;

function cleanNote(note: string): string {
  return note.trim().slice(0, 280);
}

function cleanGoal(n: number | null): number | null {
  if (n == null || !Number.isFinite(n) || n <= 0) return null;
  return round2(n);
}

function sameName(a: string, b: string): boolean {
  return a.trim().toLocaleLowerCase("tr") === b.trim().toLocaleLowerCase("tr");
}

export const useLedger = create<Ledger>()(
  persist(
    (set, get) => ({
      ...defaultLedger(),

      addEarning: (row) => set((s) => ({ earnings: [{ ...row, note: cleanNote(row.note) }, ...s.earnings] })),
      updateEarning: (id, patch) =>
        set((s) => ({
          earnings: s.earnings.map((e) => (e.id === id ? { ...patch, id, note: cleanNote(patch.note) } : e)),
        })),
      deleteEarning: (id) => set((s) => ({ earnings: s.earnings.filter((e) => e.id !== id) })),

      addExpense: (row) => set((s) => ({ expenses: [{ ...row, note: cleanNote(row.note) }, ...s.expenses] })),
      updateExpense: (id, patch) =>
        set((s) => ({
          expenses: s.expenses.map((e) => (e.id === id ? { ...patch, id, note: cleanNote(patch.note) } : e)),
        })),
      deleteExpense: (id) => set((s) => ({ expenses: s.expenses.filter((e) => e.id !== id) })),

      addVehicle: (row) => set((s) => ({ vehicles: [...s.vehicles, row] })),
      updateVehicle: (id, patch) =>
        set((s) => ({ vehicles: s.vehicles.map((v) => (v.id === id ? { ...patch, id } : v)) })),
      deleteVehicle: (id) => {
        const used =
          get().expenses.some((e) => e.vehicleId === id) || get().maintenance.some((m) => m.vehicleId === id);
        if (used) return false;
        set((s) => ({ vehicles: s.vehicles.filter((v) => v.id !== id) }));
        return true;
      },

      addMaintenance: (row) => set((s) => ({ maintenance: [row, ...s.maintenance] })),
      toggleMaintenance: (id) =>
        set((s) => ({
          maintenance: s.maintenance.map((m) => (m.id === id ? { ...m, done: !m.done } : m)),
        })),
      deleteMaintenance: (id) => set((s) => ({ maintenance: s.maintenance.filter((m) => m.id !== id) })),

      addPlatform: (name) => {
        const clean = name.trim().slice(0, 40);
        if (!clean) return { ok: false, message: "Bir ad yaz." };
        const existing = get().platforms.find((p) => sameName(p.name, clean));
        if (existing && !existing.archived) return { ok: false, message: "Bu platform zaten var." };
        if (existing?.archived) {
          set((s) => ({
            platforms: s.platforms.map((p) => (p.id === existing.id ? { ...p, archived: false, name: clean } : p)),
          }));
          return { ok: true, id: existing.id };
        }
        const id = uid();
        const row: Platform = { id, name: clean };
        set((s) => ({ platforms: [...s.platforms, row] }));
        return { ok: true, id };
      },
      renamePlatform: (id, name) => {
        const clean = name.trim().slice(0, 40);
        if (!clean) return false;
        const dup = get().platforms.some((p) => p.id !== id && !p.archived && sameName(p.name, clean));
        if (dup) return false;
        set((s) => ({ platforms: s.platforms.map((p) => (p.id === id ? { ...p, name: clean } : p)) }));
        return true;
      },
      archivePlatform: (id) =>
        set((s) => ({ platforms: s.platforms.map((p) => (p.id === id ? { ...p, archived: true } : p)) })),
      restorePlatform: (id) =>
        set((s) => ({ platforms: s.platforms.map((p) => (p.id === id ? { ...p, archived: false } : p)) })),

      setGoals: (goals) =>
        set({
          goals: {
            daily: cleanGoal(goals.daily),
            weekly: cleanGoal(goals.weekly),
            monthly: cleanGoal(goals.monthly),
          },
        }),
      setSettings: (patch) =>
        set((s) => {
          const settings = { ...s.settings, ...patch };
          if (patch.theme) applyTheme(patch.theme);
          return { settings };
        }),

      closeDay: (date) =>
        set((s) => ({ closedDays: s.closedDays.includes(date) ? s.closedDays : [...s.closedDays, date] })),
      reopenDay: (date) => set((s) => ({ closedDays: s.closedDays.filter((d) => d !== date) })),

      loadSample: () => set((s) => ({ ...s, ...buildSample(formatISODate(new Date())) })),
      resetData: () =>
        set((s) => ({
          ...defaultLedger(),
          settings: s.settings,
        })),
      importBackup: (raw) => {
        const data = parseBackup(raw);
        if (!data) return false;
        if (data.platforms.length === 0) data.platforms = defaultLedger().platforms;
        set((s) => ({ ...s, ...data }));
        applyTheme(data.settings.theme);
        return true;
      },
    }),
    {
      name: "tur-defteri-v1",
      skipHydration: true,
      version: 1,
      partialize: (s): LedgerData => ({
        platforms: s.platforms,
        earnings: s.earnings,
        expenses: s.expenses,
        vehicles: s.vehicles,
        maintenance: s.maintenance,
        goals: s.goals,
        settings: s.settings,
        closedDays: s.closedDays,
      }),
      merge: (persisted, current) => {
        if (!persisted || typeof persisted !== "object") return current;
        const p = persisted as Partial<LedgerData>;
        return {
          ...current,
          ...p,
          settings: { ...current.settings, ...p.settings },
          goals: { ...current.goals, ...p.goals },
          platforms: Array.isArray(p.platforms) ? p.platforms : current.platforms,
          earnings: Array.isArray(p.earnings) ? p.earnings : current.earnings,
          expenses: Array.isArray(p.expenses) ? p.expenses : current.expenses,
          vehicles: Array.isArray(p.vehicles) ? p.vehicles : current.vehicles,
          maintenance: Array.isArray(p.maintenance) ? p.maintenance : current.maintenance,
          closedDays: Array.isArray(p.closedDays) ? p.closedDays : current.closedDays,
        };
      },
    },
  ),
);

export function snapshot(): LedgerData {
  const s = useLedger.getState();
  return {
    platforms: s.platforms,
    earnings: s.earnings,
    expenses: s.expenses,
    vehicles: s.vehicles,
    maintenance: s.maintenance,
    goals: s.goals,
    settings: s.settings,
    closedDays: s.closedDays,
  };
}
