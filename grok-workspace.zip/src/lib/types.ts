/**
 * Tur Defteri — cihaz içi kasa modeli.
 *
 * Günlük özet saklanmaz; kazanç ve gider satırlarından hesaplanır (calc.ts).
 * Böylece bir satır düzeltilince gün, hafta ve ay birlikte güncellenir.
 *
 * KazancKalemi → Earning
 * Gider        → Expense  (yakıt litresı ve km burada)
 * Arac         → Vehicle
 * Hedef        → Goals
 */

export type ThemeMode = "system" | "light" | "dark";
export type TaxBase = "brut" | "net";

export type Category =
  | "yakit"
  | "bakim"
  | "lastik"
  | "yemek"
  | "telefon"
  | "sigorta"
  | "diger";

export type MaintenanceKind = "yag" | "lastik" | "muayene" | "diger";

export type Platform = {
  id: string;
  name: string;
  archived?: boolean;
};

/** Bir platformun o güne ait tek satırı. Bahşiş kazançtan ayrı durur. */
export type Earning = {
  id: string;
  date: string;
  platformId: string;
  amount: number;
  tip: number;
  trips: number | null;
  note: string;
};

export type Expense = {
  id: string;
  date: string;
  category: Category;
  amount: number;
  note: string;
  liters: number | null;
  vehicleId: string | null;
  odometer: number | null;
};

export type Vehicle = {
  id: string;
  brand: string;
  model: string;
  plate: string;
  /** Litre / 100 km. Kullanıcının bildirdiği ortalama. */
  consumption: number;
};

export type Maintenance = {
  id: string;
  vehicleId: string;
  kind: MaintenanceKind;
  dueDate: string;
  note: string;
  done: boolean;
};

export type Goals = {
  daily: number | null;
  weekly: number | null;
  monthly: number | null;
};

export type Settings = {
  theme: ThemeMode;
  /** 0–100. Bilgi amaçlı stopaj oranı. */
  taxRate: number;
  taxBase: TaxBase;
};

export type LedgerData = {
  platforms: Platform[];
  earnings: Earning[];
  expenses: Expense[];
  vehicles: Vehicle[];
  maintenance: Maintenance[];
  goals: Goals;
  settings: Settings;
  closedDays: string[];
};

export const CATEGORIES: { id: Category; label: string }[] = [
  { id: "yakit", label: "Yakıt" },
  { id: "bakim", label: "Bakım" },
  { id: "lastik", label: "Lastik" },
  { id: "yemek", label: "Yemek" },
  { id: "telefon", label: "Telefon / Paket" },
  { id: "sigorta", label: "Sigorta" },
  { id: "diger", label: "Diğer" },
];

export const MAINT_KINDS: { id: MaintenanceKind; label: string }[] = [
  { id: "yag", label: "Yağ değişimi" },
  { id: "lastik", label: "Lastik" },
  { id: "muayene", label: "Muayene" },
  { id: "diger", label: "Diğer" },
];

export const DEFAULT_PLATFORMS: Platform[] = [
  { id: "ys", name: "Yemeksepeti" },
  { id: "getir", name: "Getir" },
  { id: "trendyol", name: "Trendyol Go" },
  { id: "migros", name: "Migros Yemek" },
  { id: "kendi", name: "Kendi işi" },
];

export function categoryLabel(id: string): string {
  return CATEGORIES.find((c) => c.id === id)?.label ?? "Diğer";
}

export function maintLabel(id: string): string {
  return MAINT_KINDS.find((k) => k.id === id)?.label ?? "Hatırlatma";
}

export function defaultSettings(): Settings {
  return { theme: "system", taxRate: 0, taxBase: "brut" };
}

export function defaultGoals(): Goals {
  return { daily: null, weekly: null, monthly: null };
}

export function defaultLedger(): LedgerData {
  return {
    platforms: DEFAULT_PLATFORMS.map((p) => ({ ...p })),
    earnings: [],
    expenses: [],
    vehicles: [],
    maintenance: [],
    goals: defaultGoals(),
    settings: defaultSettings(),
    closedDays: [],
  };
}
