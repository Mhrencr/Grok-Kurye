import { categoryLabel, type Earning, type Expense, type LedgerData, type Platform } from "@/lib/types";
import { totalsBetween } from "@/lib/calc";

function csvCell(value: string | number): string {
  const raw = String(value);
  const safe = /^[=+\-@]/.test(raw) ? `'${raw}` : raw;
  if (/[;"\n]/.test(safe)) return `"${safe.replace(/"/g, '""')}"`;
  return safe;
}

function dec(n: number | null): string {
  if (n == null) return "";
  return n.toFixed(2).replace(".", ",");
}

function platformName(platforms: Platform[], id: string): string {
  return platforms.find((p) => p.id === id)?.name ?? "Eski platform";
}

export function buildCsv(data: LedgerData, from: string, to: string): string {
  const header = ["Tarih", "Tür", "Kalem", "Tutar", "Bahşiş", "Tur", "Litre", "Kilometre", "Not"];
  const rows: string[][] = [];
  const earnings = data.earnings
    .filter((e) => e.date >= from && e.date <= to)
    .sort((a, b) => a.date.localeCompare(b.date));
  const expenses = data.expenses
    .filter((e) => e.date >= from && e.date <= to)
    .sort((a, b) => a.date.localeCompare(b.date));
  for (const row of earnings) {
    rows.push([
      row.date,
      "Kazanç",
      platformName(data.platforms, row.platformId),
      dec(row.amount),
      dec(row.tip),
      row.trips == null ? "" : String(row.trips),
      "",
      "",
      row.note,
    ]);
  }
  for (const row of expenses) {
    rows.push([
      row.date,
      "Gider",
      categoryLabel(row.category),
      dec(row.amount),
      "",
      "",
      dec(row.liters),
      row.odometer == null ? "" : String(Math.round(row.odometer)),
      row.note,
    ]);
  }
  rows.sort((a, b) => a[0].localeCompare(b[0]));
  const totals = totalsBetween(data.earnings, data.expenses, from, to);
  const summary = [
    [],
    ["Özet", `${from} - ${to}`],
    ["Kazanç", dec(totals.earn)],
    ["Gider", dec(totals.spend)],
    ["Net", dec(totals.net)],
  ];
  const body = [header, ...rows, ...summary].map((line) => line.map(csvCell).join(";")).join("\r\n");
  return body;
}

function esc(s: string): string {
  return s
    .replaceAll("&", "\u0026amp;")
    .replaceAll("<", "\u0026lt;")
    .replaceAll(">", "\u0026gt;")
    .replaceAll('"', "\u0026quot;");
}

export function buildXlsHtml(data: LedgerData, from: string, to: string): string {
  const totals = totalsBetween(data.earnings, data.expenses, from, to);
  const lines = dataRows(data, from, to);
  const body = lines
    .map(
      (r) =>
        `<tr><td>${esc(r.date)}</td><td>${esc(r.kind)}</td><td>${esc(r.name)}</td><td>${esc(dec(r.amount))}</td><td>${esc(r.tip)}</td><td>${esc(r.note)}</td></tr>`,
    )
    .join("");
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<table>
<tr><td>Tur Defteri</td><td>${esc(from)} – ${esc(to)}</td></tr>
<tr><td>Kazanç</td><td>${esc(dec(totals.earn))}</td></tr>
<tr><td>Gider</td><td>${esc(dec(totals.spend))}</td></tr>
<tr><td>Net</td><td>${esc(dec(totals.net))}</td></tr>
</table>
<br>
<table border="1">
<tr><th>Tarih</th><th>Tür</th><th>Kalem</th><th>Tutar</th><th>Bahşiş</th><th>Not</th></tr>
${body}
</table>
</body></html>`;
}

type Flat = { date: string; kind: string; name: string; amount: number; tip: string; note: string };

function dataRows(data: LedgerData, from: string, to: string): Flat[] {
  const earn: Flat[] = data.earnings
    .filter((e) => e.date >= from && e.date <= to)
    .map((e: Earning) => ({
      date: e.date,
      kind: "Kazanç",
      name: platformName(data.platforms, e.platformId),
      amount: e.amount + e.tip,
      tip: e.tip ? dec(e.tip) : "",
      note: e.note,
    }));
  const spend: Flat[] = data.expenses
    .filter((e) => e.date >= from && e.date <= to)
    .map((e: Expense) => ({
      date: e.date,
      kind: "Gider",
      name: categoryLabel(e.category),
      amount: e.amount,
      tip: "",
      note: e.note,
    }));
  return [...earn, ...spend].sort((a, b) => a.date.localeCompare(b.date));
}

export function downloadText(filename: string, text: string, mime: string) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function downloadCsvFile(data: LedgerData, from: string, to: string) {
  downloadText(`tur-defteri-${from}-${to}.csv`, `\uFEFF${buildCsv(data, from, to)}`, "text/csv;charset=utf-8");
}

export function downloadXlsFile(data: LedgerData, from: string, to: string) {
  downloadText(
    `tur-defteri-${from}-${to}.xls`,
    `\uFEFF${buildXlsHtml(data, from, to)}`,
    "application/vnd.ms-excel",
  );
}

export function downloadBackup(data: LedgerData) {
  const payload = {
    app: "tur-defteri",
    version: 1,
    exportedAt: new Date().toISOString(),
    ...data,
  };
  const day = new Date().toISOString().slice(0, 10);
  downloadText(
    `tur-defteri-yedek-${day}.json`,
    JSON.stringify(payload, null, 2),
    "application/json",
  );
}
