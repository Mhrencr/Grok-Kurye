/** Para ve sayı biçimi. TRY, Türkçe gruplama. */

export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

/**
 * "1.200" → 1200, "1.200,50" → 1200.5, "12,5" → 12.5, "12.50" → 12.5.
 * Virgül varsa ondalıktır; noktadan sonra tam 3 hane varsa binlik sayılır.
 */
export function parseAmount(raw: string): number | null {
  const s = raw.trim().replace(/\s/g, "");
  if (!s) return null;
  let normalized = s;
  if (s.includes(",")) {
    normalized = s.replace(/\./g, "").replace(",", ".");
  } else if (/^\d{1,3}(\.\d{3})+$/.test(s)) {
    normalized = s.replace(/\./g, "");
  }
  if (!/^\d+(\.\d+)?$/.test(normalized)) return null;
  const n = Number(normalized);
  if (!Number.isFinite(n) || n < 0 || n >= 1e8) return null;
  return round2(n);
}

export function parseIntish(raw: string): number | null {
  const s = raw.trim();
  if (!/^\d+$/.test(s)) return null;
  const n = Number(s);
  if (!Number.isFinite(n) || n > 1_000_000) return null;
  return n;
}

export function amountToInput(n: number | null): string {
  if (n == null) return "";
  const rounded = round2(n);
  if (Number.isInteger(rounded)) return String(rounded);
  return rounded.toFixed(2).replace(".", ",");
}

export function formatTRY(value: number, digits: 0 | 2 | "auto" = "auto"): string {
  const auto = Math.abs(value - Math.round(value)) < 0.001 ? 0 : 2;
  const d = digits === "auto" ? auto : digits;
  return new Intl.NumberFormat("tr-TR", {
    style: "currency",
    currency: "TRY",
    minimumFractionDigits: d,
    maximumFractionDigits: d,
  }).format(value);
}

export function formatNum(value: number, digits = 1): string {
  return new Intl.NumberFormat("tr-TR", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(value);
}

export function formatKm(value: number): string {
  return `${new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 0 }).format(value)} km`;
}

/** Grafik ekseni: 1200 → "1,2 bin". */
export function formatAxis(value: number): string {
  const sign = value < 0 ? "−" : "";
  const abs = Math.abs(value);
  if (abs >= 1000) {
    const v = abs / 1000;
    const body = v >= 10 ? String(Math.round(v)) : v.toFixed(1).replace(".", ",");
    return `${sign}${body} bin`;
  }
  return `${sign}${Math.round(abs)}`;
}
