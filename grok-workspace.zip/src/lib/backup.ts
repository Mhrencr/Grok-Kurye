import { isISODate } from "@/lib/dates";
import { round2 } from "@/lib/format";
import {
  CATEGORIES,
  MAINT_KINDS,
  type Category,
  type Earning,
  type Expense,
  type LedgerData,
  type Maintenance,
  type MaintenanceKind,
  type Platform,
  type Settings,
  type TaxBase,
  type ThemeMode,
  type Vehicle,
  defaultGoals,
  defaultSettings,
} from "@/lib/types";

const THEMES: ThemeMode[] = ["system", "light", "dark"];
const BASES: TaxBase[] = ["brut", "net"];
const CATS = new Set<string>(CATEGORIES.map((c) => c.id));
const KINDS = new Set<string>(MAINT_KINDS.map((k) => k.id));

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function str(value: unknown, max: number): string | null {
  if (typeof value !== "string") return null;
  const t = value.trim();
  if (!t) return null;
  return t.slice(0, max);
}

function money(value: unknown): number | null {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value >= 1e8) return null;
  return round2(value);
}

function optMoney(value: unknown): number | null {
  if (value == null || value === "") return null;
  return money(value);
}

function dateOf(value: unknown): string | null {
  return typeof value === "string" && isISODate(value) ? value : null;
}

function asPlatform(value: unknown): Platform | null {
  if (!isRecord(value)) return null;
  const id = str(value.id, 80);
  const name = str(value.name, 40);
  if (!id || !name) return null;
  return { id, name, archived: value.archived === true };
}

function asEarning(value: unknown): Earning | null {
  if (!isRecord(value)) return null;
  const id = str(value.id, 80);
  const date = dateOf(value.date);
  const platformId = str(value.platformId, 80);
  const amount = money(value.amount);
  const tip = money(value.tip) ?? 0;
  if (!id || !date || !platformId || amount == null) return null;
  const trips = typeof value.trips === "number" && Number.isFinite(value.trips) && value.trips >= 0
    ? Math.round(value.trips)
    : null;
  const note = typeof value.note === "string" ? value.note.trim().slice(0, 280) : "";
  return { id, date, platformId, amount, tip, trips, note };
}

function asExpense(value: unknown): Expense | null {
  if (!isRecord(value)) return null;
  const id = str(value.id, 80);
  const date = dateOf(value.date);
  const category = typeof value.category === "string" && CATS.has(value.category)
    ? (value.category as Category)
    : null;
  const amount = money(value.amount);
  if (!id || !date || !category || amount == null) return null;
  const note = typeof value.note === "string" ? value.note.trim().slice(0, 280) : "";
  return {
    id,
    date,
    category,
    amount,
    note,
    liters: optMoney(value.liters),
    vehicleId: str(value.vehicleId, 80),
    odometer: optMoney(value.odometer),
  };
}

function asVehicle(value: unknown): Vehicle | null {
  if (!isRecord(value)) return null;
  const id = str(value.id, 80);
  const brand = str(value.brand, 40);
  const model = str(value.model, 40);
  const plate = str(value.plate, 16);
  const consumption = money(value.consumption);
  if (!id || !brand || !model || !plate || consumption == null || consumption <= 0 || consumption > 40) {
    return null;
  }
  return { id, brand, model, plate: plate.toLocaleUpperCase("tr"), consumption };
}

function asMaint(value: unknown): Maintenance | null {
  if (!isRecord(value)) return null;
  const id = str(value.id, 80);
  const vehicleId = str(value.vehicleId, 80);
  const kind = typeof value.kind === "string" && KINDS.has(value.kind) ? (value.kind as MaintenanceKind) : null;
  const dueDate = dateOf(value.dueDate);
  if (!id || !vehicleId || !kind || !dueDate) return null;
  const note = typeof value.note === "string" ? value.note.trim().slice(0, 280) : "";
  return { id, vehicleId, kind, dueDate, note, done: value.done === true };
}

function asSettings(value: unknown): Settings {
  const base = defaultSettings();
  if (!isRecord(value)) return base;
  const theme = THEMES.includes(value.theme as ThemeMode) ? (value.theme as ThemeMode) : base.theme;
  const taxBase = BASES.includes(value.taxBase as TaxBase) ? (value.taxBase as TaxBase) : base.taxBase;
  const rate = money(value.taxRate);
  return { theme, taxBase, taxRate: rate == null ? 0 : Math.min(100, rate) };
}

function goal(value: unknown): number | null {
  if (value == null) return null;
  const n = money(value);
  if (n == null || n <= 0) return null;
  return n;
}

/** Yedek dosyası veya düz veri. Bozuksa null. */
export function parseBackup(raw: unknown): LedgerData | null {
  if (!isRecord(raw)) return null;
  if (raw.app != null && raw.app !== "tur-defteri") return null;
  if (!Array.isArray(raw.earnings) || !Array.isArray(raw.expenses)) return null;
  const platforms = Array.isArray(raw.platforms)
    ? raw.platforms.map(asPlatform).filter((x): x is Platform => !!x)
    : [];
  const goalsRaw = isRecord(raw.goals) ? raw.goals : {};
  const closedDays = Array.isArray(raw.closedDays)
    ? raw.closedDays.filter((d): d is string => typeof d === "string" && isISODate(d))
    : [];
  return {
    platforms,
    earnings: raw.earnings.map(asEarning).filter((x): x is Earning => !!x),
    expenses: raw.expenses.map(asExpense).filter((x): x is Expense => !!x),
    vehicles: Array.isArray(raw.vehicles) ? raw.vehicles.map(asVehicle).filter((x): x is Vehicle => !!x) : [],
    maintenance: Array.isArray(raw.maintenance)
      ? raw.maintenance.map(asMaint).filter((x): x is Maintenance => !!x)
      : [],
    goals: {
      ...defaultGoals(),
      daily: goal(goalsRaw.daily),
      weekly: goal(goalsRaw.weekly),
      monthly: goal(goalsRaw.monthly),
    },
    settings: asSettings(raw.settings),
    closedDays,
  };
}
