//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-rbyCtTPn.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/arac",
			"/ayarlar",
			"/diger",
			"/gider",
			"/gun",
			"/hedef",
			"/rapor"
		],
		preloads: [
			"/assets/index-Cf6NGEXR.js",
			"/assets/format--8ipT5b0.js",
			"/assets/preload-helper-BCPM9tso.js",
			"/assets/link-Cc2JtuXk.js",
			"/assets/store-DyruQXjs.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cf6NGEXR.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DT29L8Dy.js",
			"/assets/calc-CwbN7yVh.js",
			"/assets/ui-BEgPjR-B.js"
		]
	},
	"/arac": {
		filePath: "/workspace/src/routes/arac.tsx",
		children: void 0,
		preloads: [
			"/assets/arac-BU4yfQeH.js",
			"/assets/calc-CwbN7yVh.js",
			"/assets/ui-BEgPjR-B.js"
		]
	},
	"/ayarlar": {
		filePath: "/workspace/src/routes/ayarlar.tsx",
		children: void 0,
		preloads: [
			"/assets/ayarlar-BPSq2tgl.js",
			"/assets/calc-CwbN7yVh.js",
			"/assets/ui-BEgPjR-B.js",
			"/assets/export-ghGSU9TK.js"
		]
	},
	"/diger": {
		filePath: "/workspace/src/routes/diger.tsx",
		children: void 0,
		preloads: ["/assets/diger-CQWiByM6.js", "/assets/ui-BEgPjR-B.js"]
	},
	"/gider": {
		filePath: "/workspace/src/routes/gider.tsx",
		children: void 0,
		preloads: [
			"/assets/gider-C4IKIbqK.js",
			"/assets/calc-CwbN7yVh.js",
			"/assets/ui-BEgPjR-B.js"
		]
	},
	"/gun": {
		filePath: "/workspace/src/routes/gun.tsx",
		children: void 0,
		preloads: [
			"/assets/gun-BRbYu5Us.js",
			"/assets/calc-CwbN7yVh.js",
			"/assets/ui-BEgPjR-B.js"
		]
	},
	"/hedef": {
		filePath: "/workspace/src/routes/hedef.tsx",
		children: void 0,
		preloads: [
			"/assets/hedef-DpSibbet.js",
			"/assets/calc-CwbN7yVh.js",
			"/assets/ui-BEgPjR-B.js"
		]
	},
	"/rapor": {
		filePath: "/workspace/src/routes/rapor.tsx",
		children: void 0,
		preloads: [
			"/assets/rapor-C66Qus9k.js",
			"/assets/calc-CwbN7yVh.js",
			"/assets/ui-BEgPjR-B.js",
			"/assets/export-ghGSU9TK.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
