import { i as __toESM } from "../_runtime.mjs";
import { i as formatKm, o as formatTRY, r as formatAxis } from "./format-CmA-bWrc.mjs";
import { J as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as snapshot, a as categoryLabel, b as useLedger, h as monthBounds, l as formatLong, u as formatShort, v as todayISO, x as weekBounds } from "./store-B6L3TiTP.mjs";
import { a as earningsByPlatform, c as periodKm, d as totalsBetween, l as taxAmount, n as chartPoints, o as expensesByCategory, r as dayPoints, t as calendarAvg, u as topEarningDays } from "./calc-CHS9czQW.mjs";
import { c as PageIntro, n as Card, r as Chip, t as Button, u as toneClass } from "./ui-CC6xQcZ6.mjs";
import { n as downloadCsvFile, r as downloadXlsFile } from "./export-B8hc9x3J.mjs";
import { a as Line, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as LineChart, o as Pie, r as YAxis, s as Cell, t as PieChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rapor-sz2EgIAK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILLS = [
	"var(--chart-0)",
	"var(--chart-1)",
	"var(--chart-2)",
	"var(--chart-3)",
	"var(--chart-4)"
];
function useReducedMotion() {
	const [reduce, setReduce] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		const update = () => setReduce(mq.matches);
		update();
		mq.addEventListener("change", update);
		return () => mq.removeEventListener("change", update);
	}, []);
	return reduce;
}
function Tip({ active, payload, label }) {
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-surface px-3 py-2 text-sm",
		children: [label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: label
		}) : null, payload.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-medium tabular-nums",
			children: [item.name ? `${item.name}: ` : "", formatTRY(Number(item.value ?? 0), 0)]
		}, item.name ?? "v"))]
	});
}
function SplitPies({ earn, spend }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieBlock, {
			title: "Platformlar",
			slices: earn,
			empty: "Bu aralıkta kazanç yok."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieBlock, {
			title: "Giderler",
			slices: spend,
			empty: "Bu aralıkta gider yok."
		})]
	});
}
function PieBlock({ title, slices, empty }) {
	const reduce = useReducedMotion();
	const total = slices.reduce((s, x) => s + x.value, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-line bg-surface p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold",
			children: title
		}), slices.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: empty
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto h-48 w-full max-w-xs",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
				width: "100%",
				height: "100%",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
					data: slices,
					dataKey: "value",
					nameKey: "name",
					innerRadius: 48,
					outerRadius: 72,
					paddingAngle: 2,
					stroke: "none",
					isAnimationActive: !reduce,
					children: slices.map((slice, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: FILLS[i % FILLS.length] }, slice.name))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}) })] })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 flex flex-col gap-2",
			children: slices.map((slice, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "size-2.5 shrink-0 rounded-full",
						style: { background: FILLS[i % FILLS.length] }
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: slice.name
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "shrink-0 tabular-nums",
					children: [formatTRY(slice.value, 0), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [
							" · ",
							total > 0 ? Math.round(slice.value / total * 100) : 0,
							"%"
						]
					})]
				})]
			}, slice.name))
		})] })]
	});
}
function NetLine({ points }) {
	const reduce = useReducedMotion();
	const has = points.some((p) => p.net !== 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-line bg-surface p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold",
			children: "Net akış"
		}), !has ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: "Bu aralıkta hareket yok."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 h-56 w-full min-w-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
				width: "100%",
				height: "100%",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
					data: points,
					margin: {
						top: 8,
						right: 8,
						left: 0,
						bottom: 0
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
							dataKey: "label",
							tick: {
								fill: "var(--muted)",
								fontSize: 12
							},
							axisLine: false,
							tickLine: false,
							minTickGap: 20
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
							tick: {
								fill: "var(--muted)",
								fontSize: 12
							},
							axisLine: false,
							tickLine: false,
							width: 64,
							tickFormatter: formatAxis
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							type: "monotone",
							dataKey: "net",
							name: "Net",
							stroke: "var(--primary)",
							strokeWidth: 2.5,
							dot: false,
							isAnimationActive: !reduce
						})
					]
				})
			})
		})]
	});
}
var PRESETS = [
	{
		id: "gun",
		label: "Gün"
	},
	{
		id: "hafta",
		label: "Hafta"
	},
	{
		id: "ay",
		label: "Ay"
	},
	{
		id: "ozel",
		label: "Özel"
	}
];
function RaporPage() {
	const earnings = useLedger((s) => s.earnings);
	const expenses = useLedger((s) => s.expenses);
	const platforms = useLedger((s) => s.platforms);
	const vehicles = useLedger((s) => s.vehicles);
	const settings = useLedger((s) => s.settings);
	const today = todayISO();
	const [preset, setPreset] = (0, import_react.useState)("ay");
	const [customFrom, setCustomFrom] = (0, import_react.useState)(monthBounds(today).from);
	const [customTo, setCustomTo] = (0, import_react.useState)(today);
	const range = (0, import_react.useMemo)(() => {
		if (preset === "gun") return {
			from: today,
			to: today
		};
		if (preset === "hafta") return weekBounds(today);
		if (preset === "ay") return monthBounds(today);
		return {
			from: customFrom <= customTo ? customFrom : customTo,
			to: customFrom <= customTo ? customTo : customFrom
		};
	}, [
		preset,
		today,
		customFrom,
		customTo
	]);
	const model = (0, import_react.useMemo)(() => {
		const totals = totalsBetween(earnings, expenses, range.from, range.to);
		const points = dayPoints(earnings, expenses, range.from, range.to);
		const km = periodKm(expenses, vehicles, range.from, range.to);
		const kmBasis = km.recordedKm ?? km.estimatedKm;
		const perKm = kmBasis && kmBasis > 0 ? totals.net / kmBasis : null;
		return {
			totals,
			points,
			chart: chartPoints(points),
			platforms: earningsByPlatform(earnings, platforms, range.from, range.to),
			categories: expensesByCategory(expenses, range.from, range.to).map((s) => ({
				name: categoryLabel(s.name),
				value: s.value
			})),
			top: topEarningDays(earnings, expenses, range.from, range.to),
			avgActive: totals.avgNet,
			avgCalendar: calendarAvg(totals.net, range.from, range.to),
			km,
			perKm,
			tax: taxAmount(totals.earn, totals.net, settings.taxRate, settings.taxBase)
		};
	}, [
		earnings,
		expenses,
		platforms,
		vehicles,
		range,
		settings.taxRate,
		settings.taxBase
	]);
	const table = model.points.length <= 62 ? model.points : model.chart;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "show-print text-sm",
				children: [
					"Tur Defteri · ",
					formatLong(range.from),
					" – ",
					formatLong(range.to)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
						eyebrow: "İstatistik",
						title: "Rapor",
						text: "Gün, hafta, ay veya kendi aralığın. Rakamlar cihazındaki kayıtlardan gelir."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: PRESETS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: preset === item.id,
							onClick: () => setPreset(item.id),
							children: item.label
						}, item.id))
					}),
					preset === "ozel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2 text-sm font-medium",
							children: ["Başlangıç", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								type: "date",
								value: customFrom,
								onChange: (e) => setCustomFrom(e.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2 text-sm font-medium",
							children: ["Bitiş", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								type: "date",
								value: customTo,
								onChange: (e) => setCustomTo(e.target.value)
							})]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-muted",
						children: [
							formatShort(range.from),
							" – ",
							formatShort(range.to)
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Net"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `mt-1 font-display text-5xl tabular-nums tracking-tight ${toneClass(model.totals.net)}`,
					children: formatTRY(model.totals.net, 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-3 gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: "Kazanç"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums font-medium",
							children: formatTRY(model.totals.earn, 0)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: "Gider"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums font-medium text-expense",
							children: formatTRY(model.totals.spend, 0)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: "Bahşiş"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums font-medium",
							children: formatTRY(model.totals.tip, 0)
						})] })
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Çalışılan gün ortalaması"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-3xl tabular-nums",
						children: model.avgActive == null ? "—" : formatTRY(model.avgActive, 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [model.totals.daysActive, " gün kayıtlı"]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Takvim günü ortalaması"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-3xl tabular-nums",
						children: model.avgCalendar == null ? "—" : formatTRY(model.avgCalendar, 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Boş günler dahil"
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplitPies, {
				earn: model.platforms,
				spend: model.categories
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NetLine, { points: model.chart }),
			model.points.length > 45 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Aralık uzun olduğu için çizgi grafik haftalara bölündü."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "Km başına net"
			}), model.perKm == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Yakıt litresini ve araç tüketimini yazınca bu hesap açılır. Sayaç varsa kayıtlı kilometre kullanılır."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-2 font-display text-4xl tabular-nums ${toneClass(model.perKm)}`,
				children: formatTRY(model.perKm, 2)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: model.km.recordedKm != null ? `Kayıtlı ${formatKm(model.km.recordedKm)}` : `Tahmini ${formatKm(model.km.estimatedKm ?? 0)} (tüketimden)`
			})] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-lg font-semibold",
				children: "En yüksek kazançlı günler"
			}), model.top.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Bu aralıkta kazanç yok."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: model.top.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between rounded-2xl border border-line px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatShort(day.date) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block tabular-nums font-medium",
							children: formatTRY(day.earn, 0)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `block text-sm tabular-nums ${toneClass(day.net)}`,
							children: ["net ", formatTRY(day.net, 0)]
						})]
					})]
				}, day.date))
			})] }),
			model.tax != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Tahmini stopaj"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-display text-3xl tabular-nums",
					children: formatTRY(model.tax, 2)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"%",
						settings.taxRate.toLocaleString("tr-TR"),
						" oran,",
						" ",
						settings.taxBase === "brut" ? "brüt kazanç" : "net kâr",
						" üzerinden. Resmi hesap değildir."
					]
				})
			] }) : null,
			model.totals.earn === 0 && model.totals.spend === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Bu aralıkta satır yok."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayTable, {
				rows: table,
				weekly: model.points.length > 62
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print flex flex-col gap-2 sm:flex-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "surface",
						onClick: () => downloadCsvFile(snapshot(), range.from, range.to),
						children: "CSV indir"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "surface",
						onClick: () => downloadXlsFile(snapshot(), range.from, range.to),
						children: "Excel indir"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "surface",
						onClick: () => window.print(),
						children: "PDF / yazdır"
					})
				]
			})
		]
	});
}
function DayTable({ rows, weekly }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "mb-3 text-lg font-semibold",
		children: weekly ? "Haftalık döküm" : "Gün gün"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-2xl border border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-lg text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "bg-surface-2 text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: "Tarih"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: "Kazanç"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: "Gider"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: "Net"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-3",
						children: row.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-3 tabular-nums",
						children: formatTRY(row.earn, 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-3 tabular-nums",
						children: formatTRY(row.spend, 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: `px-3 py-3 tabular-nums ${toneClass(row.net)}`,
						children: formatTRY(row.net, 0)
					})
				]
			}, row.date + row.label)) })]
		})
	})] });
}
//#endregion
export { RaporPage as component };
