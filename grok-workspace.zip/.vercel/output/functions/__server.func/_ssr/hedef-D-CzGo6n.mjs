import { i as __toESM } from "../_runtime.mjs";
import { o as formatTRY, s as parseAmount, t as amountToInput } from "./format-CmA-bWrc.mjs";
import { J as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as useLedger, g as monthProgress, h as monthBounds, v as todayISO, x as weekBounds } from "./store-B6L3TiTP.mjs";
import { d as totalsBetween, s as monthMessage } from "./calc-CHS9czQW.mjs";
import { a as ErrorNote, c as PageIntro, n as Card, o as Field, s as GoalBar, t as Button } from "./ui-CC6xQcZ6.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hedef-D-CzGo6n.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HedefPage() {
	const goals = useLedger((s) => s.goals);
	const setGoals = useLedger((s) => s.setGoals);
	const earnings = useLedger((s) => s.earnings);
	const expenses = useLedger((s) => s.expenses);
	const [daily, setDaily] = (0, import_react.useState)(() => amountToInput(goals.daily));
	const [weekly, setWeekly] = (0, import_react.useState)(() => amountToInput(goals.weekly));
	const [monthly, setMonthly] = (0, import_react.useState)(() => amountToInput(goals.monthly));
	const [error, setError] = (0, import_react.useState)("");
	const today = todayISO();
	const actual = (0, import_react.useMemo)(() => {
		const week = weekBounds(today);
		const month = monthBounds(today);
		const monthTotals = totalsBetween(earnings, expenses, month.from, month.to);
		const progress = monthProgress(today);
		return {
			day: totalsBetween(earnings, expenses, today, today),
			week: totalsBetween(earnings, expenses, week.from, week.to),
			month: monthTotals,
			late: progress.late
		};
	}, [
		earnings,
		expenses,
		today
	]);
	const pct = goals.monthly && goals.monthly > 0 ? actual.month.net / goals.monthly * 100 : null;
	function read(raw, label) {
		if (!raw.trim()) return null;
		const n = parseAmount(raw);
		if (n == null || n <= 0) {
			setError(`${label} hedefi geçersiz.`);
			return "bad";
		}
		return n;
	}
	function onSubmit(e) {
		e.preventDefault();
		setError("");
		const d = read(daily, "Günlük");
		if (d === "bad") return;
		const w = read(weekly, "Haftalık");
		if (w === "bad") return;
		const m = read(monthly, "Aylık");
		if (m === "bad") return;
		setGoals({
			daily: d,
			weekly: w,
			monthly: m
		});
		setDaily(amountToInput(d));
		setWeekly(amountToInput(w));
		setMonthly(amountToInput(m));
		toast.success("Hedefler kaydedildi");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				eyebrow: "Net kazanç",
				title: "Hedef",
				text: "Boş bırakırsan o dönem için hedef kalkar. Çubuklar net kâra bakar, brüte değil."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/diger",
				className: "text-sm font-medium text-muted",
				children: "← Diğer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Günlük net (₺)",
						hint: `Bugün ${formatTRY(actual.day.net, 0)}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							inputMode: "decimal",
							placeholder: "1200",
							value: daily,
							onChange: (e) => setDaily(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Haftalık net (₺)",
						hint: `Bu hafta ${formatTRY(actual.week.net, 0)}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							inputMode: "decimal",
							placeholder: "7000",
							value: weekly,
							onChange: (e) => setWeekly(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Aylık net (₺)",
						hint: `Bu ay ${formatTRY(actual.month.net, 0)}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							inputMode: "decimal",
							placeholder: "28000",
							value: monthly,
							onChange: (e) => setMonthly(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "lg",
						children: "Hedefleri kaydet"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalBar, {
						label: "Bugün",
						value: actual.day.net,
						goal: goals.daily
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalBar, {
						label: "Bu hafta",
						value: actual.week.net,
						goal: goals.weekly
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalBar, {
						label: "Bu ay",
						value: actual.month.net,
						goal: goals.monthly
					}),
					!goals.daily && !goals.weekly && !goals.monthly ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Kayıtlı hedef yok."
					}) : null,
					pct != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed",
						children: monthMessage(pct, actual.late)
					}) : null
				]
			})
		]
	});
}
//#endregion
export { HedefPage as component };
