import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-CmA-bWrc.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
/** Para ve sayı biçimi. TRY, Türkçe gruplama. */
function round2(n) {
	return Math.round((n + Number.EPSILON) * 100) / 100;
}
/**
* "1.200" → 1200, "1.200,50" → 1200.5, "12,5" → 12.5, "12.50" → 12.5.
* Virgül varsa ondalıktır; noktadan sonra tam 3 hane varsa binlik sayılır.
*/
function parseAmount(raw) {
	const s = raw.trim().replace(/\s/g, "");
	if (!s) return null;
	let normalized = s;
	if (s.includes(",")) normalized = s.replace(/\./g, "").replace(",", ".");
	else if (/^\d{1,3}(\.\d{3})+$/.test(s)) normalized = s.replace(/\./g, "");
	if (!/^\d+(\.\d+)?$/.test(normalized)) return null;
	const n = Number(normalized);
	if (!Number.isFinite(n) || n < 0 || n >= 1e8) return null;
	return round2(n);
}
function parseIntish(raw) {
	const s = raw.trim();
	if (!/^\d+$/.test(s)) return null;
	const n = Number(s);
	if (!Number.isFinite(n) || n > 1e6) return null;
	return n;
}
function amountToInput(n) {
	if (n == null) return "";
	const rounded = round2(n);
	if (Number.isInteger(rounded)) return String(rounded);
	return rounded.toFixed(2).replace(".", ",");
}
function formatTRY(value, digits = "auto") {
	const auto = Math.abs(value - Math.round(value)) < .001 ? 0 : 2;
	const d = digits === "auto" ? auto : digits;
	return new Intl.NumberFormat("tr-TR", {
		style: "currency",
		currency: "TRY",
		minimumFractionDigits: d,
		maximumFractionDigits: d
	}).format(value);
}
function formatNum(value, digits = 1) {
	return new Intl.NumberFormat("tr-TR", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	}).format(value);
}
function formatKm(value) {
	return `${new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 0 }).format(value)} km`;
}
/** Grafik ekseni: 1200 → "1,2 bin". */
function formatAxis(value) {
	const sign = value < 0 ? "−" : "";
	const abs = Math.abs(value);
	if (abs >= 1e3) {
		const v = abs / 1e3;
		return `${sign}${v >= 10 ? String(Math.round(v)) : v.toFixed(1).replace(".", ",")} bin`;
	}
	return `${sign}${Math.round(abs)}`;
}
//#endregion
export { formatNum as a, parseIntish as c, formatKm as i, round2 as l, cn as n, formatTRY as o, formatAxis as r, parseAmount as s, amountToInput as t };
