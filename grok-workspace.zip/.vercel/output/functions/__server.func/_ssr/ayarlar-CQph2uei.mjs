import { i as __toESM } from "../_runtime.mjs";
import { o as formatTRY, s as parseAmount, t as amountToInput } from "./format-CmA-bWrc.mjs";
import { J as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as snapshot, b as useLedger, h as monthBounds, v as todayISO } from "./store-B6L3TiTP.mjs";
import { d as totalsBetween, l as taxAmount } from "./calc-CHS9czQW.mjs";
import { a as ErrorNote, c as PageIntro, n as Card, o as Field, r as Chip, t as Button } from "./ui-CC6xQcZ6.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as downloadCsvFile, r as downloadXlsFile, t as downloadBackup } from "./export-B8hc9x3J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ayarlar-CQph2uei.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var THEMES = [
	{
		id: "system",
		label: "Sistem"
	},
	{
		id: "light",
		label: "Aydınlık"
	},
	{
		id: "dark",
		label: "Karanlık"
	}
];
function AyarlarPage() {
	const settings = useLedger((s) => s.settings);
	const setSettings = useLedger((s) => s.setSettings);
	const platforms = useLedger((s) => s.platforms);
	const earnings = useLedger((s) => s.earnings);
	const expenses = useLedger((s) => s.expenses);
	const vehicles = useLedger((s) => s.vehicles);
	const addPlatform = useLedger((s) => s.addPlatform);
	const renamePlatform = useLedger((s) => s.renamePlatform);
	const archivePlatform = useLedger((s) => s.archivePlatform);
	const restorePlatform = useLedger((s) => s.restorePlatform);
	const loadSample = useLedger((s) => s.loadSample);
	const resetData = useLedger((s) => s.resetData);
	const importBackup = useLedger((s) => s.importBackup);
	const fileRef = (0, import_react.useRef)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [rate, setRate] = (0, import_react.useState)(settings.taxRate ? amountToInput(settings.taxRate) : "");
	const [confirmSample, setConfirmSample] = (0, import_react.useState)(false);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	const today = todayISO();
	const month = monthBounds(today);
	const totals = totalsBetween(earnings, expenses, month.from, month.to);
	const tax = taxAmount(totals.earn, totals.net, settings.taxRate, settings.taxBase);
	const hasData = earnings.length + expenses.length + vehicles.length > 0;
	const active = platforms.filter((p) => !p.archived);
	const archived = platforms.filter((p) => p.archived);
	function applyRate(raw, base = settings.taxBase) {
		setRate(raw);
		if (!raw.trim()) {
			setSettings({
				taxRate: 0,
				taxBase: base
			});
			return;
		}
		const n = parseAmount(raw);
		if (n == null || n > 100) return;
		setSettings({
			taxRate: n,
			taxBase: base
		});
	}
	function exportRange(kind) {
		const dates = [...earnings, ...expenses].map((r) => r.date).sort();
		if (dates.length === 0) {
			toast.error("Dışa aktarılacak kayıt yok");
			return;
		}
		const data = snapshot();
		const from = dates[0] ?? today;
		const to = dates[dates.length - 1] ?? today;
		if (kind === "csv") downloadCsvFile(data, from, to);
		else downloadXlsFile(data, from, to);
	}
	function onFile(e) {
		const file = e.target.files?.[0];
		e.target.value = "";
		if (!file) return;
		const reader = new FileReader();
		reader.onload = () => {
			try {
				const json = JSON.parse(String(reader.result));
				if (!importBackup(json)) toast.error("Bu dosya Tur Defteri yedeği değil");
				else {
					const next = useLedger.getState().settings.taxRate;
					setRate(next ? amountToInput(next) : "");
					toast.success("Yedek geri yüklendi");
				}
			} catch {
				toast.error("Dosya okunamadı");
			}
		};
		reader.readAsText(file);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				title: "Ayarlar",
				text: "Her şey bu cihazda kalır. Uygulamayı veya site verisini silersen kayıtlar da gider; arada bir yedek indir."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/diger",
				className: "text-sm font-medium text-muted",
				children: "← Diğer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Görünüm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-1 rounded-2xl bg-surface-2 p-1",
					children: THEMES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: settings.theme === item.id ? "min-h-11 rounded-xl bg-surface text-sm font-semibold text-ink" : "min-h-11 rounded-xl text-sm font-medium text-muted",
						onClick: () => setSettings({ theme: item.id }),
						children: item.label
					}, item.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Stopaj yardımcısı"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Yüzde gir, bu ayın tahmini kesintisini gör. Beyanname yerine geçmez."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Oran (%)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							inputMode: "decimal",
							placeholder: "20",
							value: rate,
							onChange: (e) => applyRate(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: [["brut", "Brüt kazanç"], ["net", "Net kâr"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: settings.taxBase === id,
							onClick: () => applyRate(rate, id),
							children: label
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Bu ay tahmini stopaj"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-3xl tabular-nums",
							children: tax == null ? "—" : formatTRY(tax, 2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: ["Matrah ", settings.taxBase === "brut" ? formatTRY(totals.earn, 0) : formatTRY(Math.max(0, totals.net), 0)]
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Platformlar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: active.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-col gap-2 rounded-2xl border border-line bg-surface p-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field sm:flex-1",
								defaultValue: p.name,
								maxLength: 40,
								"aria-label": `${p.name} adı`,
								onBlur: (e) => {
									const next = e.target.value;
									if (next.trim() === p.name) return;
									if (!renamePlatform(p.id, next)) {
										e.target.value = p.name;
										setError("Bu isim kullanılıyor veya boş.");
									} else setError("");
								}
							}, `${p.id}-${p.name}`), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => archivePlatform(p.id),
								children: "Gizle"
							})]
						}, p.id))
					}),
					archived.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Gizli"
						}), archived.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "font-medium text-primary",
								onClick: () => restorePlatform(p.id),
								children: "Geri al"
							})]
						}, p.id))]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field sm:flex-1",
							placeholder: "Yeni platform",
							maxLength: 40,
							value: name,
							onChange: (e) => setName(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								const result = addPlatform(name);
								if (!result.ok) setError(result.message);
								else {
									setName("");
									setError("");
								}
							},
							children: "Ekle"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Dışa aktarma ve yedek"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row sm:flex-wrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "surface",
								onClick: () => exportRange("csv"),
								children: "Tüm kayıtlar CSV"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "surface",
								onClick: () => exportRange("xls"),
								children: "Tüm kayıtlar Excel"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "surface",
								onClick: () => downloadBackup(snapshot()),
								children: "Yedek indir"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "surface",
								onClick: () => fileRef.current?.click(),
								children: "Yedekten yükle"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "application/json,.json",
						className: "hidden",
						onChange: onFile
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "CSV, Türkçe Excel için noktalı virgül kullanır. PDF için Rapor ekranında yazdır. Yedek yüklemek bu cihazdaki defterin yerine geçer."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Veri"
					}),
					confirmSample ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Örnek hafta, şu anki kazanç, gider, araç ve hedeflerin yerine geçer." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								loadSample();
								setConfirmSample(false);
								toast.success("Örnek hafta yüklendi");
							},
							children: "Yükle"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setConfirmSample(false),
							children: "Vazgeç"
						})]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "surface",
						onClick: () => {
							if (hasData) setConfirmSample(true);
							else {
								loadSample();
								toast.success("Örnek hafta yüklendi");
							}
						},
						children: "Örnek haftayı yükle"
					}),
					confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kazanç, gider, araç, hedef ve platformlar silinir. Tema ayarın kalır." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								resetData();
								setConfirmReset(false);
								toast.success("Kayıtlar silindi");
							},
							children: "Evet, sil"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setConfirmReset(false),
							children: "Vazgeç"
						})]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => setConfirmReset(true),
						children: "Tüm kayıtları sil"
					})
				]
			})
		]
	});
}
//#endregion
export { AyarlarPage as component };
