import { i as __toESM } from "../_runtime.mjs";
import { a as formatNum, c as parseIntish, o as formatTRY, s as parseAmount, t as amountToInput } from "./format-CmA-bWrc.mjs";
import { J as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as categoryLabel, b as useLedger, f as groupByDate, t as CATEGORIES, u as formatShort, v as todayISO, y as uid } from "./store-B6L3TiTP.mjs";
import { d as totalsBetween } from "./calc-CHS9czQW.mjs";
import { a as ErrorNote, c as PageIntro, i as ConfirmDelete, n as Card, o as Field, r as Chip, t as Button } from "./ui-CC6xQcZ6.mjs";
import { r as Route$3 } from "./router-CjOoX-Vm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gider-Ck9fDrn-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GiderPage() {
	const { tarih } = Route$3.useSearch();
	const expenses = useLedger((s) => s.expenses);
	const earnings = useLedger((s) => s.earnings);
	const vehicles = useLedger((s) => s.vehicles);
	const addExpense = useLedger((s) => s.addExpense);
	const updateExpense = useLedger((s) => s.updateExpense);
	const deleteExpense = useLedger((s) => s.deleteExpense);
	const [date, setDate] = (0, import_react.useState)(() => tarih ?? todayISO());
	const [category, setCategory] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [liters, setLiters] = (0, import_react.useState)("");
	const [vehicleId, setVehicleId] = (0, import_react.useState)("");
	const [odometer, setOdometer] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [visibleGroups, setVisibleGroups] = (0, import_react.useState)(12);
	(0, import_react.useEffect)(() => {
		if (tarih) setDate(tarih);
	}, [tarih]);
	const groups = (0, import_react.useMemo)(() => groupByDate(expenses), [expenses]);
	const shown = groups.slice(0, visibleGroups);
	function reset(keepCategory = true) {
		setAmount("");
		setNote("");
		setLiters("");
		setOdometer("");
		setEditing(null);
		setError("");
		if (!keepCategory) setCategory("");
	}
	function onSubmit(e) {
		e.preventDefault();
		if (!category) {
			setError("Bir kategori seç.");
			return;
		}
		const amt = parseAmount(amount);
		if (amt == null || amt <= 0) {
			setError("Tutar gir.");
			return;
		}
		let literVal = null;
		if (category === "yakit" && liters.trim()) {
			literVal = parseAmount(liters);
			if (literVal == null || literVal <= 0) {
				setError("Litre geçersiz.");
				return;
			}
		}
		let odo = null;
		if (category === "yakit" && odometer.trim()) {
			odo = parseIntish(odometer);
			if (odo == null) {
				setError("Kilometre tam sayı olmalı.");
				return;
			}
		}
		const patch = {
			date,
			category,
			amount: amt,
			note,
			liters: category === "yakit" ? literVal : null,
			vehicleId: category === "yakit" && vehicleId ? vehicleId : null,
			odometer: category === "yakit" ? odo : null
		};
		if (editing) updateExpense(editing, patch);
		else addExpense({
			id: uid(),
			...patch
		});
		reset(true);
	}
	function startEdit(row) {
		setEditing(row.id);
		setDate(row.date);
		setCategory(row.category);
		setAmount(amountToInput(row.amount));
		setNote(row.note);
		setLiters(row.liters != null ? amountToInput(row.liters) : "");
		setVehicleId(row.vehicleId ?? "");
		setOdometer(row.odometer != null ? String(Math.round(row.odometer)) : "");
		setError("");
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	}
	const amtN = parseAmount(amount);
	const literN = parseAmount(liters);
	const vehicle = vehicles.find((v) => v.id === vehicleId);
	const perLiter = amtN != null && literN != null && literN > 0 ? amtN / literN : null;
	const perKm = perLiter != null && vehicle && vehicle.consumption > 0 ? perLiter * vehicle.consumption / 100 : null;
	const dayNet = totalsBetween(earnings, expenses, date, date);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				eyebrow: formatShort(date),
				title: "Gider",
				text: "Yakıtta litreyi de yaz. Kilometre maliyeti, aracın tüketiminden hesaplanır."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "flex flex-col gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tarih",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value || todayISO())
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm font-medium",
						children: "Kategori"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							pressed: category === c.id,
							onClick: () => setCategory(c.id),
							children: c.label
						}, c.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tutar (₺)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							inputMode: "decimal",
							autoComplete: "off",
							placeholder: "0,00",
							value: amount,
							onChange: (e) => setAmount(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Not",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							maxLength: 280,
							value: note,
							onChange: (e) => setNote(e.target.value)
						})
					}),
					category === "yakit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex flex-col gap-4 bg-surface-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Litre",
								hint: "İsteğe bağlı. ₺/litre ve ₺/km için gerekli.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field",
									inputMode: "decimal",
									placeholder: "0,00",
									value: liters,
									onChange: (e) => setLiters(e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-sm font-medium",
								children: "Araç"
							}), vehicles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Araç seçmeden de kaydedilir. Km hesabı için Araç bölümünden ekle."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: vehicles.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									pressed: vehicleId === v.id,
									onClick: () => setVehicleId(v.id),
									children: v.plate
								}, v.id))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Kilometre sayacı",
								hint: "İsteğe bağlı. İki alım arasında gerçek tüketim çıkar.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field",
									inputMode: "numeric",
									placeholder: "45210",
									value: odometer,
									onChange: (e) => setOdometer(e.target.value)
								})
							}),
							perLiter != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums font-medium",
										children: formatTRY(perLiter, 2)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: " / litre"
									}),
									perKm != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted",
											children: " · tahmini "
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums font-medium",
											children: formatTRY(perKm, 2)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted",
											children: [
												" / km (",
												formatNum(vehicle?.consumption ?? 0, 1),
												" L / 100 km)"
											]
										})
									] }) : null
								]
							}) : null
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Bu günün neti şimdi ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-ink",
								children: formatTRY(dayNet.net, 0)
							}),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "lg",
							className: "sm:flex-1",
							children: editing ? "Gideri güncelle" : "Gideri kaydet"
						}), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "lg",
							onClick: () => reset(true),
							children: "Vazgeç"
						}) : null]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-lg font-semibold",
				children: "Son giderler"
			}), shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Henüz gider yok."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4",
				children: [shown.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm font-medium text-muted",
					children: formatShort(group.date)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: group.items.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-line bg-surface px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: categoryLabel(row.category)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [row.note || "Not yok", row.liters ? ` · ${formatNum(row.liters, 1)} L` : ""]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "shrink-0 tabular-nums text-expense",
								children: formatTRY(row.amount, 2)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-sm font-medium text-primary",
								onClick: () => startEdit(row),
								children: "Düzenle"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, { onConfirm: () => deleteExpense(row.id) })]
						})]
					}, row.id))
				})] }, group.date)), groups.length > shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "surface",
					onClick: () => setVisibleGroups((n) => n + 12),
					children: "Daha eski giderler"
				}) : null]
			})] })
		]
	});
}
//#endregion
export { GiderPage as component };
