import { a as categoryLabel } from "./store-B6L3TiTP.mjs";
import { d as totalsBetween } from "./calc-CHS9czQW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/export-B8hc9x3J.js
function csvCell(value) {
	const raw = String(value);
	const safe = /^[=+\-@]/.test(raw) ? `'${raw}` : raw;
	if (/[;"\n]/.test(safe)) return `"${safe.replace(/"/g, "\"\"")}"`;
	return safe;
}
function dec(n) {
	if (n == null) return "";
	return n.toFixed(2).replace(".", ",");
}
function platformName(platforms, id) {
	return platforms.find((p) => p.id === id)?.name ?? "Eski platform";
}
function buildCsv(data, from, to) {
	const header = [
		"Tarih",
		"Tür",
		"Kalem",
		"Tutar",
		"Bahşiş",
		"Tur",
		"Litre",
		"Kilometre",
		"Not"
	];
	const rows = [];
	const earnings = data.earnings.filter((e) => e.date >= from && e.date <= to).sort((a, b) => a.date.localeCompare(b.date));
	const expenses = data.expenses.filter((e) => e.date >= from && e.date <= to).sort((a, b) => a.date.localeCompare(b.date));
	for (const row of earnings) rows.push([
		row.date,
		"Kazanç",
		platformName(data.platforms, row.platformId),
		dec(row.amount),
		dec(row.tip),
		row.trips == null ? "" : String(row.trips),
		"",
		"",
		row.note
	]);
	for (const row of expenses) rows.push([
		row.date,
		"Gider",
		categoryLabel(row.category),
		dec(row.amount),
		"",
		"",
		dec(row.liters),
		row.odometer == null ? "" : String(Math.round(row.odometer)),
		row.note
	]);
	rows.sort((a, b) => a[0].localeCompare(b[0]));
	const totals = totalsBetween(data.earnings, data.expenses, from, to);
	const summary = [
		[],
		["Özet", `${from} - ${to}`],
		["Kazanç", dec(totals.earn)],
		["Gider", dec(totals.spend)],
		["Net", dec(totals.net)]
	];
	return [
		header,
		...rows,
		...summary
	].map((line) => line.map(csvCell).join(";")).join("\r\n");
}
function esc(s) {
	return s.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;");
}
function buildXlsHtml(data, from, to) {
	const totals = totalsBetween(data.earnings, data.expenses, from, to);
	const body = dataRows(data, from, to).map((r) => `<tr><td>${esc(r.date)}</td><td>${esc(r.kind)}</td><td>${esc(r.name)}</td><td>${esc(dec(r.amount))}</td><td>${esc(r.tip)}</td><td>${esc(r.note)}</td></tr>`).join("");
	return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<table>
<tr><td>Tur Defteri</td><td>${esc(from)} – ${esc(to)}</td></tr>
<tr><td>Kazanç</td><td>${esc(dec(totals.earn))}</td></tr>
<tr><td>Gider</td><td>${esc(dec(totals.spend))}</td></tr>
<tr><td>Net</td><td>${esc(dec(totals.net))}</td></tr>
</table>
<br>
<table border="1">
<tr><th>Tarih</th><th>Tür</th><th>Kalem</th><th>Tutar</th><th>Bahşiş</th><th>Not</th></tr>
${body}
</table>
</body></html>`;
}
function dataRows(data, from, to) {
	const earn = data.earnings.filter((e) => e.date >= from && e.date <= to).map((e) => ({
		date: e.date,
		kind: "Kazanç",
		name: platformName(data.platforms, e.platformId),
		amount: e.amount + e.tip,
		tip: e.tip ? dec(e.tip) : "",
		note: e.note
	}));
	const spend = data.expenses.filter((e) => e.date >= from && e.date <= to).map((e) => ({
		date: e.date,
		kind: "Gider",
		name: categoryLabel(e.category),
		amount: e.amount,
		tip: "",
		note: e.note
	}));
	return [...earn, ...spend].sort((a, b) => a.date.localeCompare(b.date));
}
function downloadText(filename, text, mime) {
	const blob = new Blob([text], { type: mime });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
	URL.revokeObjectURL(url);
}
function downloadCsvFile(data, from, to) {
	downloadText(`tur-defteri-${from}-${to}.csv`, `\uFEFF${buildCsv(data, from, to)}`, "text/csv;charset=utf-8");
}
function downloadXlsFile(data, from, to) {
	downloadText(`tur-defteri-${from}-${to}.xls`, `\uFEFF${buildXlsHtml(data, from, to)}`, "application/vnd.ms-excel");
}
function downloadBackup(data) {
	const payload = {
		app: "tur-defteri",
		version: 1,
		exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
		...data
	};
	downloadText(`tur-defteri-yedek-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`, JSON.stringify(payload, null, 2), "application/json");
}
//#endregion
export { downloadCsvFile as n, downloadXlsFile as r, downloadBackup as t };
