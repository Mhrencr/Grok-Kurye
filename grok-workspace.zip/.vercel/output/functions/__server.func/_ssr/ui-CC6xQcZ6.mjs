import { i as __toESM } from "../_runtime.mjs";
import { n as cn, o as formatTRY } from "./format-CmA-bWrc.mjs";
import { J as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-CC6xQcZ6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function buttonClass(variant = "primary", size = "md", className) {
	return cn("inline-flex items-center justify-center gap-2 rounded-2xl font-semibold", size === "lg" ? "min-h-14 px-5 text-lg" : "min-h-11 px-4 text-base", variant === "primary" && "bg-primary text-primary-fg", variant === "surface" && "border border-line bg-surface text-ink", variant === "ghost" && "bg-transparent text-ink", variant === "danger" && "bg-expense text-primary-fg", className);
}
function Button({ variant = "primary", size = "md", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: buttonClass(variant, size, className),
		...props
	});
}
function Card({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-2xl border border-line bg-surface p-5", className),
		children
	});
}
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-w-0 flex-col gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium text-ink",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm leading-snug text-muted",
				children: hint
			}) : null
		]
	});
}
function Chip({ pressed, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		className: cn("min-h-11 rounded-full border px-4 text-base", pressed ? "border-primary bg-primary text-primary-fg" : "border-line bg-surface text-ink", className),
		...props
	});
}
function PageIntro({ eyebrow, title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-6",
		children: [
			eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1 text-sm font-medium text-muted",
				children: eyebrow
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl leading-tight tracking-tight",
				children: title
			}),
			text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-prose text-base leading-relaxed text-muted",
				children: text
			}) : null
		]
	});
}
function toneClass(n) {
	if (n > 0) return "text-primary";
	if (n < 0) return "text-expense";
	return "text-ink";
}
function GoalBar({ label, value, goal }) {
	if (goal == null || goal <= 0) return null;
	const pct = value / goal * 100;
	const width = Math.max(0, Math.min(100, pct));
	const left = goal - value;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-baseline justify-between gap-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "tabular-nums text-ink",
				children: [
					formatTRY(value, 0),
					" / ",
					formatTRY(goal, 0)
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-2 overflow-hidden rounded-full bg-surface-2",
			role: "progressbar",
			"aria-valuenow": Math.round(width),
			"aria-valuemin": 0,
			"aria-valuemax": 100,
			"aria-label": label,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bar-fill h-full rounded-full bg-primary",
				style: { width: `${width}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: left > 0 ? `${formatTRY(left, 0)} kaldı` : "Hedef geçildi"
		})
	] });
}
function ConfirmDelete({ onConfirm, label = "Sil" }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "text-sm text-muted",
		onClick: () => setOpen(true),
		children: label
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "font-semibold text-expense",
			onClick: onConfirm,
			children: "Evet, sil"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "text-muted",
			onClick: () => setOpen(false),
			children: "Vazgeç"
		})]
	});
}
function ErrorNote({ children }) {
	if (!children) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "text-sm text-expense",
		children
	});
}
//#endregion
export { ErrorNote as a, PageIntro as c, ConfirmDelete as i, buttonClass as l, Card as n, Field as o, Chip as r, GoalBar as s, Button as t, toneClass as u };
