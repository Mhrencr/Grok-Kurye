import { i as __toESM } from "../_runtime.mjs";
import { o as formatTRY } from "./format-CmA-bWrc.mjs";
import { J as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as useLedger, d as formatWeekday, g as monthProgress, h as monthBounds, l as formatLong, m as maintLabel, p as lastDays, u as formatShort, v as todayISO, x as weekBounds } from "./store-B6L3TiTP.mjs";
import { d as totalsBetween, f as upcomingMaintenance, i as dueLabel, s as monthMessage, t as calendarAvg } from "./calc-CHS9czQW.mjs";
import { l as buttonClass, n as Card, s as GoalBar, u as toneClass } from "./ui-CC6xQcZ6.mjs";
import { u as Check } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cj5vedWY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const earnings = useLedger((s) => s.earnings);
	const expenses = useLedger((s) => s.expenses);
	const goals = useLedger((s) => s.goals);
	const closedDays = useLedger((s) => s.closedDays);
	const vehicles = useLedger((s) => s.vehicles);
	const maintenance = useLedger((s) => s.maintenance);
	const loadSample = useLedger((s) => s.loadSample);
	const model = (0, import_react.useMemo)(() => {
		const today = todayISO();
		const week = weekBounds(today);
		const month = monthBounds(today);
		const monthTotals = totalsBetween(earnings, expenses, month.from, month.to);
		const progress = monthProgress(today);
		const pct = goals.monthly && goals.monthly > 0 ? monthTotals.net / goals.monthly * 100 : null;
		return {
			today,
			week,
			month,
			todayTotals: totalsBetween(earnings, expenses, today, today),
			weekTotals: totalsBetween(earnings, expenses, week.from, week.to),
			monthTotals,
			days: lastDays(today, 7).map((date) => ({
				date,
				totals: totalsBetween(earnings, expenses, date, date),
				closed: closedDays.includes(date)
			})).reverse(),
			reminders: upcomingMaintenance(maintenance, today).slice(0, 3),
			message: pct == null ? null : monthMessage(pct, progress.late),
			weekAvg: calendarAvg(totalsBetween(earnings, expenses, week.from, week.to).net, week.from, week.to)
		};
	}, [
		earnings,
		expenses,
		closedDays,
		maintenance,
		goals.monthly
	]);
	const empty = earnings.length === 0 && expenses.length === 0;
	const todayClosed = closedDays.includes(model.today);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: formatLong(model.today)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-4xl tracking-tight",
					children: "Gün sonu"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Kasa evde kapanır. Yolda bir şey yazmana gerek yok."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/gun",
				search: { tarih: model.today },
				className: buttonClass("primary", "lg", "w-full"),
				children: "Bugünün kayıtlarını gir"
			}),
			todayClosed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted",
				children: "Bugün deftere işlendi. İstersen düzenlersin."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Bugünün neti"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `mt-1 font-display text-5xl tabular-nums tracking-tight ${toneClass(model.todayTotals.net)}`,
					children: formatTRY(model.todayTotals.net, 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						"Kazanç ",
						formatTRY(model.todayTotals.earn, 0),
						" · Gider ",
						formatTRY(model.todayTotals.spend, 0),
						model.todayTotals.tip > 0 ? ` · Bahşiş ${formatTRY(model.todayTotals.tip, 0)}` : "",
						model.todayTotals.trips > 0 ? ` · ${model.todayTotals.trips} tur` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalBar, {
						label: "Günlük hedef",
						value: model.todayTotals.net,
						goal: goals.daily
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Bu hafta"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `mt-1 font-display text-3xl tabular-nums ${toneClass(model.weekTotals.net)}`,
						children: formatTRY(model.weekTotals.net, 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"Kazanç ",
							formatTRY(model.weekTotals.earn, 0),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Gider ",
							formatTRY(model.weekTotals.spend, 0)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalBar, {
							label: "Haftalık hedef",
							value: model.weekTotals.net,
							goal: goals.weekly
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Bu ay"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `mt-1 font-display text-3xl tabular-nums ${toneClass(model.monthTotals.net)}`,
						children: formatTRY(model.monthTotals.net, 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"Kazanç ",
							formatTRY(model.monthTotals.earn, 0),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Gider ",
							formatTRY(model.monthTotals.spend, 0)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalBar, {
							label: "Aylık hedef",
							value: model.monthTotals.net,
							goal: goals.monthly
						})
					}),
					model.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-ink",
						children: model.message
					}) : null
				] })]
			}),
			!goals.daily && !goals.weekly && !goals.monthly ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/hedef",
				className: "text-sm font-semibold text-primary",
				children: "Net kazanç hedefi koy"
			}) : null,
			model.reminders.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2",
				children: model.reminders.map((item) => {
					const vehicle = vehicles.find((v) => v.id === item.vehicleId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/arac",
						className: "rounded-2xl border border-line bg-surface px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: vehicle?.plate ?? "Araç"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: maintLabel(item.kind)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: item.days < 0 ? "text-sm text-expense" : "text-sm text-muted",
								children: dueLabel(item.days)
							})
						]
					}, item.id);
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-lg font-semibold",
				children: "Son 7 gün"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "px-4 py-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: model.days.map((day) => {
					const quiet = day.totals.earn === 0 && day.totals.spend === 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-t border-line first:border-t-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/gun",
							search: { tarih: day.date },
							className: "flex items-center gap-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-14 shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: formatWeekday(day.date)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium",
										children: formatShort(day.date)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "min-w-0 flex-1",
									children: quiet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "Kayıt yok"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-sm text-muted",
										children: [
											formatTRY(day.totals.earn, 0),
											" kazanç · ",
											formatTRY(day.totals.spend, 0),
											" gider"
										]
									})
								}),
								day.closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "size-4 shrink-0 text-primary",
									"aria-label": "Kaydedildi"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `shrink-0 font-display text-xl tabular-nums ${toneClass(quiet ? 0 : day.totals.net)}`,
									children: quiet ? "—" : formatTRY(day.totals.net, 0)
								})
							]
						})
					}, day.date);
				}) })
			})] }),
			empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Defter boş"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "İlk gününü kendin yazabilir ya da ekranların nasıl dolduğunu görmek için örnek bir hafta yükleyebilirsin."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${buttonClass("surface", "md")} mt-4`,
					onClick: loadSample,
					children: "Örnek haftayı yükle"
				})
			] }) : null,
			model.weekAvg != null && model.weekTotals.daysActive > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Bu hafta takvim ortalaması ",
					formatTRY(model.weekAvg, 0),
					" / gün. Çalıştığın",
					" ",
					model.weekTotals.daysActive,
					" günün ortalaması ",
					formatTRY(model.weekTotals.avgNet ?? 0, 0),
					"."
				]
			}) : null
		]
	});
}
//#endregion
export { Home as component };
