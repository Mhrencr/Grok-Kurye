import { J as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as PageIntro } from "./ui-CC6xQcZ6.mjs";
import { a as Settings, l as ChevronRight, p as Bike, r as Target } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/diger-2DMqrePR.js
var import_jsx_runtime = require_jsx_runtime();
var LINKS = [
	{
		to: "/arac",
		title: "Araç ve yakıt",
		text: "Tüketim, kilometre maliyeti, yağ, lastik ve muayene.",
		icon: Bike
	},
	{
		to: "/hedef",
		title: "Hedefler",
		text: "Günlük, haftalık ve aylık net kazanç.",
		icon: Target
	},
	{
		to: "/ayarlar",
		title: "Ayarlar ve yedek",
		text: "Tema, stopaj, platformlar, Excel ve cihaz yedeği.",
		icon: Settings
	}
];
function DigerPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			title: "Diğer",
			text: "Günün kaydı özet, gün ve giderde. Gerisi burada."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: LINKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				className: "flex min-h-20 items-center gap-4 rounded-2xl border border-line bg-surface px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
						className: "size-6 shrink-0 text-primary",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-muted",
							children: item.text
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
						className: "size-5 shrink-0 text-muted",
						"aria-hidden": true
					})
				]
			}) }, item.to))
		})]
	});
}
//#endregion
export { DigerPage as component };
