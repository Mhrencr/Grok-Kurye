import { l as round2 } from "./format-CmA-bWrc.mjs";
import { a as startOfMonth, i as endOfWeek, n as getDaysInMonth, o as endOfMonth, r as format, s as startOfWeek, t as tr } from "../_libs/date-fns.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-B6L3TiTP.js
var ISO = /^\d{4}-\d{2}-\d{2}$/;
function isISODate(value) {
	if (!ISO.test(value)) return false;
	return formatISODate(parseISODate(value)) === value;
}
function formatISODate(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseISODate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y || 1970, (m || 1) - 1, d || 1);
}
function todayISO() {
	return formatISODate(/* @__PURE__ */ new Date());
}
function shiftISO(iso, days) {
	const d = parseISODate(iso);
	d.setDate(d.getDate() + days);
	return formatISODate(d);
}
function weekBounds(iso) {
	const d = parseISODate(iso);
	return {
		from: formatISODate(startOfWeek(d, { weekStartsOn: 1 })),
		to: formatISODate(endOfWeek(d, { weekStartsOn: 1 }))
	};
}
function monthBounds(iso) {
	const d = parseISODate(iso);
	return {
		from: formatISODate(startOfMonth(d)),
		to: formatISODate(endOfMonth(d))
	};
}
function lastDays(iso, count) {
	const days = [];
	for (let i = count - 1; i >= 0; i -= 1) days.push(shiftISO(iso, -i));
	return days;
}
/** Dahil aralık. 400 günden uzunsa kesilir; arayüz zaten daraltır. */
function eachISO(from, to) {
	if (from > to) return [];
	const out = [];
	let cur = from;
	let guard = 0;
	while (cur <= to && guard < 400) {
		out.push(cur);
		cur = shiftISO(cur, 1);
		guard += 1;
	}
	return out;
}
function daysBetween(from, to) {
	const a = parseISODate(from).getTime();
	const b = parseISODate(to).getTime();
	return Math.round((b - a) / 864e5);
}
function formatLong(iso) {
	return format(parseISODate(iso), "d MMMM yyyy, EEEE", { locale: tr });
}
function formatShort(iso) {
	return format(parseISODate(iso), "d MMM", { locale: tr });
}
function formatWeekday(iso) {
	return format(parseISODate(iso), "EEE", { locale: tr });
}
function monthProgress(iso) {
	const d = parseISODate(iso);
	const day = d.getDate();
	const days = getDaysInMonth(d);
	return {
		day,
		days,
		late: day >= days - 2
	};
}
function dateSearch(search) {
	return { tarih: typeof search.tarih === "string" && isISODate(search.tarih) ? search.tarih : void 0 };
}
function groupByDate(rows) {
	const sorted = [...rows].sort((a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : 0);
	const map = /* @__PURE__ */ new Map();
	for (const row of sorted) {
		const list = map.get(row.date);
		if (list) list.push(row);
		else map.set(row.date, [row]);
	}
	return [...map.entries()].map(([date, items]) => ({
		date,
		items
	}));
}
var CATEGORIES = [
	{
		id: "yakit",
		label: "Yakıt"
	},
	{
		id: "bakim",
		label: "Bakım"
	},
	{
		id: "lastik",
		label: "Lastik"
	},
	{
		id: "yemek",
		label: "Yemek"
	},
	{
		id: "telefon",
		label: "Telefon / Paket"
	},
	{
		id: "sigorta",
		label: "Sigorta"
	},
	{
		id: "diger",
		label: "Diğer"
	}
];
var MAINT_KINDS = [
	{
		id: "yag",
		label: "Yağ değişimi"
	},
	{
		id: "lastik",
		label: "Lastik"
	},
	{
		id: "muayene",
		label: "Muayene"
	},
	{
		id: "diger",
		label: "Diğer"
	}
];
var DEFAULT_PLATFORMS = [
	{
		id: "ys",
		name: "Yemeksepeti"
	},
	{
		id: "getir",
		name: "Getir"
	},
	{
		id: "trendyol",
		name: "Trendyol Go"
	},
	{
		id: "migros",
		name: "Migros Yemek"
	},
	{
		id: "kendi",
		name: "Kendi işi"
	}
];
function categoryLabel(id) {
	return CATEGORIES.find((c) => c.id === id)?.label ?? "Diğer";
}
function maintLabel(id) {
	return MAINT_KINDS.find((k) => k.id === id)?.label ?? "Hatırlatma";
}
function defaultSettings() {
	return {
		theme: "system",
		taxRate: 0,
		taxBase: "brut"
	};
}
function defaultGoals() {
	return {
		daily: null,
		weekly: null,
		monthly: null
	};
}
function defaultLedger() {
	return {
		platforms: DEFAULT_PLATFORMS.map((p) => ({ ...p })),
		earnings: [],
		expenses: [],
		vehicles: [],
		maintenance: [],
		goals: defaultGoals(),
		settings: defaultSettings(),
		closedDays: []
	};
}
var THEMES = [
	"system",
	"light",
	"dark"
];
var BASES = ["brut", "net"];
var CATS = new Set(CATEGORIES.map((c) => c.id));
var KINDS = new Set(MAINT_KINDS.map((k) => k.id));
function isRecord(value) {
	return !!value && typeof value === "object" && !Array.isArray(value);
}
function str(value, max) {
	if (typeof value !== "string") return null;
	const t = value.trim();
	if (!t) return null;
	return t.slice(0, max);
}
function money(value) {
	if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value >= 1e8) return null;
	return round2(value);
}
function optMoney(value) {
	if (value == null || value === "") return null;
	return money(value);
}
function dateOf(value) {
	return typeof value === "string" && isISODate(value) ? value : null;
}
function asPlatform(value) {
	if (!isRecord(value)) return null;
	const id = str(value.id, 80);
	const name = str(value.name, 40);
	if (!id || !name) return null;
	return {
		id,
		name,
		archived: value.archived === true
	};
}
function asEarning(value) {
	if (!isRecord(value)) return null;
	const id = str(value.id, 80);
	const date = dateOf(value.date);
	const platformId = str(value.platformId, 80);
	const amount = money(value.amount);
	const tip = money(value.tip) ?? 0;
	if (!id || !date || !platformId || amount == null) return null;
	return {
		id,
		date,
		platformId,
		amount,
		tip,
		trips: typeof value.trips === "number" && Number.isFinite(value.trips) && value.trips >= 0 ? Math.round(value.trips) : null,
		note: typeof value.note === "string" ? value.note.trim().slice(0, 280) : ""
	};
}
function asExpense(value) {
	if (!isRecord(value)) return null;
	const id = str(value.id, 80);
	const date = dateOf(value.date);
	const category = typeof value.category === "string" && CATS.has(value.category) ? value.category : null;
	const amount = money(value.amount);
	if (!id || !date || !category || amount == null) return null;
	return {
		id,
		date,
		category,
		amount,
		note: typeof value.note === "string" ? value.note.trim().slice(0, 280) : "",
		liters: optMoney(value.liters),
		vehicleId: str(value.vehicleId, 80),
		odometer: optMoney(value.odometer)
	};
}
function asVehicle(value) {
	if (!isRecord(value)) return null;
	const id = str(value.id, 80);
	const brand = str(value.brand, 40);
	const model = str(value.model, 40);
	const plate = str(value.plate, 16);
	const consumption = money(value.consumption);
	if (!id || !brand || !model || !plate || consumption == null || consumption <= 0 || consumption > 40) return null;
	return {
		id,
		brand,
		model,
		plate: plate.toLocaleUpperCase("tr"),
		consumption
	};
}
function asMaint(value) {
	if (!isRecord(value)) return null;
	const id = str(value.id, 80);
	const vehicleId = str(value.vehicleId, 80);
	const kind = typeof value.kind === "string" && KINDS.has(value.kind) ? value.kind : null;
	const dueDate = dateOf(value.dueDate);
	if (!id || !vehicleId || !kind || !dueDate) return null;
	return {
		id,
		vehicleId,
		kind,
		dueDate,
		note: typeof value.note === "string" ? value.note.trim().slice(0, 280) : "",
		done: value.done === true
	};
}
function asSettings(value) {
	const base = defaultSettings();
	if (!isRecord(value)) return base;
	const theme = THEMES.includes(value.theme) ? value.theme : base.theme;
	const taxBase = BASES.includes(value.taxBase) ? value.taxBase : base.taxBase;
	const rate = money(value.taxRate);
	return {
		theme,
		taxBase,
		taxRate: rate == null ? 0 : Math.min(100, rate)
	};
}
function goal(value) {
	if (value == null) return null;
	const n = money(value);
	if (n == null || n <= 0) return null;
	return n;
}
/** Yedek dosyası veya düz veri. Bozuksa null. */
function parseBackup(raw) {
	if (!isRecord(raw)) return null;
	if (raw.app != null && raw.app !== "tur-defteri") return null;
	if (!Array.isArray(raw.earnings) || !Array.isArray(raw.expenses)) return null;
	const platforms = Array.isArray(raw.platforms) ? raw.platforms.map(asPlatform).filter((x) => !!x) : [];
	const goalsRaw = isRecord(raw.goals) ? raw.goals : {};
	const closedDays = Array.isArray(raw.closedDays) ? raw.closedDays.filter((d) => typeof d === "string" && isISODate(d)) : [];
	return {
		platforms,
		earnings: raw.earnings.map(asEarning).filter((x) => !!x),
		expenses: raw.expenses.map(asExpense).filter((x) => !!x),
		vehicles: Array.isArray(raw.vehicles) ? raw.vehicles.map(asVehicle).filter((x) => !!x) : [],
		maintenance: Array.isArray(raw.maintenance) ? raw.maintenance.map(asMaint).filter((x) => !!x) : [],
		goals: {
			...defaultGoals(),
			daily: goal(goalsRaw.daily),
			weekly: goal(goalsRaw.weekly),
			monthly: goal(goalsRaw.monthly)
		},
		settings: asSettings(raw.settings),
		closedDays
	};
}
/** İlk bakış için tek haftalık, silinebilir örnek. Gerçek kayıtların yerine geçer. */
function buildSample(today) {
	const d = (n) => shiftISO(today, n);
	const vehicleId = "arac-ornek";
	const earn = (date, platformId, amount, tip, trips, note = "") => ({
		id: `ornek-${date}-${platformId}-${amount}`,
		date,
		platformId,
		amount,
		tip,
		trips,
		note
	});
	const spend = (id, date, category, amount, note, extra = {}) => ({
		id,
		date,
		category,
		amount,
		note,
		liters: extra.liters ?? null,
		vehicleId: extra.vehicleId ?? null,
		odometer: extra.odometer ?? null
	});
	const earnings = [
		earn(d(-6), "ys", 860, 45, 16, "Akşam yoğun"),
		earn(d(-6), "getir", 240, 20, 4),
		earn(d(-5), "trendyol", 610, 30, 11),
		earn(d(-4), "ys", 980, 80, 18),
		earn(d(-4), "migros", 190, 10, 3),
		earn(d(-2), "getir", 470, 35, 8),
		earn(d(-2), "kendi", 260, 40, 2, "Tanıdık teslimat"),
		earn(d(-1), "ys", 720, 55, 13),
		earn(d(-1), "trendyol", 300, 15, 5),
		earn(d(0), "ys", 540, 40, 9)
	];
	const expenses = [
		spend("g-yakit-1", d(-6), "yakit", 420, "İstasyon", {
			liters: 8.1,
			vehicleId,
			odometer: 45210
		}),
		spend("g-yemek", d(-5), "yemek", 165, "Öğle"),
		spend("g-bakim", d(-5), "bakim", 90, "Zincir spreyi"),
		spend("g-yakit-2", d(-2), "yakit", 395, "İstasyon", {
			liters: 7.6,
			vehicleId,
			odometer: 45490
		}),
		spend("g-tel", d(-1), "telefon", 220, "Hat + paket")
	];
	const maintenance = [{
		id: "m-yag",
		vehicleId,
		kind: "yag",
		dueDate: shiftISO(today, 3),
		note: "1500 km oldu sayılır",
		done: false
	}, {
		id: "m-muayene",
		vehicleId,
		kind: "muayene",
		dueDate: shiftISO(today, 40),
		note: "",
		done: false
	}];
	return {
		platforms: DEFAULT_PLATFORMS.map((p) => ({ ...p })),
		earnings,
		expenses,
		vehicles: [{
			id: vehicleId,
			brand: "Honda",
			model: "PCX",
			plate: "34 TD 270",
			consumption: 2.8
		}],
		maintenance,
		goals: {
			daily: 1200,
			weekly: 7e3,
			monthly: 28e3
		},
		closedDays: [d(-1), d(-4)]
	};
}
var THEME_STORAGE_KEY = "tur-theme";
/** Runs before paint from the document head. Keep in sync with applyTheme. */
var THEME_BOOT_SCRIPT = `(function(){try{var t=localStorage.getItem(${JSON.stringify(THEME_STORAGE_KEY)});if(t==="light"||t==="dark")document.documentElement.setAttribute("data-theme",t);}catch(e){}})();`;
function applyTheme(theme) {
	if (typeof document === "undefined") return;
	const root = document.documentElement;
	if (theme === "system") root.removeAttribute("data-theme");
	else root.setAttribute("data-theme", theme);
	try {
		localStorage.setItem(THEME_STORAGE_KEY, theme);
	} catch {}
}
function uid() {
	if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
	return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function cleanNote(note) {
	return note.trim().slice(0, 280);
}
function cleanGoal(n) {
	if (n == null || !Number.isFinite(n) || n <= 0) return null;
	return round2(n);
}
function sameName(a, b) {
	return a.trim().toLocaleLowerCase("tr") === b.trim().toLocaleLowerCase("tr");
}
var useLedger = create()(persist((set, get) => ({
	...defaultLedger(),
	addEarning: (row) => set((s) => ({ earnings: [{
		...row,
		note: cleanNote(row.note)
	}, ...s.earnings] })),
	updateEarning: (id, patch) => set((s) => ({ earnings: s.earnings.map((e) => e.id === id ? {
		...patch,
		id,
		note: cleanNote(patch.note)
	} : e) })),
	deleteEarning: (id) => set((s) => ({ earnings: s.earnings.filter((e) => e.id !== id) })),
	addExpense: (row) => set((s) => ({ expenses: [{
		...row,
		note: cleanNote(row.note)
	}, ...s.expenses] })),
	updateExpense: (id, patch) => set((s) => ({ expenses: s.expenses.map((e) => e.id === id ? {
		...patch,
		id,
		note: cleanNote(patch.note)
	} : e) })),
	deleteExpense: (id) => set((s) => ({ expenses: s.expenses.filter((e) => e.id !== id) })),
	addVehicle: (row) => set((s) => ({ vehicles: [...s.vehicles, row] })),
	updateVehicle: (id, patch) => set((s) => ({ vehicles: s.vehicles.map((v) => v.id === id ? {
		...patch,
		id
	} : v) })),
	deleteVehicle: (id) => {
		if (get().expenses.some((e) => e.vehicleId === id) || get().maintenance.some((m) => m.vehicleId === id)) return false;
		set((s) => ({ vehicles: s.vehicles.filter((v) => v.id !== id) }));
		return true;
	},
	addMaintenance: (row) => set((s) => ({ maintenance: [row, ...s.maintenance] })),
	toggleMaintenance: (id) => set((s) => ({ maintenance: s.maintenance.map((m) => m.id === id ? {
		...m,
		done: !m.done
	} : m) })),
	deleteMaintenance: (id) => set((s) => ({ maintenance: s.maintenance.filter((m) => m.id !== id) })),
	addPlatform: (name) => {
		const clean = name.trim().slice(0, 40);
		if (!clean) return {
			ok: false,
			message: "Bir ad yaz."
		};
		const existing = get().platforms.find((p) => sameName(p.name, clean));
		if (existing && !existing.archived) return {
			ok: false,
			message: "Bu platform zaten var."
		};
		if (existing?.archived) {
			set((s) => ({ platforms: s.platforms.map((p) => p.id === existing.id ? {
				...p,
				archived: false,
				name: clean
			} : p) }));
			return {
				ok: true,
				id: existing.id
			};
		}
		const id = uid();
		const row = {
			id,
			name: clean
		};
		set((s) => ({ platforms: [...s.platforms, row] }));
		return {
			ok: true,
			id
		};
	},
	renamePlatform: (id, name) => {
		const clean = name.trim().slice(0, 40);
		if (!clean) return false;
		if (get().platforms.some((p) => p.id !== id && !p.archived && sameName(p.name, clean))) return false;
		set((s) => ({ platforms: s.platforms.map((p) => p.id === id ? {
			...p,
			name: clean
		} : p) }));
		return true;
	},
	archivePlatform: (id) => set((s) => ({ platforms: s.platforms.map((p) => p.id === id ? {
		...p,
		archived: true
	} : p) })),
	restorePlatform: (id) => set((s) => ({ platforms: s.platforms.map((p) => p.id === id ? {
		...p,
		archived: false
	} : p) })),
	setGoals: (goals) => set({ goals: {
		daily: cleanGoal(goals.daily),
		weekly: cleanGoal(goals.weekly),
		monthly: cleanGoal(goals.monthly)
	} }),
	setSettings: (patch) => set((s) => {
		const settings = {
			...s.settings,
			...patch
		};
		if (patch.theme) applyTheme(patch.theme);
		return { settings };
	}),
	closeDay: (date) => set((s) => ({ closedDays: s.closedDays.includes(date) ? s.closedDays : [...s.closedDays, date] })),
	reopenDay: (date) => set((s) => ({ closedDays: s.closedDays.filter((d) => d !== date) })),
	loadSample: () => set((s) => ({
		...s,
		...buildSample(formatISODate(/* @__PURE__ */ new Date()))
	})),
	resetData: () => set((s) => ({
		...defaultLedger(),
		settings: s.settings
	})),
	importBackup: (raw) => {
		const data = parseBackup(raw);
		if (!data) return false;
		if (data.platforms.length === 0) data.platforms = defaultLedger().platforms;
		set((s) => ({
			...s,
			...data
		}));
		applyTheme(data.settings.theme);
		return true;
	}
}), {
	name: "tur-defteri-v1",
	skipHydration: true,
	version: 1,
	partialize: (s) => ({
		platforms: s.platforms,
		earnings: s.earnings,
		expenses: s.expenses,
		vehicles: s.vehicles,
		maintenance: s.maintenance,
		goals: s.goals,
		settings: s.settings,
		closedDays: s.closedDays
	}),
	merge: (persisted, current) => {
		if (!persisted || typeof persisted !== "object") return current;
		const p = persisted;
		return {
			...current,
			...p,
			settings: {
				...current.settings,
				...p.settings
			},
			goals: {
				...current.goals,
				...p.goals
			},
			platforms: Array.isArray(p.platforms) ? p.platforms : current.platforms,
			earnings: Array.isArray(p.earnings) ? p.earnings : current.earnings,
			expenses: Array.isArray(p.expenses) ? p.expenses : current.expenses,
			vehicles: Array.isArray(p.vehicles) ? p.vehicles : current.vehicles,
			maintenance: Array.isArray(p.maintenance) ? p.maintenance : current.maintenance,
			closedDays: Array.isArray(p.closedDays) ? p.closedDays : current.closedDays
		};
	}
}));
function snapshot() {
	const s = useLedger.getState();
	return {
		platforms: s.platforms,
		earnings: s.earnings,
		expenses: s.expenses,
		vehicles: s.vehicles,
		maintenance: s.maintenance,
		goals: s.goals,
		settings: s.settings,
		closedDays: s.closedDays
	};
}
//#endregion
export { snapshot as _, categoryLabel as a, useLedger as b, eachISO as c, formatWeekday as d, groupByDate as f, monthProgress as g, monthBounds as h, applyTheme as i, formatLong as l, maintLabel as m, MAINT_KINDS as n, dateSearch as o, lastDays as p, THEME_BOOT_SCRIPT as r, daysBetween as s, CATEGORIES as t, formatShort as u, todayISO as v, weekBounds as x, uid as y };
