import { i as __toESM } from "../_runtime.mjs";
import { c as parseIntish, o as formatTRY, s as parseAmount, t as amountToInput } from "./format-CmA-bWrc.mjs";
import { J as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as categoryLabel, b as useLedger, l as formatLong, v as todayISO, y as uid } from "./store-B6L3TiTP.mjs";
import { d as totalsBetween } from "./calc-CHS9czQW.mjs";
import { a as ErrorNote, c as PageIntro, i as ConfirmDelete, n as Card, o as Field, r as Chip, t as Button, u as toneClass } from "./ui-CC6xQcZ6.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route$2 } from "./router-CjOoX-Vm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gun-CrYN0mjN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GunPage() {
	const { tarih } = Route$2.useSearch();
	const earnings = useLedger((s) => s.earnings);
	const expenses = useLedger((s) => s.expenses);
	const platforms = useLedger((s) => s.platforms);
	const closedDays = useLedger((s) => s.closedDays);
	const addEarning = useLedger((s) => s.addEarning);
	const updateEarning = useLedger((s) => s.updateEarning);
	const deleteEarning = useLedger((s) => s.deleteEarning);
	const addPlatform = useLedger((s) => s.addPlatform);
	const closeDay = useLedger((s) => s.closeDay);
	const reopenDay = useLedger((s) => s.reopenDay);
	const [date, setDate] = (0, import_react.useState)(() => tarih ?? todayISO());
	const [platformId, setPlatformId] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [tip, setTip] = (0, import_react.useState)("");
	const [trips, setTrips] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [addingPlatform, setAddingPlatform] = (0, import_react.useState)(false);
	const [newPlatform, setNewPlatform] = (0, import_react.useState)("");
	const [confirmEmpty, setConfirmEmpty] = (0, import_react.useState)(false);
	const formRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (tarih) setDate(tarih);
	}, [tarih]);
	const activePlatforms = platforms.filter((p) => !p.archived || p.id === platformId);
	(0, import_react.useEffect)(() => {
		if (platformId) return;
		const first = platforms.find((p) => !p.archived);
		if (first) setPlatformId(first.id);
	}, [platformId, platforms]);
	const dayEarnings = (0, import_react.useMemo)(() => earnings.filter((e) => e.date === date), [earnings, date]);
	const dayExpenses = (0, import_react.useMemo)(() => expenses.filter((e) => e.date === date), [expenses, date]);
	const totals = (0, import_react.useMemo)(() => totalsBetween(earnings, expenses, date, date), [
		earnings,
		expenses,
		date
	]);
	const closed = closedDays.includes(date);
	function resetFields() {
		setAmount("");
		setTip("");
		setTrips("");
		setNote("");
		setEditing(null);
		setError("");
	}
	function onSubmit(e) {
		e.preventDefault();
		if (!platformId) {
			setError("Önce bir platform seç veya ekle.");
			return;
		}
		if (amount.trim() && parseAmount(amount) == null) {
			setError("Kazanç tutarı geçersiz.");
			return;
		}
		if (tip.trim() && parseAmount(tip) == null) {
			setError("Bahşiş tutarı geçersiz.");
			return;
		}
		const amt = amount.trim() ? parseAmount(amount) ?? 0 : 0;
		const tp = tip.trim() ? parseAmount(tip) ?? 0 : 0;
		if (amt + tp <= 0) {
			setError("Kazanç veya bahşiş gir.");
			return;
		}
		let tripCount = null;
		if (trips.trim()) {
			tripCount = parseIntish(trips);
			if (tripCount == null) {
				setError("Tur sayısı tam sayı olmalı.");
				return;
			}
		}
		const patch = {
			date,
			platformId,
			amount: amt,
			tip: tp,
			trips: tripCount,
			note
		};
		if (editing) updateEarning(editing, patch);
		else addEarning({
			id: uid(),
			...patch
		});
		const keep = platformId;
		resetFields();
		setPlatformId(keep);
	}
	function startEdit(row) {
		setEditing(row.id);
		setPlatformId(row.platformId);
		setAmount(amountToInput(row.amount));
		setTip(row.tip ? amountToInput(row.tip) : "");
		setTrips(row.trips == null ? "" : String(row.trips));
		setNote(row.note);
		setError("");
		formRef.current?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}
	function onAddPlatform() {
		const result = addPlatform(newPlatform);
		if (!result.ok) {
			setError(result.message);
			return;
		}
		setPlatformId(result.id);
		setNewPlatform("");
		setAddingPlatform(false);
		setError("");
	}
	function onClose() {
		if (dayEarnings.length + dayExpenses.length === 0 && !confirmEmpty) {
			setConfirmEmpty(true);
			return;
		}
		closeDay(date);
		setConfirmEmpty(false);
		toast.success("Gün deftere işlendi");
	}
	const nameOf = (id) => platforms.find((p) => p.id === id)?.name ?? "Eski platform";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				eyebrow: "Toplu giriş",
				title: "Günün kazancı",
				text: "Her platformu ayrı satır yaz. Toplam kendiliğinden çıkar. Günü bitirince kaydet."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: formatLong(date)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `mt-1 font-display text-4xl tabular-nums ${toneClass(totals.net)}`,
					children: formatTRY(totals.net, 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"Kazanç ",
						formatTRY(totals.earn, 2),
						" · Gider ",
						formatTRY(totals.spend, 2),
						totals.tip > 0 ? ` · Bahşiş ${formatTRY(totals.tip, 2)}` : ""
					]
				}),
				closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm font-medium text-primary",
					children: "Bu gün kaydedildi."
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				ref: formRef,
				onSubmit,
				className: "flex flex-col gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tarih",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "date",
							value: date,
							onChange: (e) => {
								setDate(e.target.value || todayISO());
								resetFields();
								setConfirmEmpty(false);
							}
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm font-medium",
							children: "Platform"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [activePlatforms.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								pressed: platformId === p.id,
								onClick: () => setPlatformId(p.id),
								children: p.name
							}, p.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								pressed: addingPlatform,
								onClick: () => setAddingPlatform((v) => !v),
								children: "+ Yeni"
							})]
						}),
						addingPlatform ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-col gap-2 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field sm:flex-1",
								value: newPlatform,
								placeholder: "Platform adı",
								maxLength: 40,
								onChange: (e) => setNewPlatform(e.target.value)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: onAddPlatform,
								children: "Ekle"
							})]
						}) : null
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Kazanç (₺)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								inputMode: "decimal",
								autoComplete: "off",
								placeholder: "0,00",
								value: amount,
								onChange: (e) => setAmount(e.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Bahşiş (₺)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								inputMode: "decimal",
								autoComplete: "off",
								placeholder: "0,00",
								value: tip,
								onChange: (e) => setTip(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tur sayısı",
							hint: "Boş bırakabilirsin.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								inputMode: "numeric",
								placeholder: "0",
								value: trips,
								onChange: (e) => setTrips(e.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Not",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								maxLength: 280,
								value: note,
								onChange: (e) => setNote(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "lg",
							className: "sm:flex-1",
							children: editing ? "Satırı güncelle" : "Satır ekle"
						}), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "lg",
							onClick: resetFields,
							children: "Vazgeç"
						}) : null]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-lg font-semibold",
				children: "Bu günün satırları"
			}), dayEarnings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Henüz kazanç satırı yok."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: dayEarnings.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-line bg-surface px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: nameOf(row.platformId)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [
										formatTRY(row.amount, 2),
										row.tip > 0 ? ` + ${formatTRY(row.tip, 2)} bahşiş` : "",
										row.trips != null ? ` · ${row.trips} tur` : ""
									]
								}),
								row.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: row.note
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "shrink-0 font-display text-xl tabular-nums",
							children: formatTRY(row.amount + row.tip, 0)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm font-medium text-primary",
							onClick: () => startEdit(row),
							children: "Düzenle"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, { onConfirm: () => deleteEarning(row.id) })]
					})]
				}, row.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Bu günün giderleri"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/gider",
					search: { tarih: date },
					className: "text-sm font-semibold text-primary",
					children: "Gider ekle"
				})]
			}), dayExpenses.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Gider yok."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: dayExpenses.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between rounded-2xl border border-line px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: row.note || categoryLabel(row.category)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-expense",
						children: formatTRY(row.amount, 2)
					})]
				}, row.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "save-bar",
				children: [confirmEmpty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm text-muted",
					children: "Bu tarihte kayıt yok. Boş gün olarak kaydedilsin mi?"
				}) : null, closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "surface",
					size: "lg",
					className: "w-full",
					onClick: () => reopenDay(date),
					children: "Günü yeniden aç"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full",
					onClick: onClose,
					children: "Günü kaydet"
				})]
			})
		]
	});
}
//#endregion
export { GunPage as component };
