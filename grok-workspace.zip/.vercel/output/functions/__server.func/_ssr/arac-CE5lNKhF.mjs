import { i as __toESM } from "../_runtime.mjs";
import { a as formatNum, c as parseIntish, i as formatKm, o as formatTRY, s as parseAmount, t as amountToInput } from "./format-CmA-bWrc.mjs";
import { J as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as useLedger, m as maintLabel, n as MAINT_KINDS, s as daysBetween, u as formatShort, v as todayISO, y as uid } from "./store-B6L3TiTP.mjs";
import { i as dueLabel, p as vehicleFuelStats } from "./calc-CHS9czQW.mjs";
import { a as ErrorNote, c as PageIntro, i as ConfirmDelete, n as Card, o as Field, r as Chip, t as Button } from "./ui-CC6xQcZ6.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/arac-CE5lNKhF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AracPage() {
	const vehicles = useLedger((s) => s.vehicles);
	const expenses = useLedger((s) => s.expenses);
	const maintenance = useLedger((s) => s.maintenance);
	const addVehicle = useLedger((s) => s.addVehicle);
	const updateVehicle = useLedger((s) => s.updateVehicle);
	const deleteVehicle = useLedger((s) => s.deleteVehicle);
	const addExpense = useLedger((s) => s.addExpense);
	const addMaintenance = useLedger((s) => s.addMaintenance);
	const toggleMaintenance = useLedger((s) => s.toggleMaintenance);
	const deleteMaintenance = useLedger((s) => s.deleteMaintenance);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [showForm, setShowForm] = (0, import_react.useState)(false);
	const current = vehicles.find((v) => v.id === selected) ?? vehicles[0] ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				eyebrow: "Çoklu araç",
				title: "Araç ve yakıt",
				text: "Yakıt alımı gider olarak düşer. Sayaç yazarsan gerçek tüketim, yazmazsan beyan ettiğin litre/100 km kullanılır."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/diger",
				className: "text-sm font-medium text-muted",
				children: "← Diğer"
			}),
			vehicles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: vehicles.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					pressed: current?.id === v.id,
					onClick: () => setSelected(v.id),
					children: v.plate
				}, v.id))
			}) : null,
			vehicles.length === 0 || showForm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleForm, {
				onDone: () => setShowForm(false),
				onCreate: (row) => {
					addVehicle(row);
					setSelected(row.id);
					setShowForm(false);
				}
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "surface",
				onClick: () => setShowForm(true),
				children: "Araç ekle"
			}),
			current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleDetail, {
				vehicle: current,
				expenses,
				maintenance: maintenance.filter((m) => m.vehicleId === current.id),
				onSave: (patch) => updateVehicle(current.id, patch),
				onDelete: () => {
					if (!deleteVehicle(current.id)) toast.error("Bu araca bağlı gider veya hatırlatma var. Önce onları sil.");
					else setSelected(null);
				},
				onFuel: (row) => {
					addExpense(row);
					toast.success("Yakıt gider olarak kaydedildi");
				},
				onRemind: (row) => addMaintenance(row),
				onToggle: toggleMaintenance,
				onDeleteRemind: deleteMaintenance
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Km maliyeti için önce aracı yaz."
			})
		]
	});
}
function VehicleForm({ onCreate, onDone }) {
	const [brand, setBrand] = (0, import_react.useState)("");
	const [model, setModel] = (0, import_react.useState)("");
	const [plate, setPlate] = (0, import_react.useState)("");
	const [cons, setCons] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	function onSubmit(e) {
		e.preventDefault();
		if (!brand.trim() || !model.trim() || !plate.trim()) {
			setError("Marka, model ve plaka gerekli.");
			return;
		}
		const consumption = parseAmount(cons);
		if (consumption == null || consumption <= 0 || consumption > 40) {
			setError("Tüketimi 100 km'de litre olarak yaz. Örneğin 2,8.");
			return;
		}
		onCreate({
			id: uid(),
			brand: brand.trim(),
			model: model.trim(),
			plate: plate.trim().toLocaleUpperCase("tr"),
			consumption
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Marka",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: brand,
						maxLength: 40,
						onChange: (e) => setBrand(e.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Model",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: model,
						maxLength: 40,
						onChange: (e) => setModel(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Plaka",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: plate,
						maxLength: 16,
						onChange: (e) => setPlate(e.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ortalama tüketim",
					hint: "Litre / 100 km",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						inputMode: "decimal",
						placeholder: "2,8",
						value: cons,
						onChange: (e) => setCons(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "lg",
					children: "Aracı kaydet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "lg",
					onClick: onDone,
					children: "Vazgeç"
				})]
			})
		]
	});
}
function VehicleDetail({ vehicle, expenses, maintenance, onSave, onDelete, onFuel, onRemind, onToggle, onDeleteRemind }) {
	const stats = vehicleFuelStats(vehicle, expenses);
	const [cons, setCons] = (0, import_react.useState)(amountToInput(vehicle.consumption));
	const [error, setError] = (0, import_react.useState)("");
	const today = todayISO();
	const open = maintenance.filter((m) => !m.done).sort((a, b) => a.dueDate.localeCompare(b.dueDate));
	const done = maintenance.filter((m) => m.done);
	const fuels = expenses.filter((e) => e.category === "yakit" && e.vehicleId === vehicle.id).sort((a, b) => a.date < b.date ? 1 : -1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						vehicle.brand,
						" ",
						vehicle.model
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-tight",
					children: vehicle.plate
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 grid grid-cols-2 gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Ort. ₺/litre",
							value: stats.pricePerLiter != null ? formatTRY(stats.pricePerLiter, 2) : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "₺ / km",
							value: stats.costPerKm != null ? formatTRY(stats.costPerKm, 2) : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Tüketim",
							value: stats.actualConsumption != null ? `${formatNum(stats.actualConsumption, 1)} L` : `${formatNum(vehicle.consumption, 1)} L`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Kayıtlı km",
							value: stats.recordedKm != null ? formatKm(stats.recordedKm) : "—"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [stats.actualConsumption != null ? `Sayaçlara göre ${formatNum(stats.actualConsumption, 1)} L / 100 km. Beyan ${formatNum(vehicle.consumption, 1)}.` : "İki yakıt alımına kilometre yazınca gerçek tüketim çıkar.", stats.fills > 0 ? ` ${stats.fills} alım, ${formatNum(stats.liters, 1)} litre.` : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-3 sm:flex-row sm:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Beyan tüketim (L/100 km)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							inputMode: "decimal",
							value: cons,
							onChange: (e) => setCons(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: () => {
							const n = parseAmount(cons);
							if (n == null || n <= 0 || n > 40) {
								setError("2,8 gibi bir değer yaz.");
								return;
							}
							setError("");
							onSave({
								...vehicle,
								consumption: n
							});
							toast.success("Tüketim güncellendi");
						},
						children: "Güncelle"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
						label: "Aracı sil",
						onConfirm: onDelete
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FuelForm, { onSave: (fields) => onFuel({
				id: uid(),
				date: fields.date,
				category: "yakit",
				amount: fields.amount,
				note: fields.note,
				liters: fields.liters,
				vehicleId: vehicle.id,
				odometer: fields.odometer
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-lg font-semibold",
				children: "Yakıt alımları"
			}), fuels.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Bu araç için yakıt yok. Yukarıdan veya gider ekranından ekle."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: fuels.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 rounded-2xl border border-line px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: formatShort(row.date)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							row.liters ? `${formatNum(row.liters, 1)} L` : "Litre yok",
							row.odometer != null ? ` · ${formatKm(row.odometer)}` : "",
							row.note ? ` · ${row.note}` : ""
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tabular-nums",
						children: formatTRY(row.amount, 0)
					})]
				}, row.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemindForm, { onSave: (fields) => onRemind({
				id: uid(),
				vehicleId: vehicle.id,
				kind: fields.kind,
				dueDate: fields.dueDate,
				note: fields.note,
				done: false
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-lg font-semibold",
					children: "Hatırlatmalar"
				}),
				open.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Açık hatırlatma yok."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: open.map((item) => {
						const days = daysBetween(today, item.dueDate);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl border border-line bg-surface px-4 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: maintLabel(item.kind)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: days < 0 ? "text-sm text-expense" : "text-sm text-muted",
									children: [
										formatShort(item.dueDate),
										" · ",
										dueLabel(days),
										item.note ? ` · ${item.note}` : ""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-sm font-medium text-primary",
										onClick: () => onToggle(item.id),
										children: "Tamamlandı"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, { onConfirm: () => onDeleteRemind(item.id) })]
								})
							]
						}, item.id);
					})
				}),
				done.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-2",
					children: done.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							maintLabel(item.kind),
							" · ",
							formatShort(item.dueDate)
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "font-medium text-ink",
							onClick: () => onToggle(item.id),
							children: "Geri al"
						})]
					}, item.id))
				}) : null
			] })
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-sm text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "font-display text-2xl tabular-nums",
		children: value
	})] });
}
function FuelForm({ onSave }) {
	const [date, setDate] = (0, import_react.useState)(todayISO);
	const [amount, setAmount] = (0, import_react.useState)("");
	const [liters, setLiters] = (0, import_react.useState)("");
	const [odometer, setOdometer] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	function onSubmit(e) {
		e.preventDefault();
		const amt = parseAmount(amount);
		if (amt == null || amt <= 0) {
			setError("Tutarı yaz.");
			return;
		}
		let literVal = null;
		if (liters.trim()) {
			literVal = parseAmount(liters);
			if (literVal == null || literVal <= 0) {
				setError("Litre geçersiz.");
				return;
			}
		}
		let odo = null;
		if (odometer.trim()) {
			odo = parseIntish(odometer);
			if (odo == null) {
				setError("Kilometre tam sayı olmalı.");
				return;
			}
		}
		onSave({
			date,
			amount: amt,
			liters: literVal,
			odometer: odo,
			note
		});
		setAmount("");
		setLiters("");
		setOdometer("");
		setNote("");
		setError("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "Yakıt alımı"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tarih",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					type: "date",
					value: date,
					onChange: (e) => setDate(e.target.value || todayISO())
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tutar (₺)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						inputMode: "decimal",
						placeholder: "0,00",
						value: amount,
						onChange: (e) => setAmount(e.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Litre",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						inputMode: "decimal",
						placeholder: "0,00",
						value: liters,
						onChange: (e) => setLiters(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Kilometre sayacı",
				hint: "İsteğe bağlı",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					inputMode: "numeric",
					value: odometer,
					onChange: (e) => setOdometer(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Not",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					maxLength: 280,
					value: note,
					onChange: (e) => setNote(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNote, { children: error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "lg",
				children: "Yakıtı kaydet"
			})
		]
	});
}
function RemindForm({ onSave }) {
	const [kind, setKind] = (0, import_react.useState)("yag");
	const [dueDate, setDueDate] = (0, import_react.useState)(todayISO());
	const [note, setNote] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex flex-col gap-4",
		onSubmit: (e) => {
			e.preventDefault();
			onSave({
				kind,
				dueDate,
				note
			});
			setNote("");
			toast.success("Hatırlatma eklendi");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "Bakım hatırlatması"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Masrafı giderlere ayrıca yaz. Burası sadece tarihi tutar."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: MAINT_KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					pressed: kind === k.id,
					onClick: () => setKind(k.id),
					children: k.label
				}, k.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tarih",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					type: "date",
					value: dueDate,
					onChange: (e) => setDueDate(e.target.value || todayISO())
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Not",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					maxLength: 280,
					value: note,
					onChange: (e) => setNote(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				children: "Hatırlatmayı kaydet"
			})
		]
	});
}
//#endregion
export { AracPage as component };
